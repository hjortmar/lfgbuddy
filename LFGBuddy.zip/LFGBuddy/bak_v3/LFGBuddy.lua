-- LFGBuddy Addon for WoW 3.3.5 API 2009 -----------------------------------------------------------------
-- CONFIG / defaults
local DEFAULT_IGNORE_ZONES = {
    "Baradin Hold", "Ragefire Chasm", "Wailing Caverns", "The Deadmines", "Shadowfang Keep",
    "Blackfathom Deeps", "Stormwind Stockade", "The Stockades", "Gnomeregan", "Razorfen Kraul",
    "Scarlet Monastery", "Razorfen Downs", "Uldaman", "Zul'Farrak", "Maraudon",
    "Sunken Temple", "Temple of Atal'Hakkar", "Blackrock Depths", "Blackrock Spire",
    "Tol Barad", "Lower Blackrock Spire", "Upper Blackrock Spire", "Scholomance", "Stratholme",
}

-- Define the default cities based on faction
local DEFAULT_CITIES_ONLY

local playerFaction = UnitFactionGroup("player")
local DEFAULT_CITIES_ONLY = playerFaction == "Horde" and {
    "Orgrimmar", "Undercity", "Thunder Bluff"
} or playerFaction == "Alliance" and {
    "Stormwind", "Ironforge", "Darnassus", "Exodar"
} or {}

local ALL_CLASSES = {"Shaman","Paladin","Druid","Warrior","Warlock","Priest","Rogue","Mage","Hunter"}

local SEND_INTERVAL = 1.0 -- seconds between whispers

-- Internal state
local LFGBuddy = {}
LFGBuddy.frame = nil
LFGBuddy.whisperQueue = {}
LFGBuddy.sending = false
LFGBuddy.sendTimer = 0

-- SavedVars
playerLevel = UnitLevel("player") or 60

-- Initialize the options table
LFGBuddyOptions = {
    lastClass = "Shaman",
    lastX = UnitLevel("player") or 60,
    lastY = UnitLevel("player") or 60,
    message = "Hey buddy, wanna come tank Maraudon?",
    ignoreZones = DEFAULT_IGNORE_ZONES,
    recentMessages = {},
    filterCities = false,
    defaultCities = DEFAULT_CITIES_ONLY,
}

-- Define the saved variable name
local LFGBUDDY_SAVEDVARNAME = "LFGBuddyDB"

-- Function to initialize options
local function InitializeOptions()
    if not _G[LFGBUDDY_SAVEDVARNAME] then
        print("Saved variable not found. Initializing default values.")
        _G[LFGBUDDY_SAVEDVARNAME] = LFGBuddyOptions
    else
        print("Saved variable found. Loading values.")
        LFGBuddyOptions = _G[LFGBUDDY_SAVEDVARNAME]
    end
end

-- Call the function to initialize options
InitializeOptions()

-- Helpers --------------------------------------------------------------------
local function Notify(msg)
    if LFGBuddy.frame and LFGBuddy.frame:IsShown() then
        DEFAULT_CHAT_FRAME:AddMessage(msg)
    end
end

local function CreateSimpleFrame(name, parent, width, height)
    local f = CreateFrame("Frame", name, parent)
    f:SetSize(width, height)
    f:SetFrameStrata("DIALOG")
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) self:StartMoving() end)
    f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    return f
end

local function isZoneIgnored(zone)
    if not zone or zone == "" then return false end
    for _, z in ipairs(LFGBuddyOptions.ignoreZones) do
        if z == zone then return true end
    end
    return false
end

local function isZoneInDefaultCities(zone)
    if not zone or zone == "" then return false end
    for _, city in ipairs(DEFAULT_CITIES_ONLY) do
        if city == zone then return true end
    end
    return false
end

-- WHO results
local function OnWhoListUpdate()
    local n = GetNumWhoResults()
    LFGBuddy.whisperQueue = {}
    local onlyCities = citiesCheckbox:GetChecked() -- Check if the checkbox is checked

    for i = 1, n do
        local name, guild, level, race, class, zone = GetWhoInfo(i)
        if name and name ~= UnitName("player") then
            if onlyCities then
                -- If the checkbox is checked, only include players in default cities
                if isZoneInDefaultCities(zone) then
                    tinsert(LFGBuddy.whisperQueue, {name = name, level = level, class = class, zone = zone})
                end
            else
                -- If the checkbox is not checked, ignore players in the specified zones
                if not isZoneIgnored(zone) then
                    tinsert(LFGBuddy.whisperQueue, {name = name, level = level, class = class, zone = zone})
                end
            end
        end
    end

    if #LFGBuddy.whisperQueue == 0 then
        Notify("No players to whisper after filtering ignore zones.")
    else
        Notify("Queued " .. #LFGBuddy.whisperQueue .. " whispers.")
    end
end

-- Whisper pacing
local eventFrame = CreateFrame("Frame")
eventFrame:SetScript("OnUpdate", function(self, elapsed)
    if LFGBuddy.sending then
        LFGBuddy.sendTimer = LFGBuddy.sendTimer + elapsed
        if LFGBuddy.sendTimer >= SEND_INTERVAL then
            LFGBuddy.sendTimer = 0
            local entry = tremove(LFGBuddy.whisperQueue, 1)
            if entry then
                local msg = LFGBuddyOptions.message  -- Use LFGBuddyOptions for the message
                SendChatMessage(msg, "WHISPER", nil, entry.name)
                Notify("Whispered " .. entry.name)

                -- Save message history
                if msg ~= "" then
                    for i = #LFGBuddyOptions.recentMessages, 1, -1 do
                        if LFGBuddyOptions.recentMessages[i] == msg then
                            table.remove(LFGBuddyOptions.recentMessages, i)
                        end
                    end
                    table.insert(LFGBuddyOptions.recentMessages, 1, msg)
                    while #LFGBuddyOptions.recentMessages > 10 do
                        table.remove(LFGBuddyOptions.recentMessages)
                    end
                end
            else
                LFGBuddy.sending = false
                Notify("Finished sending whispers.")
            end
        end
    end
end)

local evt = CreateFrame("Frame")
evt:RegisterEvent("WHO_LIST_UPDATE")
evt:SetScript("OnEvent", function(_, event)
    if event == "WHO_LIST_UPDATE" then OnWhoListUpdate() end
end)

-- Dropdown helper
local function CreateLevelDropdown(name, anchor, defaultValue, dbKey)
    local dd = CreateFrame("Frame", name, UIParent, "UIDropDownMenuTemplate")
    UIDropDownMenu_SetWidth(dd, 70)

    local function Init()
        local info = UIDropDownMenu_CreateInfo()
        local min = math.max(1, playerLevel - 8)
        local max = math.min(60, playerLevel + 8)
        for i = min, max do
            info.text = tostring(i)
            info.value = i
            info.func = function(self)
                UIDropDownMenu_SetSelectedValue(dd, self.value)
                if dbKey then DB[dbKey] = self.value end -- ✅ persist to DB
            end
            info.checked = (i == UIDropDownMenu_GetSelectedValue(dd)) -- ✅ only check selected
            UIDropDownMenu_AddButton(info)
        end
    end

    UIDropDownMenu_Initialize(dd, Init)

    if defaultValue then
        UIDropDownMenu_SetSelectedValue(dd, defaultValue)
    end

    return dd
end

-- UI -------------------------------------------------------------------------
local function CreateUI()
    if LFGBuddy.frame then return end
    local f = CreateSimpleFrame("LFGBuddyFrame", UIParent, 600, 300)
    f:SetPoint("CENTER")
    f:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", edgeSize = 12
    })
    f:SetBackdropColor(0, 0, 0, 0.8)

    -- Header
    local header = CreateFrame("Frame", nil, f)
    header:SetPoint("BOTTOMLEFT", f, "TOPLEFT", 0, 0)
    header:SetSize(f:GetWidth(), 28)
    header:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border", edgeSize = 12
    })
    header:SetBackdropColor(0, 0, 0, 0.9)
    header:EnableMouse(true)
    header:SetMovable(true)
    header:RegisterForDrag("LeftButton")
    header:SetScript("OnDragStart", function() f:StartMoving() end)
    header:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)

    header.title = header:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    header.title:SetPoint("LEFT", 10, 0)
    header.title:SetText("LFG Buddy")

    local close = CreateFrame("Button", nil, header, "UIPanelCloseButton")
    close:SetPoint("RIGHT", -4, 0)
    close:SetScript("OnClick", function() f:Hide() end)

    -- Content frames
    local contentFrame = CreateFrame("Frame", nil, f)
    contentFrame:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -70) -- space for header buttons
    contentFrame:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -10, 10)

    local lfmPanel = CreateFrame("Frame", nil, contentFrame)
    lfmPanel:SetAllPoints(contentFrame)

    local blacklistPanel = CreateFrame("Frame", nil, contentFrame)
    blacklistPanel:SetAllPoints(contentFrame)
    blacklistPanel:Hide()


-- Tab switching function
local function ShowTab(tab)
    lfmPanel:Hide()
    blacklistPanel:Hide()
    if tab == "LFM" then lfmPanel:Show() end
    if tab == "Blacklist" then blacklistPanel:Show() end
end

-- Tab buttons in header
local lfmBtn = CreateFrame("Button", nil, header, "UIPanelButtonTemplate")
lfmBtn:SetPoint("LEFT", 50, 0)
lfmBtn:SetSize(90, 24)
lfmBtn:SetText("LFM")
lfmBtn:SetScript("OnClick", function() ShowTab("LFM") end)

local blBtn = CreateFrame("Button", nil, header, "UIPanelButtonTemplate")
blBtn:SetPoint("LEFT", lfmBtn, "RIGHT", 5, 0)
blBtn:SetSize(90, 24)
blBtn:SetText("Blacklist")
blBtn:SetScript("OnClick", function() ShowTab("Blacklist") end)

    ----------------------------------------------------------------
    -- LFM PANEL
    ----------------------------------------------------------------
    local rowY = -10

local classLabel = lfmPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
classLabel:SetPoint("TOPLEFT", 5, 55)
classLabel:SetText("Class")

local classDrop = CreateFrame("Frame", "LFGBuddy_ClassDropDown", lfmPanel, "UIDropDownMenuTemplate")
classDrop:SetPoint("TOPLEFT", classLabel, "BOTTOMLEFT", -18, -2)
UIDropDownMenu_SetWidth(classDrop, 80)

local classes = ALL_CLASSES
UIDropDownMenu_Initialize(classDrop, function()
    local info = UIDropDownMenu_CreateInfo()
    for _, v in ipairs(classes) do
        info.text = v
        info.value = v
        info.func = function(self)
            LFGBuddyOptions.lastClass = self.value  -- Update the options table
            UIDropDownMenu_SetSelectedValue(classDrop, self.value)
        end
        info.checked = (v == LFGBuddyOptions.lastClass)  -- Check if this class is the selected one
        UIDropDownMenu_AddButton(info)
    end
end)

UIDropDownMenu_SetSelectedValue(classDrop, LFGBuddyOptions.lastClass)  -- Set the initial selected value

-- Min Level Label
local minLabel = lfmPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
minLabel:SetPoint("TOPLEFT", classDrop, "TOPRIGHT", -13, 14)
minLabel:SetText("Min Level")

-- Min Level Dropdown
local minDrop = CreateLevelDropdown("LFGBuddy_MinDrop", lfmPanel, LFGBuddyOptions.lastX)
minDrop:SetPoint("TOPLEFT", minLabel, "BOTTOMLEFT", -18, -2)
minDrop:SetParent(lfmPanel)
minDrop:SetFrameLevel(classDrop:GetFrameLevel() + 2)

-- Max Level Label
local maxLabel = lfmPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
maxLabel:SetPoint("TOPLEFT", minDrop, "TOPRIGHT", -13, 14)
maxLabel:SetText("Max Level")

-- Max Level Dropdown
local maxDrop = CreateLevelDropdown("LFGBuddy_MaxDrop", lfmPanel, LFGBuddyOptions.lastY)
maxDrop:SetPoint("TOPLEFT", maxLabel, "BOTTOMLEFT", -18, -2)
maxDrop:SetParent(lfmPanel)
maxDrop:SetFrameLevel(minDrop:GetFrameLevel() + 2)

-- Label for the Checkbox
local citiesLabel = lfmPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
citiesLabel:SetPoint("TOPLEFT", maxDrop, "TOPRIGHT", 0, 13) -- Positioning above the checkbox
citiesLabel:SetText("Citydwellers")



-- Checkbox for DEFAULT CITIES ONLY

citiesCheckbox = CreateFrame("CheckButton", "UIPlaygroundCitiesCheckbox", lfmPanel, "UICheckButtonTemplate")
citiesCheckbox:SetChecked(LFGBuddyOptions.filterCities)
citiesCheckbox:SetPoint("TOPLEFT", citiesLabel, "BOTTOMLEFT", -5, 0) -- Positioning to the right of the Max Level label
citiesCheckbox:SetScript("OnClick", function(self)
    LFGBuddyOptions.filterCities = self:GetChecked() -- Save the checkbox state to DB
    if self:GetChecked() then
        print("Filtering WHO results to only include players in capital cities.")
    else
        print("Including players from all zones.")
    end
end)



    local msgLabel = lfmPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    msgLabel:SetPoint("TOPLEFT", classLabel, "BOTTOMLEFT", 2, -40)
    msgLabel:SetText("Message")
    local edit = CreateFrame("EditBox", "LFGBuddy_MessageEdit", lfmPanel, "InputBoxTemplate")
    edit:SetPoint("TOPLEFT", msgLabel, "BOTTOMLEFT", 3, 0)
    edit:SetSize(400, 26)
    edit:SetAutoFocus(false)
    edit:SetText(LFGBuddyOptions.message or "")
    edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    edit:SetScript("OnEnterPressed", function(self) LFGBuddyOptions.message=self:GetText(); self:ClearFocus() end)
    edit:SetScript("OnTextChanged", function(self) LFGBuddyOptions.message=self:GetText() end)

    -- Buttons
    local refreshBtn = CreateFrame("Button", "LFGBuddy_RefreshButton", lfmPanel, "UIPanelButtonTemplate")
    refreshBtn:SetPoint("BOTTOMLEFT", lfmPanel, "BOTTOMLEFT", 10, 10)
    refreshBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11) 
    refreshBtn:SetSize(96,24)
    refreshBtn:SetText("Refresh /who")
    refreshBtn:SetScript("OnClick", function()
        local classStr = string.lower(LFGBuddyOptions.lastClass)
        local min = UIDropDownMenu_GetSelectedValue(minDrop)
        local max = UIDropDownMenu_GetSelectedValue(maxDrop)
        local whoQuery = "c-"..classStr.." "..min.."-"..max
    -- Check if the citiesCheckbox is checked and append city filters
    if citiesCheckbox:GetChecked() then
        whoQuery = whoQuery .. ' z-"Thunder Bluff" z-"Orgrimmar" z-"Undercity"'
    end
        Notify("/who "..whoQuery)
        SendWho(whoQuery)
    end)

    local sendBtn = CreateFrame("Button", "LFGBuddy_SendButton", lfmPanel, "UIPanelButtonTemplate")
    sendBtn:SetPoint("BOTTOMRIGHT", lfmPanel, "BOTTOMRIGHT", -10, 10)
    sendBtn:SetSize(120,26)
    sendBtn:SetText("Send Whispers")
    sendBtn:SetScript("OnClick", function()
        if #LFGBuddy.whisperQueue==0 then
            Notify("No queued whispers. Run /who first.")
            return
        end
        LFGBuddy.sending = true
        LFGBuddy.sendTimer = SEND_INTERVAL
        Notify("Started sending whispers.")
        pauseBtn:SetText("Pause")
    end)

    local pauseBtn = CreateFrame("Button", "LFGBuddy_PauseButton", lfmPanel, "UIPanelButtonTemplate")
    pauseBtn:SetPoint("RIGHT", sendBtn, "LEFT", -5, 0)
    pauseBtn:SetSize(80,26)
    pauseBtn:SetText("Pause")
    pauseBtn:SetScript("OnClick", function()
        if LFGBuddy.sending then
            LFGBuddy.sending = false
            Notify("Whisper sending paused.")
            pauseBtn:SetText("Resume")
        else
            if #LFGBuddy.whisperQueue > 0 then
                LFGBuddy.sending = true
                LFGBuddy.sendTimer = SEND_INTERVAL
                Notify("Whisper sending resumed.")
                pauseBtn:SetText("Pause")
            else
                Notify("No queued whispers to resume.")
            end
        end
    end)

    local resetBtn = CreateFrame("Button", "LFGBuddy_ResetButton", lfmPanel, "UIPanelButtonTemplate")
    resetBtn:SetPoint("RIGHT", pauseBtn, "LEFT", -5, 0)
    resetBtn:SetSize(80,26)
    resetBtn:SetText("Reset")
    resetBtn:SetScript("OnClick", function()
        LFGBuddy.sending=false; LFGBuddy.whisperQueue={}; LFGBuddy.sendTimer=0
        Notify("Whisper queue reset.")
    end)

    ----------------------------------------------------------------
    -- BLACKLIST PANEL
    ----------------------------------------------------------------
    blacklistPanel.title = blacklistPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    blacklistPanel.title:SetPoint("TOPLEFT", 10, -10)
    blacklistPanel.title:SetText("Blacklist")
    local blEdit = CreateFrame("EditBox", nil, blacklistPanel, "InputBoxTemplate")
    blEdit:SetPoint("TOPLEFT", blacklistPanel.title, "BOTTOMLEFT", 0, -10)
    blEdit:SetSize(200,24)
    blEdit:SetAutoFocus(false)
    blEdit:SetScript("OnEnterPressed", function(self)
        local text = self:GetText()
        if text ~= "" then
            table.insert(LFGBuddyOptions.ignoreZones, text)
            Notify("Added "..text.." to blacklist")
            self:SetText("")
        end
    end)

    -- default tab
    ShowTab("LFM")
    LFGBuddy.frame = f
end

-- Slash command
SLASH_LFGBUDDY1 = "/lfgbuddy"
SlashCmdList["LFGBUDDY"] = function()
    if not LFGBuddy.frame then CreateUI() end
    if LFGBuddy.frame:IsShown() then LFGBuddy.frame:Hide() else LFGBuddy.frame:Show() end
end

-- Preload
CreateUI()
LFGBuddy.frame:Hide()

