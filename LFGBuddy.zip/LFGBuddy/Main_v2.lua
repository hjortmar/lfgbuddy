-- Main.lua
local ADDON_NAME, LFGBuddy = ...

-- Options table stored in WTF
LFGBuddyOptions = LFGBuddyOptions or {}

-- Initialization
function LFGBuddy.OnFirstLoad()
    -- one-time initialization check
    if not LFGBuddyOptions.initialized then
	
		local LFGBUDDY_DEFAULT_IGNORE_ZONES  = {
			"Baradin Hold","Ragefire Chasm","Wailing Caverns","The Deadmines","Shadowfang Keep",
			"Blackfathom Deeps","Stormwind Stockade","The Stockades","Gnomeregan","Razorfen Kraul",
			"Scarlet Monastery","Razorfen Downs","Uldaman","Zul'Farrak","Maraudon",
			"Sunken Temple","Temple of Atal'Hakkar","Blackrock Depths","Blackrock Spire",
			"Tol Barad","Lower Blackrock Spire","Upper Blackrock Spire","Scholomance","Stratholme",
		}

		local playerFaction = UnitFactionGroup("player")
		local LFGBUDDY_DEFAULT_CITIES =
			(playerFaction == "Horde")
			and {"Orgrimmar","Undercity","Thunder Bluff"}
			or {"Stormwind","Ironforge","Darnassus","Exodar"}
								 
		local LFGBUDDY_DEFAULT_CLASSES = {"Shaman","Paladin","Druid","Warrior","Warlock","Priest","Rogue","Mage","Hunter"}

        -- fill ignore zones
        LFGBuddyOptions.ignoreZones = {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_IGNORE_ZONES) do
            table.insert(LFGBuddyOptions.ignoreZones, name)
        end

        -- fill cities
        LFGBuddyOptions.cities = {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_CITIES) do
            table.insert(LFGBuddyOptions.cities, name)
        end

        -- fill classes
        LFGBuddyOptions.classes = {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_CLASSES) do
            table.insert(LFGBuddyOptions.classes, name)
        end

        LFGBuddyOptions.loadOnLogin = false
		LFGBuddyOptions.collectedContinents = {}
        LFGBuddyOptions.showOnWho = false
        LFGBuddyOptions.initialized = true -- mark as initialized

        print("|cff33ff99LFGBuddy:|r Initialized with default ignorezones, cities, and classes.")
    end
	
    --LFGBuddyOptions.loadOnLogin = LFGBuddyOptions.loadOnLogin
	
end

-- Reset initialized flag so defaults will be reapplied on next load
function LFGBuddy.ResetDefaults()
    LFGBuddyOptions.initialized = false
    LFGBuddy.OnFirstLoad()
    print("|cff33ff99LFG Buddy:|r Defaults restored.")
end

-- Collect continents and store in options, avoiding duplicates
function LFGBuddy.CollectContinents()
    LFGBuddyOptions.collectedContinents = LFGBuddyOptions.collectedContinents or {}
    local continents = { GetMapContinents() }
    local headerPrinted = false

    for i, name in ipairs(continents) do
        -- Skip if already collected
        local exists = false
        for _, existing in ipairs(LFGBuddyOptions.collectedContinents) do
            if existing == name then
                exists = true
                break
            end
        end
        if not exists then
            table.insert(LFGBuddyOptions.collectedContinents, name)
            
            if not headerPrinted then
                print("|cff33ff99LFGBuddy:|r Collected continents:")
                headerPrinted = true
            end
            
            print("  " .. name)
        end
    end

    if not headerPrinted then
        print("|cff33ff99LFGBuddy:|r No new continents were added.")
    end
end

-- Add a class to LFGBuddyOptions.classes
function LFGBuddy.AddClass(className)
    if not className or className == "" then return end
    LFGBuddyOptions.classes = LFGBuddyOptions.classes or {}

    -- Check for duplicates
    for _, existing in ipairs(LFGBuddyOptions.classes) do
        if existing == className then
            print("|cff33ff99LFGBuddy:|r Class '"..className.."' already exists.")
            return
        end
    end

    table.insert(LFGBuddyOptions.classes, className)
    print("|cff33ff99LFGBuddy:|r Class '"..className.."' added.")
end

-- Function to enable or disable auto-show on Who
function LFGBuddy.ToggleShowOnWho(enable)
    LFGBuddyOptions.showOnWho = enable
    print("|cff33ff99LFGBuddy:|r Auto-show GUI on Who tab " .. (enable and "ENABLED." or "DISABLED."))
end

-- Hook WhoFrame to show our GUI if enabled
local function WhoFrame_OnShowHook()
    if LFGBuddyOptions.showOnWho and LFGBuddy.frame then
        LFGBuddy.frame:Show()
    end
end

-- Attach hook safely
if WhoFrame then
    WhoFrame:HookScript("OnShow", WhoFrame_OnShowHook)
end

-- Create a simple frame
local function CreateSimpleFrame()
    if LFGBuddy.frame then return end  -- avoid creating multiple times

    local f = CreateFrame("Frame", "LFGBuddyFrame", UIParent)
    f:SetSize(450, 150)
    f:SetPoint("CENTER")
    f:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        edgeSize = 10
    })
    f:SetBackdropColor(0,0,0,0.8)
    --f:SetBackdropBorderColor(0, .44, .87, 0.5)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)

    -- Title
    local title = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    title:SetPoint("TOP", 0, -10)
    title:SetText("LFGBuddy UI")

    -- Example text
    local text = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    text:SetPoint("CENTER")
    text:SetText("This is a simple test frame!")

    -- Close button
    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", f, "TOPRIGHT")
    f.closeButton = close

	-- Separator line
	local sep = f:CreateTexture(nil, "BACKGROUND")
	sep:SetColorTexture(0.5, 0.5, 0.5, 0.8) -- gray line
	sep:SetHeight(1)
	sep:SetPoint("TOPLEFT", 10, -35)
	sep:SetPoint("TOPRIGHT", -10, -35)

    f:Hide()
    LFGBuddy.frame = f
end



-- Helper to show current settings
function LFGBuddy.ShowSettings()
    print("|cff33ff99LFG Buddy Settings:|r")
    print("  loadOnLogin = " .. (LFGBuddyOptions.loadOnLogin and "ENABLED" or "DISABLED"))
    print("  collectedContinents = " .. (#LFGBuddyOptions.collectedContinents > 0 and table.concat(LFGBuddyOptions.collectedContinents, ", ") or "None"))
    print("  ignorezones = " .. (#LFGBuddyOptions.ignoreZones > 0 and table.concat(LFGBuddyOptions.ignoreZones, ", ") or "None"))
    print("  cities = " .. (#LFGBuddyOptions.cities > 0 and table.concat(LFGBuddyOptions.cities, ", ") or "None"))
    print("  classes = " .. (#LFGBuddyOptions.classes > 0 and table.concat(LFGBuddyOptions.classes, ", ") or "None"))
    print("Commands:")
    print("  /lb collectzones   - Collect continents and save to options")
    print("  /lb login on       - Enable auto-login")
    print("  /lb login off      - Disable auto-login")
    print("  /lb login          - Show current auto-login setting")
    print("  /lb show           - Show GUI")
    print("  /lb reset          - Reset to default settings.")
    print("  /lb addclass <ClassName>   - Add a class to your list")
    print("  /lb                - Show this help")
end

-- Slash command handler
SLASH_LFGBUDDY1 = "/lb"
SlashCmdList["LFGBUDDY"] = function(msg)
    msg = msg or ""
    local command, arg = msg:match("^(%S*)%s*(.-)$")
    command = command:lower()

    if command == "collectzones" then
        LFGBuddy.CollectContinents()
    elseif command == "show" then
        CreateSimpleFrame()
        LFGBuddy.frame:Show()
    elseif command == "login" then
        arg = arg:lower()
        if arg == "on" then
            LFGBuddyOptions.loadOnLogin = true
            print("|cff33ff99LFG Buddy:|r Auto-collect on login ENABLED.")
        elseif arg == "off" then
            LFGBuddyOptions.loadOnLogin = false
            print("|cff33ff99LFG Buddy:|r Auto-collect on login DISABLED.")
        else
            print("|cff33ff99LFG Buddy:|r Auto-collect on login is " ..
                (LFGBuddyOptions.loadOnLogin and "|cFF00FF00ENABLED|r" or "|cFFFF0000DISABLED|r"))
        end
    elseif command == "reset" then
        LFGBuddy.ResetDefaults()
        print("|cff33ff99LFG Buddy:|r Reset to default settings.")
    elseif command == "addclass" and arg ~= "" then
        LFGBuddy.AddClass(arg)
    else
        LFGBuddy.ShowSettings()
    end
end



-- Event hook
local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function(self, event, addonName)
    if event == "ADDON_LOADED" and addonName == ADDON_NAME then
		LFGBuddy.OnFirstLoad()
        print("|cff33ff99LFG Buddy loaded.|r Type /lb for commands.")
    elseif event == "PLAYER_LOGIN" then
        if LFGBuddyOptions.loadOnLogin then
            LFGBuddy.CollectContinents()
        end
    end
end)
