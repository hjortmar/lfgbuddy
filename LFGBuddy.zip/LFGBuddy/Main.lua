-- Main.lua
local ADDON_NAME, LFGBuddy = ...

-- show messages
-- only show messages when whisperqueue updated.
-- reset lockout timers

-- =========================
-- Default Data
-- =========================
local LFGBUDDY_DEFAULT_IGNORE_ZONES = {
    "Baradin Hold","Ragefire Chasm","Wailing Caverns","The Deadmines","Shadowfang Keep",
    "Blackfathom Deeps","Stormwind Stockade","The Stockades","Gnomeregan","Razorfen Kraul",
    "Scarlet Monastery","Razorfen Downs","Uldaman","Zul'Farrak","Maraudon",
    "Sunken Temple","Temple of Atal'Hakkar","The Temple of Atal'Hakkar","Blackrock Depths","Blackrock Spire",
    "Tol Barad","Lower Blackrock Spire","Upper Blackrock Spire","Scholomance","Stratholme","Blackrock Mountain",
}

local LFGBUDDY_DEFAULT_PVP_ZONES = {
    "Warsong Gulch","Arathi Basin",
}

-- Default city lists
local DEFAULT_HORDE_CITIES = {"Orgrimmar", "Undercity", "Thunder Bluff","Silvermoon"}
local DEFAULT_ALLIANCE_CITIES = {"Stormwind", "Ironforge", "Darnassus", "Exodar"}

local LFGBUDDY_DEFAULT_CLASSES = {"Shaman","Paladin","Druid","Warrior","Warlock","Priest","Rogue","Mage","Hunter"}

-- =========================
-- Options stored in WTF
-- =========================
LFGBuddyOptions = LFGBuddyOptions or {}

-- =========================
-- Initialization
-- =========================
function LFGBuddy.OnFirstLoad()
    if not LFGBuddyOptions.initialized then
        -- ignore zones
        LFGBuddyOptions.ignoreZones = {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_IGNORE_ZONES) do
            table.insert(LFGBuddyOptions.ignoreZones, name)
        end
		
        -- ignore zones
        LFGBuddyOptions.ignorePvPZones = {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_PVP_ZONES) do
            table.insert(LFGBuddyOptions.ignorePvPZones, name)
        end

		local playerFaction = UnitFactionGroup("player")
		LFGBuddyOptions.cities = (playerFaction == "Horde") and DEFAULT_HORDE_CITIES or DEFAULT_ALLIANCE_CITIES

        -- classes
        LFGBuddyOptions.classes = {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_CLASSES) do
            table.insert(LFGBuddyOptions.classes, name)
        end
		
		if #LFGBuddyOptions.classes > 0 then LFGBuddyOptions.lastClass = LFGBuddyOptions.classes[1] end

        -- Init min/max levels
        local lvl = UnitLevel("player")
        LFGBuddyOptions.minLevel = math.max(1, lvl - 8)
        LFGBuddyOptions.maxLevel = math.min(60, lvl + 8)

        -- flags
        LFGBuddyOptions.showOnWho = true
        LFGBuddyOptions.lockToWho  = true
        LFGBuddyOptions.queueCitiesOnly = false
		LFGBuddyOptions.recentSentMessages = {} -- we want to store the last 10 messasges sent aka what is written in "Message".
		LFGBuddyOptions.recentMessageRecipients = {} -- we want to store the names of players that we have sent a message to, we do not want to send them a message again for 10 minutes. They should be ignored until 10 minutes have passed.
		LFGBuddyOptions.ignoreRecipientLockout = false
		LFGBuddyOptions.spamInterval = 1.2
		LFGBuddyOptions.spamLockoutMins = 10
		LFGBuddyOptions.togglepvpzones = true
		LFGBuddyOptions.firstrefresh = false
		LFGBuddyOptions.firstqueue = false
		LFGBuddyOptions.disableaddonnotifications = false
	--	LFGBuddyOptions.framePoint = LFGBuddyOptions.framePoint or nil
	--	LFGBuddyOptions.frameRelativePoint = LFGBuddyOptions.frameRelativePoint or nil
	--	LFGBuddyOptions.frameX = LFGBuddyOptions.frameX or 0
	--	LFGBuddyOptions.frameY = LFGBuddyOptions.frameY or 0
        LFGBuddyOptions.initialized = true

        print("|cff33ff99LFGBuddy:|r Initialized with default ignorezones, cities, and classes.")
    end
	
    -- Runtime state (reset every reload/UI load)
    LFGBuddy.whisperQueue = {}
    LFGBuddy.sendTimer = 0
    LFGBuddy.sending = false
end

-- Reset everything to defaults
function LFGBuddy.ResetDefaults()
    LFGBuddyOptions = {}
	LFGBuddyOptions.initialized = false
    LFGBuddy.OnFirstLoad()
	LFGBuddy.UpdateButtonStates()
    print("|cff33ff99LFGBuddy:|r Defaults restored.")
end

function LFGBuddy.Print(msg, raw, force)
    -- If notifications are disabled and force is not set, stop
    if LFGBuddyOptions.disableaddonnotifications and not force then
        return
    end

    local text = tostring(msg or "")

    if not raw then
        text = "|cff33ff99LFGBuddy:|r " .. text
    end

    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage(text)
    else
        print(text)  -- fallback in case chat frame isn't available
    end
	
	---- Normal, respects disableaddonnotifications
	--LFGBuddy.Print("This will show if notifications are enabled.")
	--
	---- Raw, no prefix
	--LFGBuddy.Print("Just the message", true)
	--
	---- Force print even if notifications are disabled
	--LFGBuddy.Print("Critical message", false, true)
end

-- =========================
-- Classes
-- =========================
-- Adds a class to the list
function LFGBuddy.AddClass(className)
    if not className or className == "" then
        return false, "Invalid class name."
    end

    LFGBuddyOptions.classes = LFGBuddyOptions.classes or {}

    for _, existing in ipairs(LFGBuddyOptions.classes) do
        if existing:lower() == className:lower() then
            return false, "Class '" .. className .. "' already exists."
        end
    end

    table.insert(LFGBuddyOptions.classes, className)
    return true, "Class '" .. className .. "' added."
end

-- Removes a class from the list
function LFGBuddy.RemoveClass(className)
    if not className or className == "" then
        return false, "Invalid class name."
    end

    if not LFGBuddyOptions.classes or #LFGBuddyOptions.classes == 0 then
        return false, "No classes defined."
    end

    for i, existing in ipairs(LFGBuddyOptions.classes) do
        if existing:lower() == className:lower() then
            table.remove(LFGBuddyOptions.classes, i)
            return true, "Class '" .. className .. "' removed."
        end
    end

    return false, "Class '" .. className .. "' not found."
end

-- =========================
-- Switch between faction capitals.
-- =========================
function LFGBuddy.ToggleCities()
    local isHorde = false
    for _, city in ipairs(LFGBuddyOptions.cities) do
        if city == "Orgrimmar" then
            isHorde = true
            break
        end
    end

    if isHorde then
        LFGBuddyOptions.cities = DEFAULT_ALLIANCE_CITIES
		LFGBuddy.Print("Cities switched to Alliance defaults.")
    else
        LFGBuddyOptions.cities = DEFAULT_HORDE_CITIES
        LFGBuddy.Print("Cities switched to Horde defaults.")
    end
end


-- =========================
-- Add and remove ignorezones.
-- =========================
function LFGBuddy.PrintIgnoreZones()
    if not LFGBuddyOptions.ignoreZones or #LFGBuddyOptions.ignoreZones == 0 then
        LFGBuddy.Print("No ignore zones set.")
        return
    end

    LFGBuddy.Print("Ignore Zones:")
    for i, zone in ipairs(LFGBuddyOptions.ignoreZones) do
        LFGBuddy.Print(i .. ". " .. zone)
    end
end

function LFGBuddy.AddIgnoreZone(zoneName)
    if not zoneName or zoneName == "" then return end
    LFGBuddyOptions.ignoreZones = LFGBuddyOptions.ignoreZones or {}

    local lowerZone = zoneName:lower()
    for _, existing in ipairs(LFGBuddyOptions.ignoreZones) do
        if existing:lower() == lowerZone then
            LFGBuddy.Print("Zone '" .. zoneName .. "' is already in ignore list.")
            return
        end
    end

    table.insert(LFGBuddyOptions.ignoreZones, zoneName)
    LFGBuddy.Print("Zone '" .. zoneName .. "' added to ignore list.")
end

-- Remove a zone from ignoreZones
function LFGBuddy.RemoveIgnoreZone(zoneName)
    if not zoneName or zoneName == "" then return end
    if not LFGBuddyOptions.ignoreZones then return end

    local lowerZone = zoneName:lower()
    for i, existing in ipairs(LFGBuddyOptions.ignoreZones) do
        if existing:lower() == lowerZone then
            table.remove(LFGBuddyOptions.ignoreZones, i)
            LFGBuddy.Print("Zone '" .. existing .. "' removed from ignore list.")
            return
        end
    end

    LFGBuddy.Print("Zone '" .. zoneName .. "' not found in ignore list.")
end

-- =========================
-- ShowOnWho
-- =========================
-- Toggle auto-show on Who tab-- Helper: snap LFGBuddy to WhoFrame if lock is enabled
local function SnapToWhoFrame()
    if LFGBuddy.frame and WhoFrame and LFGBuddyOptions.lockToWho then
        LFGBuddy.frame:StopMovingOrSizing()
        LFGBuddy.frame:ClearAllPoints()
        LFGBuddy.frame:SetPoint("TOPLEFT", WhoFrame, "TOPRIGHT", -35, -13)
        LFGBuddy.frame:SetMovable(false)
        LFGBuddy.frame:EnableMouse(false)
    end
end

-- Toggle auto-show on Who tab
function LFGBuddy.ToggleShowOnWho(enable)
    LFGBuddyOptions.showOnWho = enable
    LFGBuddy.Print("Auto-show GUI on Who tab " .. (enable and "ENABLED." or "DISABLED."))

    if enable then
        LFGBuddyUI() -- create frame if needed
    end
end

-- Toggle lock-to-Who (independent of show/hide)
function LFGBuddy.ToggleLockToWho(enable)
    LFGBuddyOptions.lockToWho = enable
    if enable then
        SnapToWhoFrame()
    elseif LFGBuddy.frame then
        -- Allow free movement again
        LFGBuddy.frame:SetMovable(true)
        LFGBuddy.frame:EnableMouse(true)
    end

    LFGBuddy.Print("Lock to Who tab " .. (enable and "ENABLED." or "DISABLED."))
end

-- Show/hide frame when Who tab opens/closes
local function WhoFrame_OnShowHook()
    if LFGBuddyOptions.showOnWho then
        LFGBuddyUI()
        LFGBuddy.frame:Show()
    end

    -- Always handle snapping separately
    if LFGBuddyOptions.lockToWho then
        SnapToWhoFrame()
    end
end

local function WhoFrame_OnHideHook()
    if LFGBuddy.frame and LFGBuddyOptions.showOnWho then
        LFGBuddy.frame:Hide()
    end
end

-- Hook safely
if WhoFrame then
    WhoFrame:HookScript("OnShow", WhoFrame_OnShowHook)
    WhoFrame:HookScript("OnHide", WhoFrame_OnHideHook)
end


-- Check if a zone is one of the default cities
local function isZoneInDefaultCities(zone)
    for _, city in ipairs(LFGBuddyOptions.cities) do
        if city == zone then return true end
    end
    return false
end

-- Check if a zone is ignored
local function isZoneIgnored(zone)
    for _, ignored in ipairs(LFGBuddyOptions.ignoreZones) do
        if ignored == zone then return true end
    end
    return false
end

-- Check if a zone is ignored
local function isPvPZoneIgnored(zone)
    for _, ignored in ipairs(LFGBuddyOptions.ignorePvPZones) do
        if ignored == zone then return true end
    end
    return false
end


function LFGBuddy.ToggleQueueCitiesOnly(enable)
    LFGBuddyOptions.queueCitiesOnly = enable
    LFGBuddy.Print("Queue only players in default cities " .. (enable and "ENABLED." or "DISABLED."))
end

function LFGBuddy.UpdateWhisperQueue_without_BlizzIgnoreList()
    LFGBuddy.whisperQueue = {}
    local now = time()
    local lockoutSeconds = (LFGBuddyOptions.spamLockoutMins or 10) * 60  -- convert minutes to seconds
    local n = GetNumWhoResults()
    for i = 1, n do
        local name, guild, level, race, class, zone = GetWhoInfo(i)
        if name and name ~= UnitName("player") then
            local include = true
            if LFGBuddyOptions.queueCitiesOnly then
                include = isZoneInDefaultCities(zone)
            else
                include = not isZoneIgnored(zone)
            end

            -- Skip players who are recent recipients (based on configurable lockout)
            local lastSent = LFGBuddyOptions.recentMessageRecipients[name]
            if lastSent and not LFGBuddyOptions.ignoreRecipientLockout then
                if now - lastSent <= lockoutSeconds then
                    include = false
                    LFGBuddy.Print("Skipping " .. name .. " (lockout active)")
                end
            end

            if include then
                table.insert(LFGBuddy.whisperQueue, {name=name, level=level, class=class, zone=zone})
            end
        end
    end

    if #LFGBuddy.whisperQueue == 0 then
        LFGBuddy.Print("No players to whisper after filtering.")
    else
        LFGBuddy.Print("Queued " .. #LFGBuddy.whisperQueue .. " whispers.")
    end
	LFGBuddy.UpdateButtonStates()
end

function LFGBuddy.UpdateWhisperQueue()
    LFGBuddy.whisperQueue = {}
    local now = time()
    local lockoutSeconds = (LFGBuddyOptions.spamLockoutMins or 10) * 60  -- convert minutes to seconds
    local n = GetNumWhoResults()

    for i = 1, n do
        local name, guild, level, race, class, zone = GetWhoInfo(i)
        if name and name ~= UnitName("player") then
            local include = true

			if LFGBuddyOptions.queueCitiesOnly then
				-- Only keep players in default cities
				include = isZoneInDefaultCities(zone)
			else
				-- Exclude players in ignored zones
				if isZoneIgnored(zone) then
					include = false
				end

				-- Exclude players in PvP zones if toggle is active
				if LFGBuddyOptions.togglepvpzones and isPvPZoneIgnored(zone) then
					include = false
				end
			end

            -- Skip players who are on the Blizzard ignore list
            if IsIgnored(name) then
                include = false
                LFGBuddy.Print("Skipping " .. name .. " (ignored)")
            end

            -- Skip players who are recent recipients (lockout)
            local lastSent = LFGBuddyOptions.recentMessageRecipients[name]
            if lastSent and not LFGBuddyOptions.ignoreRecipientLockout then
                if now - lastSent <= lockoutSeconds then
                    include = false
                    LFGBuddy.Print("Skipping " .. name .. " (lockout active)")
                end
            end

            if include then
                table.insert(LFGBuddy.whisperQueue, {name=name, level=level, class=class, zone=zone})
            end
        end
    end

    if #LFGBuddy.whisperQueue == 0 then
        LFGBuddy.Print("No players to whisper after filtering.")
    else
        LFGBuddy.Print("Queued " .. #LFGBuddy.whisperQueue .. " whispers.")
    end

    LFGBuddy.UpdateButtonStates()
end

function LFGBuddy.ShowWhisperQueue()
    if not LFGBuddy.whisperQueue or #LFGBuddy.whisperQueue == 0 then
        LFGBuddy.Print("Whisper queue is empty.")
        return
    end

    LFGBuddy.Print("Current Whisper Queue:", false, true)
    for i, entry in ipairs(LFGBuddy.whisperQueue) do
        LFGBuddy.Print(string.format("  %s - Level %s %s in %s", entry.name, entry.level, entry.class, entry.zone),true,true)
    end
end

-- Whisper pacing
local eventFrame = CreateFrame("Frame")
eventFrame:SetScript("OnUpdate", function(self, elapsed)
    if LFGBuddy.sending then
        LFGBuddy.sendTimer = (LFGBuddy.sendTimer or 0) + elapsed
        if LFGBuddy.sendTimer >= (LFGBuddyOptions.spamInterval or 1.0) then
            LFGBuddy.sendTimer = 0
            local entry = tremove(LFGBuddy.whisperQueue, 1)
            if entry then
                local now = time()
                local last = LFGBuddyOptions.recentMessageRecipients[entry.name]
                if not last or (now - last) > 600 or LFGBuddyOptions.ignoreRecipientLockout then
                    local msg = LFGBuddy.messageEdit:GetText() or ""
                    SendChatMessage(msg, "WHISPER", nil, entry.name)
                    LFGBuddyOptions.recentMessageRecipients[entry.name] = now
                    --LFGBuddy.Print("Whispered " .. entry.name)
                else
                    LFGBuddy.Print("Skipped " .. entry.name .. " (lockout active)")
                end
            else
                LFGBuddy.sending = false
                if LFGBuddy_StartPauseButton then
                    LFGBuddy_StartPauseButton:SetText("Start") -- reset the button
                end
                LFGBuddy.Print("Whispers sent to all in queue.",false,true)
				LFGBuddy.UpdateButtonStates()
            end
        end
    end
end)

function LFGBuddy.ClearMessageFocus()
    if LFGBuddy.messageEdit and LFGBuddy.messageEdit:HasFocus() then
        LFGBuddy.messageEdit:ClearFocus()
    end
end

-- =========================
-- GUI
-- =========================

function LFGBuddyUI()
    if LFGBuddy.frame then return end
	
    local f = CreateFrame("Frame", "LFGBuddyFrame", UIParent)
    f:SetSize(367, 148)
    f:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        edgeSize = 10
    })
    f:ClearAllPoints()
	if LFGBuddyOptions.framePoint then
		f:SetPoint(
			LFGBuddyOptions.framePoint,
			UIParent,
			LFGBuddyOptions.frameRelativePoint,
			LFGBuddyOptions.frameX,
			LFGBuddyOptions.frameY
		)
	else
		f:SetPoint("CENTER")
	end
	f:SetScript("OnDragStart", f.StartMoving) 
	f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetBackdropColor(0,0,0,0.8)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")

    -- Title
    local title = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    title:SetPoint("TOPLEFT", 6, -6)
    title:SetFont("Fonts\\FRIZQT__.TTF", 13) 
    title:SetText("LFG Buddy")

    -- Close button
    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", f, "TOPRIGHT", 4, 3)
    f.closeButton = close
    close:SetScript("OnClick", function()
        f:Hide()
        if LFGBuddyOptions.lockToWho and WhoFrame then
            FriendsFrame:Hide()
        end
    end)

    -- Separator
    local sep = f:CreateTexture(nil, "BACKGROUND")
    sep:SetColorTexture(0.5, 0.5, 0.5, 0.8)
	sep:SetAlpha(0.8)
    sep:SetHeight(1)
    sep:SetPoint("TOPLEFT", 5, -24)
    sep:SetPoint("TOPRIGHT", -5, -24)
	sep:SetDrawLayer("BACKGROUND", 1)

    -- === Tabs ===
    local tabNames = {"", "Options"}
    local tabButtons, tabFrames = {}, {}

    for i, name in ipairs(tabNames) do

		-- Create a button without a template
		local btn = CreateFrame("Button", nil, f)
		if name == "" then
			btn:SetSize(1, 16)  -- Set size to 1, 16 for the blank tab
		else
			btn:SetSize(45, 16)  -- Set size for non-empty tabs
		end

		-- Create a font string for the button
		local fontString = btn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
		fontString:SetText(name)  -- Set button text
		fontString:SetAllPoints(btn)  -- Make the font string cover the button
		fontString:SetFont("Fonts\\FRIZQT__.TTF", 11) 

		-- Set button background color for normal state
		btn:SetNormalTexture("")  -- No normal texture
		btn:SetHighlightTexture("")  -- No highlight texture
		btn:SetDisabledTexture("")  -- No disabled texture

		if i == 1 then
			btn:SetPoint("TOPRIGHT", f.closeButton, "TOPLEFT", 0, -7)
		else
			btn:SetPoint("RIGHT", tabButtons[i-1], "LEFT", 0, 0)
		end

		-- Create content frame
		local frame = CreateFrame("Frame", nil, f)
		frame:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -70)
		frame:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -10, 10)
		frame:Hide()

		-- Button click handler
		btn:SetScript("OnClick", function()
			if selectedTabIndex == i then
				-- If it is, switch back to the main tab (first tab)
				tabButtons[1]:Click()  -- Simulate a click on the first tab
			else
				for j, other in ipairs(tabFrames) do
					other:SetShown(frame == other)
					tabButtons[j]:UnlockHighlight()
					tabButtons[j].fontString:SetTextColor(1, 1, 1)  -- Reset text color
				end
				btn:LockHighlight()
				fontString:SetTextColor(1.0, 0.82, 0.0)  -- Highlight color for selected tab
				selectedTabIndex = i  -- Update the selected tab index
			end
		end)

		-- Set default text color
		fontString:SetTextColor(1, 1, 1)  -- Default text color

		-- Store the font string in the button for easy access later
		btn.fontString = fontString

        table.insert(tabButtons, btn)
        table.insert(tabFrames, frame)
    end

    tabButtons[1]:Click() -- Default to first tab
	
    -- Class Label (inside Main tab)
    local classLabel = tabFrames[1]:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	classLabel:SetFont("Fonts\\FRIZQT__.TTF", 11) 
    classLabel:SetPoint("TOPLEFT", tabFrames[1], "TOPLEFT", -2, 40)
    classLabel:SetText("Class")

    -- Class Dropdown (inside Main tab)
    local classDrop = CreateFrame("Frame", "LFGBuddy_ClassDropDown", tabFrames[1], "UIDropDownMenuTemplate")
    classDrop:SetPoint("TOPLEFT", classLabel, "TOPLEFT", -17, -13)
    UIDropDownMenu_SetWidth(classDrop, 80)

	-- Ensure lastClass is valid
	if not LFGBuddyOptions.lastClass and LFGBuddyOptions.classes and #LFGBuddyOptions.classes > 0 then
		LFGBuddyOptions.lastClass = LFGBuddyOptions.classes[1]
	end

	-- Initialize the dropdown buttons
	UIDropDownMenu_Initialize(classDrop, function(self, level, menuList)
		local info = UIDropDownMenu_CreateInfo()

		if LFGBuddyOptions.classes then
			for _, v in ipairs(LFGBuddyOptions.classes) do
				info.text, info.value = v, v
				info.func = function(self)
					UIDropDownMenu_SetSelectedValue(classDrop, self.value)
					UIDropDownMenu_SetText(classDrop, self.value)  -- Update visible text
					LFGBuddyOptions.lastClass = self.value
				end
				info.checked = (v == LFGBuddyOptions.lastClass)
				UIDropDownMenu_AddButton(info)
			end
		end
	end)

	-- Set the selected value and visible text immediately
	UIDropDownMenu_SetSelectedValue(classDrop, LFGBuddyOptions.lastClass)
	UIDropDownMenu_SetText(classDrop, LFGBuddyOptions.lastClass)

	-- Refresh dropdown when clicked (optional, for dynamic updates)
	classDrop:HookScript("OnShow", function()
		UIDropDownMenu_Initialize(classDrop, nil)
	end)
	
	function LFGBuddy.CreateLevelDropdown(name, initialValue, optionKey, parent, anchorTo, xOff, yOff)
		local drop = CreateFrame("Frame", name, parent, "UIDropDownMenuTemplate")
		drop:SetPoint("LEFT", anchorTo, "RIGHT", xOff or 0, yOff or 0)
		UIDropDownMenu_SetWidth(drop, 40)

		UIDropDownMenu_Initialize(drop, function()
			local info = UIDropDownMenu_CreateInfo()
			local playerLevel = UnitLevel("player")
			local minLevel = math.max(1, playerLevel - 8)
			local maxLevel = math.min(60, playerLevel + 8)

			for lvl = minLevel, maxLevel do
				info.text, info.value = tostring(lvl), lvl
				info.func = function(self)
					UIDropDownMenu_SetSelectedValue(drop, self.value)
					LFGBuddyOptions[optionKey] = self.value
				end
				info.checked = (lvl == LFGBuddyOptions[optionKey])
				UIDropDownMenu_AddButton(info)
			end
		end)

		if initialValue then
			UIDropDownMenu_SetSelectedValue(drop, initialValue)
		end

		return drop
	end

	-- Min Level Dropdown + Label
	local minDrop = LFGBuddy.CreateLevelDropdown("LFGBuddy_MinDrop",
		LFGBuddyOptions.minLevel, "minLevel",
		tabFrames[1], classDrop, -27, 0)
	local minLabel = tabFrames[1]:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	minLabel:SetPoint("TOPLEFT", minDrop, "TOPLEFT", 17, 13)
	minLabel:SetFont("Fonts\\FRIZQT__.TTF", 11) 
	minLabel:SetText("Min Level")

	-- Max Level Dropdown + Label
	local maxDrop = LFGBuddy.CreateLevelDropdown("LFGBuddy_MaxDrop",
		LFGBuddyOptions.maxLevel, "maxLevel",
		tabFrames[1], minDrop, -27, 0)
	local maxLabel = tabFrames[1]:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	maxLabel:SetPoint("TOPLEFT", maxDrop, "TOPLEFT", 17, 13)
	maxLabel:SetFont("Fonts\\FRIZQT__.TTF", 11) 
	maxLabel:SetText("Max Level")
	
	-- Message Label
	local msgLabel = tabFrames[1]:CreateFontString(nil,"OVERLAY","GameFontNormal")
	msgLabel:SetPoint("TOPLEFT", classLabel, "BOTTOMLEFT", 0, -35)
	msgLabel:SetFont("Fonts\\FRIZQT__.TTF", 11) 
	msgLabel:SetText("Message")

	-- Message Edit Box
	local messageEdit = CreateFrame("EditBox", "LFGBuddy_MessageEditBox", tabFrames[1], "InputBoxTemplate")
	messageEdit:SetSize(320, 20)
	messageEdit:SetPoint("TOPLEFT", msgLabel, "BOTTOMLEFT", 6, -2)
	messageEdit:SetAutoFocus(false)
	messageEdit:SetText(LFGBuddyOptions.recentSentMessages[1] or "")
	LFGBuddy.messageEdit = messageEdit  -- store globally for helpers

	-- Recent Messages Dropdown
	local messageDrop = CreateFrame("Frame", "LFGBuddy_MessageDropdown", tabFrames[1], "UIDropDownMenuTemplate")
	messageDrop:SetPoint("LEFT", messageEdit, "RIGHT", -18, -3)
	UIDropDownMenu_SetWidth(messageDrop, 10)
	LFGBuddy.messageDrop = messageDrop

	-- Function to refresh dropdown menu
	function LFGBuddy.RefreshMessageDropdown()
		UIDropDownMenu_Initialize(messageDrop, function(self, level)
			local info = UIDropDownMenu_CreateInfo()
			for _, msg in ipairs(LFGBuddyOptions.recentSentMessages or {}) do
				info.text = msg
				info.func = function()
					messageEdit:SetText(msg)
					LFGBuddyOptions.message = msg
				end
				UIDropDownMenu_AddButton(info, level)
			end
		end)
	end
	LFGBuddy.RefreshMessageDropdown() -- initial population
	
	-- Base vertical offset relative to classLabel
	local buttonYOffset = -78
	local buttonSpacing = 5 -- horizontal spacing between buttons
	local buttonWidth, buttonHeight = 60, 22

	-- Refresh /who button
	local refreshBtn = CreateFrame("Button", "LFGBuddy_RefreshButton", tabFrames[1], "UIPanelButtonTemplate")
	refreshBtn:SetSize(buttonWidth, buttonHeight)
	refreshBtn:SetPoint("TOPLEFT", classLabel, "BOTTOMLEFT", -1, buttonYOffset)
	refreshBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	refreshBtn:SetText("Refresh")
	refreshBtn:SetScript("OnClick", function()
		LFGBuddy.ClearMessageFocus()  -- drop focus from message box

		-- Get selected class
		local classStr = string.lower(LFGBuddyOptions.lastClass or UIDropDownMenu_GetSelectedValue(classDrop) or "")
		if classStr == "" then
			LFGBuddy.Print("No class selected for /who query.")
			return
		end

		-- Get selected min/max levels
		local min = UIDropDownMenu_GetSelectedValue(minDrop) or LFGBuddyOptions.minLevel or 1
		local max = UIDropDownMenu_GetSelectedValue(maxDrop) or LFGBuddyOptions.maxLevel or 60

		-- Build base WHO query
		local whoQuery = "c-" .. classStr .. " " .. min .. "-" .. max

		-- Optional: filter by cities if checkbox is checked
		if citiesCheckbox and citiesCheckbox:GetChecked() then
			for _, city in ipairs(LFGBuddyOptions.cities or {}) do
				whoQuery = whoQuery .. ' z-"' .. city .. '"'
			end
		end

		-- Output to chat (instead of Notify)
		LFGBuddy.Print("Sending /who query: " .. whoQuery)

		-- Send the /who query to the server
		SendWho(whoQuery)
		
		LFGBuddyOptions.firstrefresh = true
		LFGBuddy.UpdateButtonStates()
	end)
	
	-- Show Queue button
	local showQueueBtn = CreateFrame("Button", "LFGBuddy_ShowQueueButton", tabFrames[1], "UIPanelButtonTemplate")
	showQueueBtn:SetSize(95, buttonHeight)
	showQueueBtn:SetPoint("LEFT", refreshBtn, "RIGHT", buttonSpacing, 0)
	showQueueBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	showQueueBtn:SetText("Whisper who?")
	
	showQueueBtn:SetScript("OnClick", function()
		LFGBuddy.ClearMessageFocus()
		LFGBuddy.ShowWhisperQueue()
		-- disable if firstrefresh is not true
		LFGBuddyOptions.firstqueue = true
		LFGBuddy.UpdateButtonStates()
	end)
		
	-- Start/Pause toggle button
	local startBtn = CreateFrame("Button", "LFGBuddy_StartPauseButton", tabFrames[1], "UIPanelButtonTemplate")
	startBtn:SetSize(buttonWidth, buttonHeight)
	startBtn:SetPoint("LEFT", showQueueBtn, "RIGHT", 40, 0)
	startBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	startBtn:SetText("Send")
	
	LFGBuddy.UpdateButtonStates()

	startBtn:SetScript("OnClick", function()
		LFGBuddy.ClearMessageFocus()

		-- If we're currently sending -> toggle to Pause
		if LFGBuddy.sending then
			LFGBuddy.sending = false
			startBtn:SetText("Pause")
			LFGBuddy.Print("Whispers paused.",false,true)
			return
		end

		-- Otherwise, we’re starting
		local msg = messageEdit:GetText() or ""
		local minChars = 10
		if #msg < minChars then
			LFGBuddy.Print("Message is too short to send, 10 characters is required.",false,true)
			return
		end

		-- Update recentSentMessages
		LFGBuddyOptions.recentSentMessages = LFGBuddyOptions.recentSentMessages or {}
		for i = #LFGBuddyOptions.recentSentMessages, 1, -1 do
			if LFGBuddyOptions.recentSentMessages[i] == msg then
				table.remove(LFGBuddyOptions.recentSentMessages, i)
			end
		end
		table.insert(LFGBuddyOptions.recentSentMessages, 1, msg)
		while #LFGBuddyOptions.recentSentMessages > 10 do
			table.remove(LFGBuddyOptions.recentSentMessages)
		end
		LFGBuddyOptions.message = msg
		LFGBuddy.RefreshMessageDropdown()

		-- Ensure queue exists
		LFGBuddy.whisperQueue = LFGBuddy.whisperQueue or {}

		-- Pre-filter queue: remove anyone in lockout
		local now = time()
		local filteredQueue = {}
		for _, entry in ipairs(LFGBuddy.whisperQueue) do
			local last = LFGBuddyOptions.recentMessageRecipients[entry.name]
			local lockoutSecs = (LFGBuddyOptions.spamLockoutMins or 10) * 60
			if not last or (now - last) > lockoutSecs or LFGBuddyOptions.ignoreRecipientLockout then
				table.insert(filteredQueue, entry)
			else
				LFGBuddy.Print("Skipping " .. entry.name .. " (lockout active)")
			end
		end

		if #filteredQueue == 0 then
			LFGBuddy.Print("No players to send to after lockout check. Sending cancelled.")
			return
		end

		LFGBuddy.whisperQueue = filteredQueue
		LFGBuddy.sending = true
		LFGBuddy.sendTimer = 0
		
		LFGBuddy.UpdateButtonStates()

		startBtn:SetText("Pause") -- Switch button label
		LFGBuddy.Print("Sending whispers started.",false,true)
	end)


	-- Reset button
	local resetBtn = CreateFrame("Button", "LFGBuddy_ResetButton", tabFrames[1], "UIPanelButtonTemplate")
	resetBtn:SetSize(buttonWidth, buttonHeight)
	resetBtn:SetPoint("LEFT", startBtn, "RIGHT", buttonSpacing, 0)
	resetBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	LFGBuddy.UpdateButtonStates()
	resetBtn:SetText("Reset")
	resetBtn:SetScript("OnClick", function()
		LFGBuddy.ClearMessageFocus()
		LFGBuddy.sending = false
		LFGBuddy.whisperQueue = {}
		if LFGBuddy_StartPauseButton then
			LFGBuddy_StartPauseButton:SetText("Start")
		end
		resetBtn:Disable()
		LFGBuddy.Print("Whisper queue reset.")
	end)
	
	-- Cities Only Checkbox (bare)
	local citiesCheckbox = CreateFrame("CheckButton", "LFGBuddy_CitiesCheckbox", tabFrames[1], "UICheckButtonTemplate")
	citiesCheckbox:SetPoint("LEFT", classLabel, "RIGHT", 200, -22)
	citiesCheckbox:SetSize(20, 20)
	citiesCheckbox:SetChecked(LFGBuddyOptions.queueCitiesOnly or false)

	-- Label next to checkbox
	local citiesLabel = tabFrames[1]:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	citiesLabel:SetPoint("LEFT", citiesCheckbox, "RIGHT", 4, 0) -- 4 pixels to the right of checkbox
	citiesLabel:SetText("Players in cities only")
	citiesLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	-- OnClick handler for checkbox
	citiesCheckbox:SetScript("OnClick", function(self)
		LFGBuddy.ClearMessageFocus()
		LFGBuddy.ToggleQueueCitiesOnly(self:GetChecked())
	end)

    -- OPTIONS TAB
		
	-- "Show on Who" Checkbox
	local showOnWhoCheckbox = CreateFrame("CheckButton", "LFGBuddy_ShowOnWhoCheckbox", tabFrames[2], "UICheckButtonTemplate")
	showOnWhoCheckbox:SetPoint("TOPLEFT", tabFrames[2], "TOPLEFT", -5, 39)
	showOnWhoCheckbox:SetSize(20, 20)
	showOnWhoCheckbox:SetChecked(LFGBuddyOptions.showOnWho or false)

	local showOnWhoLabel = tabFrames[2]:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	showOnWhoLabel:SetPoint("LEFT", showOnWhoCheckbox, "RIGHT", 4, 0)
	showOnWhoLabel:SetText("Show when Who tab is opened")
	showOnWhoLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	showOnWhoCheckbox:SetScript("OnClick", function(self)
		local checked = self:GetChecked()
		LFGBuddy.ToggleShowOnWho(checked)
	end)


	-- "Lock to Who" Checkbox
	local lockToWhoCheckbox = CreateFrame("CheckButton", "LFGBuddy_LockToWhoCheckbox", tabFrames[2], "UICheckButtonTemplate")
	lockToWhoCheckbox:SetPoint("TOPLEFT", showOnWhoCheckbox, "BOTTOMLEFT", 0, -5)
	lockToWhoCheckbox:SetSize(20, 20)
	lockToWhoCheckbox:SetChecked(LFGBuddyOptions.lockToWho or false)

	local lockToWhoLabel = tabFrames[2]:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	lockToWhoLabel:SetPoint("LEFT", lockToWhoCheckbox, "RIGHT", 4, 0)
	lockToWhoLabel:SetText("Snap onto Who tab")
	lockToWhoLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	lockToWhoCheckbox:SetScript("OnClick", function(self)
		local checked = self:GetChecked()
		LFGBuddy.ToggleLockToWho(checked)
	end)
	
	-- "Disable Notifications" Checkbox
	local disableNotificationsCheckbox = CreateFrame("CheckButton", "LFGBuddy_DisableNotificationsCheckbox", tabFrames[2], "UICheckButtonTemplate")
	disableNotificationsCheckbox:SetPoint("TOPLEFT", lockToWhoCheckbox, "BOTTOMLEFT", 0, -5)
	disableNotificationsCheckbox:SetSize(20, 20)
	disableNotificationsCheckbox:SetChecked(LFGBuddyOptions.disableaddonnotifications or false)

	local disableNotificationsLabel = tabFrames[2]:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	disableNotificationsLabel:SetPoint("LEFT", disableNotificationsCheckbox, "RIGHT", 4, 0)
	disableNotificationsLabel:SetText("Disable addon chat notifications")
	disableNotificationsLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	disableNotificationsCheckbox:SetScript("OnClick", function(self)
		LFGBuddyOptions.disableaddonnotifications = self:GetChecked()
		LFGBuddy.Print("Addon chat notifications " .. (self:GetChecked() and "disabled." or "enabled."),false,true)
	end)
	

	-- === Reset Defaults Button ===
	local resetDefaultsBtn = CreateFrame("Button", "LFGBuddy_ResetDefaultsButton", tabFrames[2], "UIPanelButtonTemplate")
	resetDefaultsBtn:SetSize(100, 22)
	resetDefaultsBtn:SetPoint("TOPLEFT", disableNotificationsCheckbox, "BOTTOMLEFT", 0, -18)
	resetDefaultsBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	resetDefaultsBtn:SetText("Reset addon")
	resetDefaultsBtn:SetScript("OnClick", function()
		LFGBuddy.ResetDefaults()
	end)
		
	-- === Reset Recent Recipients Button ===
	local resetRecipientsBtn = CreateFrame("Button", "LFGBuddy_ResetRecipientsButton", tabFrames[2], "UIPanelButtonTemplate")
	resetRecipientsBtn:SetSize(100, 22)
	resetRecipientsBtn:SetPoint("TOPLEFT", resetDefaultsBtn, "BOTTOMLEFT", 200, 22)
	resetRecipientsBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	resetRecipientsBtn:SetText("Reset lockouts")
	resetRecipientsBtn:SetScript("OnClick", function()
		LFGBuddyOptions.recentMessageRecipients = {}
		LFGBuddy.Print("Recent recipients cleared.", false, true)
	end)

	-- === Toggle PvP Zones Checkbox ===
	local togglePvPCheckbox = CreateFrame("CheckButton", "LFGBuddy_TogglePvPCheckbox", tabFrames[2], "UICheckButtonTemplate")
	togglePvPCheckbox:SetPoint("TOPLEFT", showOnWhoCheckbox, "BOTTOMLEFT", 200, 20)
	togglePvPCheckbox:SetSize(20, 20)
	togglePvPCheckbox:SetChecked(LFGBuddyOptions.togglepvpzones or false)

	local togglePvPLabel = tabFrames[2]:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	togglePvPLabel:SetPoint("LEFT", togglePvPCheckbox, "RIGHT", 4, 0)
	togglePvPLabel:SetText("Exclude PvP zones")
	togglePvPLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	togglePvPCheckbox:SetScript("OnClick", function(self)
		LFGBuddyOptions.togglepvpzones = self:GetChecked()
		LFGBuddy.Print("PvP zone filtering " .. (self:GetChecked() and "enabled." or "disabled."), false, true)
	end)

	-- === Ignore Recipient Lockout Checkbox ===
	local ignoreLockoutCheckbox = CreateFrame("CheckButton", "LFGBuddy_IgnoreLockoutCheckbox", tabFrames[2], "UICheckButtonTemplate")
	ignoreLockoutCheckbox:SetPoint("TOPLEFT", togglePvPCheckbox, "BOTTOMLEFT", 0, -5)
	ignoreLockoutCheckbox:SetSize(20, 20)
	ignoreLockoutCheckbox:SetChecked(LFGBuddyOptions.ignoreRecipientLockout or false)

	local ignoreLockoutLabel = tabFrames[2]:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	ignoreLockoutLabel:SetPoint("LEFT", ignoreLockoutCheckbox, "RIGHT", 4, 0)
	ignoreLockoutLabel:SetText("Ignore spam lockouts")
	ignoreLockoutLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	ignoreLockoutCheckbox:SetScript("OnClick", function(self)
		LFGBuddyOptions.ignoreRecipientLockout = self:GetChecked()
		LFGBuddy.Print("Recipient lockout " .. (self:GetChecked() and "ignored." or "respected."), false, true)
	end)

	-- === Spam Lockout Minutes Slider ===
	local spamSlider = CreateFrame("Slider", "LFGBuddy_SpamLockoutSlider", tabFrames[2], "OptionsSliderTemplate")
	spamSlider:SetPoint("TOPLEFT", ignoreLockoutCheckbox, "BOTTOMLEFT", 2, -15)
	spamSlider:SetMinMaxValues(5, 30)
	spamSlider:SetValueStep(1)
	spamSlider:SetWidth(130)
	spamSlider:SetValue(LFGBuddyOptions.spamLockoutMins or 10)

	-- Slider label
	local spamLabel = tabFrames[2]:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	spamLabel:SetPoint("TOPLEFT", spamSlider, "TOPLEFT", 0, 10)
	spamLabel:SetText("Spam lockout minutes: " .. (LFGBuddyOptions.spamLockoutMins or 10))
	spamLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	spamSlider:SetScript("OnValueChanged", function(self, value)
		value = math.floor(value + 0.5) -- round
		LFGBuddyOptions.spamLockoutMins = value
		spamLabel:SetText("Lockout Minutes: " .. value)
	end)



    f:Hide()
    LFGBuddy.frame = f
end

function LFGBuddy.UpdateButtonStates()
    -- Start/Pause button: enabled only if firstrefresh, firstqueue, AND whisperQueue not empty
    if LFGBuddy_StartPauseButton then
        if LFGBuddyOptions.firstrefresh and LFGBuddyOptions.firstqueue and
           LFGBuddy.whisperQueue and #LFGBuddy.whisperQueue > 0 then
            LFGBuddy_StartPauseButton:Enable()
        else
            LFGBuddy_StartPauseButton:Disable()
        end
    end

    -- Reset button: only enabled if sending is active
    if LFGBuddy_ResetButton then
        if LFGBuddy.sending then
            LFGBuddy_ResetButton:Enable()
        else
            LFGBuddy_ResetButton:Disable()
        end
    end

    -- Queue button: enabled if firstrefresh is true
    if LFGBuddy_ShowQueueButton then
        if LFGBuddyOptions.firstrefresh then
            LFGBuddy_ShowQueueButton:Enable()
        else
            LFGBuddy_ShowQueueButton:Disable()
        end
    end
end

-- =========================
-- Show Current Settings
-- =========================
function LFGBuddy.ShowSettings()
    LFGBuddy.Print("Settings:",false,true)
    LFGBuddy.Print("  loadOnLogin = " .. (LFGBuddyOptions.loadOnLogin and "ENABLED" or "DISABLED"),false,true)
    LFGBuddy.Print("  showOnWho = " .. (LFGBuddyOptions.showOnWho and "ENABLED" or "DISABLED"),false,true)
    LFGBuddy.Print("  lockToWho = " .. (LFGBuddyOptions.lockToWho and "ENABLED" or "DISABLED"),false,true)
    LFGBuddy.Print("  queueCitiesOnly = " .. (LFGBuddyOptions.queueCitiesOnly and "ENABLED" or "DISABLED"),false,true)
    LFGBuddy.Print("  ignorezones = " .. (#LFGBuddyOptions.ignoreZones > 0 and table.concat(LFGBuddyOptions.ignoreZones, ", ") or "None"),false,true)
    LFGBuddy.Print("  cities = " .. (#LFGBuddyOptions.cities > 0 and table.concat(LFGBuddyOptions.cities, ", ") or "None"),false,true)
    LFGBuddy.Print("  classes = " .. (#LFGBuddyOptions.classes > 0 and table.concat(LFGBuddyOptions.classes, ", ") or "None"),false,true)
    LFGBuddy.Print("Commands:",false,true)
    LFGBuddy.Print("  /lb login on/off   - Toggle auto-login",false,true)
    LFGBuddy.Print("  /lb show           - Show GUI",false,true)
    LFGBuddy.Print("  /lb reset          - Addon reset to defaults",false,true)
    LFGBuddy.Print("  /lb switchfaction          - Change faction capitals",false,true)
    LFGBuddy.Print("  /lb addclass <Class Name> - Add a class",false,true)
    LFGBuddy.Print("  /lb removeclass <Class Name> - Remove a class",false,true)
    LFGBuddy.Print("  /lb ignorezones - Print ignorelist",false,true)
    LFGBuddy.Print("  /lb addzone <Zone Name> - Add a zone to ignorelist",false,true)
    LFGBuddy.Print("  /lb removezone <Zone Name> - Remove a zone from ignorelist",false,true)
    LFGBuddy.Print("  /lb showonwho on/off - Toggle auto-show on Who tab",false,true)
    LFGBuddy.Print("  /lb locktowho on/off - Snap and lock onto on Who tab",false,true)
    LFGBuddy.Print("  /lb whisperqueue - List of all players currently in whisperqueue",false,true)
    LFGBuddy.Print("  /lb whisperqueuecitiesonly - When whisperqueue is updated include only players in a city zone",false,true)
    LFGBuddy.Print("  /lb                - Show this help",false,true)
end

-- =========================
-- Slash Commands
-- =========================
SLASH_LFGBUDDY1 = "/lb"
SlashCmdList["LFGBUDDY"] = function(msg)
    msg = msg or ""
    local command, arg = msg:match("^(%S*)%s*(.-)$")
    command = command:lower()
    arg = arg:lower()

    if command == "show" then
		LFGBuddyUI()
		LFGBuddy.frame:Show()
    elseif command == "reset" then
        LFGBuddy.ResetDefaults()
	elseif command == "switchfaction" then
    LFGBuddy.ToggleCities()
	elseif command == "addclass" and arg ~= "" then
		local success, msg = LFGBuddy.AddClass(arg)
		LFGBuddy.Print(msg)
	elseif command == "removeclass" and arg ~= "" then
		local success, msg = LFGBuddy.RemoveClass(arg)
		LFGBuddy.Print(msg)
	elseif command == "ignorezones" then
		LFGBuddy.PrintIgnoreZones()
	elseif command == "addzone" and arg ~= "" then
		LFGBuddy.AddIgnoreZone(arg)
	elseif command == "removezone" and arg ~= "" then
		LFGBuddy.RemoveIgnoreZone(arg)
    elseif command == "showonwho" then
        if arg == "on" then
            LFGBuddy.ToggleShowOnWho(true)
        elseif arg == "off" then
            LFGBuddy.ToggleShowOnWho(false)
        else
            LFGBuddy.Print("showOnWho is " .. (LFGBuddyOptions.showOnWho and "ENABLED" or "DISABLED"),false,true)
        end
	elseif command == "locktowho" then
    if arg == "on" then
        LFGBuddy.ToggleLockToWho(true)
    elseif arg == "off" then
        LFGBuddy.ToggleLockToWho(false)
    else
        LFGBuddy.Print("lockToWho is " .. (LFGBuddyOptions.lockToWho and "ENABLED" or "DISABLED"),false,true)
    end
	elseif command == "whisperqueue" then
		LFGBuddy.ShowWhisperQueue()
	elseif command == "whisperqueuecitiesonly" then
    if arg == "on" then
        LFGBuddy.ToggleQueueCitiesOnly(true)
    elseif arg == "off" then
        LFGBuddy.ToggleQueueCitiesOnly(false)
    else
        LFGBuddy.Print("Queue only in cities is " .. (LFGBuddyOptions.queueCitiesOnly and "ENABLED" or "DISABLED"),false,true)
    end
    else
        LFGBuddy.ShowSettings()
    end
end

-- =========================
-- Event Handling
-- =========================
local addonFrame = CreateFrame("Frame")
addonFrame:RegisterEvent("ADDON_LOADED")
addonFrame:SetScript("OnEvent", function(self, event, addonName)
    if event == "ADDON_LOADED" and addonName == ADDON_NAME then
        LFGBuddy.OnFirstLoad()
    end
end)

-- Who updates
local whoEventFrame = CreateFrame("Frame")
whoEventFrame:RegisterEvent("WHO_LIST_UPDATE")
whoEventFrame:SetScript("OnEvent", function(_, event)
    if event == "WHO_LIST_UPDATE" then
        if LFGBuddy.frame and LFGBuddy.frame:IsShown() then
            LFGBuddy.UpdateWhisperQueue()
        end
    end
end)

local saveFramePos = CreateFrame("Frame")
saveFramePos:RegisterEvent("PLAYER_LOGOUT")
saveFramePos:SetScript("OnEvent", function()
	if LFGBuddy.frame then
		-- Get current position in relation to UIParent
		local x, y = LFGBuddy.frame:GetCenter()
		if x and y then
			LFGBuddyOptions.framePoint = "CENTER"
			LFGBuddyOptions.frameRelativePoint = "CENTER"
			LFGBuddyOptions.frameX = x - (UIParent:GetWidth() / 2)
			LFGBuddyOptions.frameY = y - (UIParent:GetHeight() / 2)
		end
	end
end)
