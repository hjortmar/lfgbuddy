-- Main.lua
local ADDON_NAME, LFGBuddy = ...

local LFGBUDDY_DEFAULT_IGNORE_ZONES = {
    "Baradin Hold","Ragefire Chasm","Wailing Caverns","The Deadmines","Shadowfang Keep",
    "Blackfathom Deeps","Stormwind Stockade","The Stockades","Gnomeregan","Razorfen Kraul",
    "Scarlet Monastery","Razorfen Downs","Uldaman","Zul'Farrak","Maraudon",
    "Sunken Temple","Temple of Atal'Hakkar","The Temple of Atal'Hakkar","Blackrock Depths","Blackrock Spire",
    "Tol Barad","Lower Blackrock Spire","Upper Blackrock Spire","Scholomance","Stratholme","Blackrock Mountain",
}

-- Kept local for initialization ONLY
local LFGBUDDY_DEFAULT_PVP_ZONES = {"Warsong Gulch","Arathi Basin","Alterac Valley"}

local DEFAULT_HORDE_CITIES = {"Orgrimmar", "Undercity", "Thunder Bluff","Silvermoon"}

local DEFAULT_ALLIANCE_CITIES = {"Stormwind", "Ironforge", "Darnassus", "Exodar"}

local LFGBUDDY_DEFAULT_CLASSES = {"Shaman","Paladin","Druid","Warrior","Warlock","Priest","Rogue","Mage","Hunter"}

-- =========================
-- Options stored in WTF
-- =========================
LFGBuddyOptions = LFGBuddyOptions or {}

-- =========================
-- Initialization
-- =========================
function LFGBuddy.OnFirstLoad()
    if not LFGBuddyOptions.initialized then
        -- ignore zones
        LFGBuddyOptions.ignoreZones = {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_IGNORE_ZONES) do
            table.insert(LFGBuddyOptions.ignoreZones, name)
        end
		
        -- ignore zones: Uses the local variable to populate the OPTIONS table
        LFGBuddyOptions.ignorePvPZones = {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_PVP_ZONES) do
            table.insert(LFGBuddyOptions.ignorePvPZones, name)
        end

		local playerFaction = UnitFactionGroup("player")
		LFGBuddyOptions.cities = (playerFaction == "Horde") and DEFAULT_HORDE_CITIES or DEFAULT_ALLIANCE_CITIES

        -- classes
        LFGBuddyOptions.classes = {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_CLASSES) do
            table.insert(LFGBuddyOptions.classes, name)
        end
		
		if #LFGBuddyOptions.classes > 0 then LFGBuddyOptions.lastClass = LFGBuddyOptions.classes[1] end

        -- Init min/max levels
        local lvl = UnitLevel("player")
        LFGBuddyOptions.minLevel = lvl -- Defaults to player level
        LFGBuddyOptions.maxLevel = math.min(60, lvl + 8)

        -- flags
        -- LFGBuddyOptions.showOnWho removed
        -- LFGBuddyOptions.lockToWho removed
        LFGBuddyOptions.queueCitiesOnly = false
		LFGBuddyOptions.recentSentMessages = {}
		LFGBuddyOptions.recentMessageRecipients = {}
		LFGBuddyOptions.ignoreRecipientLockout = false
		LFGBuddyOptions.spamInterval = 1.2
		LFGBuddyOptions.spamLockoutMins = 30
		LFGBuddyOptions.togglepvpzones = true
		-- LFGBuddyOptions.firstrefresh removed
		-- LFGBuddyOptions.firstqueue removed
		LFGBuddyOptions.disableaddonnotifications = false
		LFGBuddyOptions.autoPauseCount = 50 -- New default for auto-pause
        LFGBuddyOptions.initialized = true

        print("|cff33ff99LFGBuddy:|r Initialized with default ignorezones, cities, and classes.")
    end
	
    -- Runtime state (reset every reload/UI load)
    LFGBuddy.whisperQueue = {}
	LFGBuddy.excludedPlayers = {} -- New: To track players excluded during refresh
    LFGBuddy.sendTimer = 0
    LFGBuddy.sending = false
	LFGBuddy.whispersSentSinceStart = 0 -- New: Counter for auto-pause
end

-- Reset everything to defaults
function LFGBuddy.ResetDefaults()
    LFGBuddyOptions = {}
	LFGBuddyOptions.initialized = false
    LFGBuddy.OnFirstLoad()
	LFGBuddy.UpdateButtonStates()
    print("|cff33ff99LFGBuddy:|r Defaults restored.")
end

function LFGBuddy.Print(msg, raw, force)
    -- If notifications are disabled and force is not set, stop
    if LFGBuddyOptions.disableaddonnotifications and not force then
        return
    end

    local text = tostring(msg or "")

    if not raw then
        text = "|cff33ff99LFGBuddy:|r " .. text
    end

    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage(text)
    else
        print(text)  -- fallback in case chat frame isn't available
    end
end

-- =========================
-- Classes (kept for completeness)
-- =========================
-- Adds a class to the list
function LFGBuddy.AddClass(className)
    if not className or className == "" then
        return false, "Invalid class name."
    end

    LFGBuddyOptions.classes = LFGBuddyOptions.classes or {}

    for _, existing in ipairs(LFGBuddyOptions.classes) do
        if existing:lower() == className:lower() then
            return false, "Class '" .. className .. "' already exists."
        end
    end

    table.insert(LFGBuddyOptions.classes, className)
    return true, "Class '" .. className .. "' added."
end

-- Removes a class from the list
function LFGBuddy.RemoveClass(className)
    if not className or className == "" then
        return false, "Invalid class name."
    end

    if not LFGBuddyOptions.classes or #LFGBuddyOptions.classes == 0 then
        return false, "No classes defined."
    end

    for i, existing in ipairs(LFGBuddyOptions.classes) do
        if existing:lower() == className:lower() then
            table.remove(LFGBuddyOptions.classes, i)
            return true, "Class '" .. className .. "' removed."
        end
    end

    return false, "Class '" .. className .. "' not found."
end

-- =========================
-- Switch between faction capitals.
-- =========================
function LFGBuddy.ToggleCities()
    local isHorde = false
    for _, city in ipairs(LFGBuddyOptions.cities) do
        if city == "Orgrimmar" then
            isHorde = true
            break
        end
    end

    if isHorde then
        LFGBuddyOptions.cities = DEFAULT_ALLIANCE_CITIES
		LFGBuddy.Print("Switched to Alliance cities, if active, only players in these cities will be included in the whisperqueue.")
    else
        LFGBuddyOptions.cities = DEFAULT_HORDE_CITIES
        LFGBuddy.Print("Switched to Horde cities, if active, only players in these cities will be included in the whisperqueue.")
    end
	
	LFGBuddy.PrintCities()
	
end


-- =========================
-- Add and remove ignorezones. (kept for completeness)
-- =========================
function LFGBuddy.PrintIgnoreZones()
    if not LFGBuddyOptions.ignoreZones or #LFGBuddyOptions.ignoreZones == 0 then
        LFGBuddy.Print("No ignore zones have been set.", false, true)
        return
    end

    LFGBuddy.Print("Ignore zones:", false, true)
    for i, zone in ipairs(LFGBuddyOptions.ignoreZones) do
        LFGBuddy.Print("  " .. zone, true, true)
    end
	LFGBuddy.Print("If players are in any of the zones above, they will not be included in the whisperqueue.", false, true)
end

function LFGBuddy.PrintCities()
    if not LFGBuddyOptions.cities or #LFGBuddyOptions.cities == 0 then
        LFGBuddy.Print("No cities have been set.", false, true)
        return
    end

    for i, city in ipairs(LFGBuddyOptions.cities) do
        LFGBuddy.Print("  " .. city, true, true)
    end
end

function LFGBuddy.PrintPvPZones()
    -- FIX: Check and print LFGBuddyOptions.ignorePvPZones
    if not LFGBuddyOptions.ignorePvPZones or #LFGBuddyOptions.ignorePvPZones == 0 then
        LFGBuddy.Print("No PvP zones have been set.", false, true)
        return
    end

    LFGBuddy.Print("PvP zones (excluded option is enabled):", false, true)
    for i, zone in ipairs(LFGBuddyOptions.ignorePvPZones) do
        LFGBuddy.Print("  " .. zone, true, true)
    end
end

function LFGBuddy.AddIgnoreZone(zoneName)
    if not zoneName or zoneName == "" then return end
    LFGBuddyOptions.ignoreZones = LFGBuddyOptions.ignoreZones or {}

    local lowerZone = zoneName:lower()
    for _, existing in ipairs(LFGBuddyOptions.ignoreZones) do
        if existing:lower() == lowerZone then
            LFGBuddy.Print("Zone '" .. zoneName .. "' is already in ignore list.")
            return
        end
    end

    table.insert(LFGBuddyOptions.ignoreZones, zoneName)
    LFGBuddy.Print("Zone '" .. zoneName .. "' added to ignore list.")
end

-- Remove a zone from ignoreZones
function LFGBuddy.RemoveIgnoreZone(zoneName)
    if not zoneName or zoneName == "" then return end
    if not LFGBuddyOptions.ignoreZones then return end

    local lowerZone = zoneName:lower()
    for i, existing in ipairs(LFGBuddyOptions.ignoreZones) do
        if existing:lower() == lowerZone then
            table.remove(LFGBuddyOptions.ignoreZones, i)
            LFGBuddy.Print("Zone '" .. existing .. "' removed from ignore list.")
            return
        end
    end

    LFGBuddy.Print("Zone '" .. zoneName .. "' not found in ignore list.")
end

-- =========================
-- Who Frame Interaction (Simplified)
-- =========================

-- Helper: snap LFGBuddy to WhoFrame
local function SnapToWhoFrame()
    if LFGBuddy.frame and WhoFrame then
        LFGBuddy.frame:StopMovingOrSizing()
        LFGBuddy.frame:ClearAllPoints()
        LFGBuddy.frame:SetPoint("TOPLEFT", WhoFrame, "TOPRIGHT", -35, -13)
        LFGBuddy.frame:SetMovable(false)
        LFGBuddy.frame:EnableMouse(false)
    end
end

-- Show/hide frame when Who tab opens/closes (simplified)
local function WhoFrame_OnShowHook()
    LFGBuddyUI()
    LFGBuddy.frame:Show()
    LFGBuddyOptionsUI() -- Ensure options frame exists to check button state
	SnapToWhoFrame() -- Always snap
end

local function WhoFrame_OnHideHook()
    if LFGBuddy.frame then
        LFGBuddy.frame:Hide()
    end
	if LFGBuddyOptionsFrame then
		LFGBuddyOptionsFrame:Hide()
		LFGBuddyOptionsFrame_OptionsButton:UnlockHighlight()
		LFGBuddyOptionsFrame_OptionsButton.fontString:SetTextColor(1, 1, 1) -- White
	end
end

-- Hook safely
if WhoFrame then
    WhoFrame:HookScript("OnShow", WhoFrame_OnShowHook)
    WhoFrame:HookScript("OnHide", WhoFrame_OnHideHook)
end


-- Check if a zone is one of the default cities
local function isZoneInDefaultCities(zone)
    for _, city in ipairs(LFGBuddyOptions.cities) do
        if city == zone then return true end
    end
    return false
end

-- Check if a zone is ignored
local function isZoneIgnored(zone)
    for _, ignored in ipairs(LFGBuddyOptions.ignoreZones) do
        if ignored == zone then return true end
    end
    return false
end

-- Check if a zone is ignored
local function isPvPZoneIgnored(zone)
    -- FIX: Use LFGBuddyOptions.ignorePvPZones for filtering
    for _, ignored in ipairs(LFGBuddyOptions.ignorePvPZones or {}) do 
        if ignored == zone then return true end
    end
    return false
end


function LFGBuddy.ToggleQueueCitiesOnly(enable)
    LFGBuddyOptions.queueCitiesOnly = enable
    LFGBuddy.Print("Adding only players in cities to queue " .. (enable and "ENABLED." or "DISABLED."))
end

function LFGBuddy.UpdateWhisperQueue()
    LFGBuddy.whisperQueue = {}
	LFGBuddy.excludedPlayers = {} -- Reset excluded list
    local now = time()
    local lockoutSeconds = (LFGBuddyOptions.spamLockoutMins or 30) * 60  -- convert minutes to seconds
    local n = GetNumWhoResults()

    for i = 1, n do
        local name, guild, level, race, class, zone = GetWhoInfo(i)
        if name and name ~= UnitName("player") then
            local include = true
			local excludeReason = nil

			if LFGBuddyOptions.queueCitiesOnly then
				-- Only keep players in default cities
				if not isZoneInDefaultCities(zone) then
					include = false
					excludeReason = "not in a city"
				end
			else
				-- Exclude players in ignored zones
				if isZoneIgnored(zone) then
					include = false
					excludeReason = "Ignored zone: " .. zone
				end

				-- Exclude players in PvP zones if toggle is active
				if include and LFGBuddyOptions.togglepvpzones and isPvPZoneIgnored(zone) then
					include = false
					excludeReason = "PvP zone: " .. zone
				end
			end

            -- Skip players who are on the Blizzard ignore list
            if include and IsIgnored(name) then
                include = false
                excludeReason = "player ignored"
            end

            -- Skip players who are recent recipients (lockout)
            local lastSent = LFGBuddyOptions.recentMessageRecipients[name]
            if include and lastSent and not LFGBuddyOptions.ignoreRecipientLockout then
                if now - lastSent <= lockoutSeconds then
                    include = false
                    excludeReason = "Spam lockout active"
                end
            end

            if include then
                table.insert(LFGBuddy.whisperQueue, {name=name, level=level, class=class, zone=zone})
            else
				table.insert(LFGBuddy.excludedPlayers, {name=name, reason=excludeReason or "Unknown Reason"})
            end
        end
    end

    if #LFGBuddy.whisperQueue == 0 then
        LFGBuddy.Print("No players to whisper after filtering.")
    else
        LFGBuddy.Print("Queued " .. #LFGBuddy.whisperQueue .. " whispers.")
    end

    LFGBuddy.UpdateButtonStates()
end

function LFGBuddy.ShowWhisperQueue()
	-- Only print to chat if notifications are enabled OR if this is a force print via slash command
	local isChatNotifEnabled = true -- MODIFIED: Always set to true to force print when the button is pressed.
	
	if #LFGBuddy.excludedPlayers > 0 then
		LFGBuddy.Print("--- Excluded Players (" .. #LFGBuddy.excludedPlayers .. ") ---", false, isChatNotifEnabled)
		for _, entry in ipairs(LFGBuddy.excludedPlayers) do
			-- NEW FORMATTING LOGIC: Reformat the reason based on the content
			local reasonText = entry.reason or "Unknown Reason"
			
			-- Check for the specific "Ignored Zone" format
			local zoneName = reasonText:match("Ignored Zone: (.+)")
			if zoneName then
				-- Change "Ignored Zone: Baradin Hold" to "Baradin Hold (ignored zone)"
				reasonText = string.format("%s (ignored zone)", zoneName)
			else
				-- Check for the specific "PvP Zone" format
				local pvpZoneName = reasonText:match("PvP Zone: (.+)")
				if pvpZoneName then
					-- Change "PvP Zone: Warsong Gulch" to "Warsong Gulch (PvP zone)"
					reasonText = string.format("%s (PvP zone)", pvpZoneName)
				end
				-- Other reasons like "Not in a designated city" or "Blizzard Ignore List" remain as is.
			end

			LFGBuddy.Print(string.format("  %s - Reason: %s", entry.name, reasonText), true, isChatNotifEnabled)
		end
	end

	if not LFGBuddy.whisperQueue or #LFGBuddy.whisperQueue == 0 then
		LFGBuddy.Print("Whisperqueue is empty.", false, isChatNotifEnabled)
		return
	end

	LFGBuddy.Print("--- Whisperqueue (" .. #LFGBuddy.whisperQueue .. ") ---", false, isChatNotifEnabled)
	for i, entry in ipairs(LFGBuddy.whisperQueue) do
		LFGBuddy.Print(string.format("  %s - %s %s %s", entry.name, entry.level, entry.class, entry.zone),true, isChatNotifEnabled)
	end
	
	LFGBuddy.Print("Queued " .. #LFGBuddy.whisperQueue .. " whispers.", false, isChatNotifEnabled)
end

-- Whisper pacing
local eventFrame = CreateFrame("Frame")
eventFrame:SetScript("OnUpdate", function(self, elapsed)
    if LFGBuddy.sending then
        LFGBuddy.sendTimer = (LFGBuddy.sendTimer or 0) + elapsed
        if LFGBuddy.sendTimer >= (LFGBuddyOptions.spamInterval or 1.0) then
            LFGBuddy.sendTimer = 0
            local entry = tremove(LFGBuddy.whisperQueue, 1)
            if entry then
                local now = time()
                local last = LFGBuddyOptions.recentMessageRecipients[entry.name]
                -- Re-check lockout just in case (e.g. settings changed while sending)
                local lockoutSecs = (LFGBuddyOptions.spamLockoutMins or 30) * 60
                if not last or (now - last) > lockoutSecs or LFGBuddyOptions.ignoreRecipientLockout then
                    local msg = LFGBuddy.messageEdit:GetText() or ""
                    SendChatMessage(msg, "WHISPER", nil, entry.name)
                    LFGBuddyOptions.recentMessageRecipients[entry.name] = now
					LFGBuddy.whispersSentSinceStart = LFGBuddy.whispersSentSinceStart + 1 -- Increment counter

					-- Check for auto-pause
					if LFGBuddy.whispersSentSinceStart >= (LFGBuddyOptions.autoPauseCount or 50) then
						LFGBuddy.sending = false
						if LFGBuddy_StartPauseButton then
							LFGBuddy_StartPauseButton:SetText("Send")
						end
						LFGBuddy.Print("|cffFF0000Auto-paused:|r Reached " .. (LFGBuddyOptions.autoPauseCount or 50) .. " whispers.",false,true)
						LFGBuddy.UpdateButtonStates()
						return -- Stop sending immediately
					end

                else
                    LFGBuddy.Print("Skipped " .. entry.name .. " (lockout active)")
                end
            else
                LFGBuddy.sending = false
                if LFGBuddy_StartPauseButton then
                    LFGBuddy_StartPauseButton:SetText("Send") -- reset the button
                end
                LFGBuddy.Print("Whispers sent to all in queue.",false,true)
				LFGBuddy.UpdateButtonStates()
            end
        end
    end
end)

function LFGBuddy.ClearMessageFocus()
    if LFGBuddy.messageEdit and LFGBuddy.messageEdit:HasFocus() then
        LFGBuddy.messageEdit:ClearFocus()
    end
end

-- =========================
-- GUI (Main Frame - Simplified, no tabs, no title/separator)
-- =========================

function LFGBuddyUI()
    if LFGBuddy.frame then return end
	
    local f = CreateFrame("Frame", "LFGBuddyFrame", UIParent)
    f:SetSize(367, 110)
    f:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        edgeSize = 10
    })
    f:ClearAllPoints()
	if LFGBuddyOptions.framePoint then
		f:SetPoint(
			LFGBuddyOptions.framePoint,
			UIParent,
			LFGBuddyOptions.frameRelativePoint,
			LFGBuddyOptions.frameX,
			LFGBuddyOptions.frameY
		)
	else
		f:SetPoint("CENTER")
	end
	f:SetScript("OnDragStart", f.StartMoving) 
	f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetBackdropColor(0,0,0,0.8)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")

    -- Options "Label" Button (replaces the tab)
    local optionsBtn = CreateFrame("Button", "LFGBuddyOptionsFrame_OptionsButton", f)
	optionsBtn:SetSize(45, 16)
	optionsBtn:SetPoint("TOPRIGHT", f, "TOPRIGHT", -5, -3) -- Anchored top right
	
	-- Create a font string for the button
	local fontString = optionsBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	fontString:SetText("Options")
	fontString:SetAllPoints(optionsBtn)
	fontString:SetFont("Fonts\\FRIZQT__.TTF", 10)
	fontString:SetTextColor(1, 1, 1) -- Default white color
	optionsBtn.fontString = fontString

	optionsBtn:SetScript("OnClick", function()
		LFGBuddyOptionsUI()
		if LFGBuddyOptionsFrame:IsShown() then
			LFGBuddyOptionsFrame:Hide()
			optionsBtn:UnlockHighlight()
			fontString:SetTextColor(1, 1, 1) -- White
		else
			LFGBuddyOptionsFrame:Show()
			optionsBtn:LockHighlight()
			fontString:SetTextColor(1.0, 0.82, 0.0) -- Blizzard Gold
		end
	end)
	
	-- Main Content Panel (replaces the first tab frame)
	local mainPanel = CreateFrame("Frame", nil, f)
	mainPanel:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -45)
	mainPanel:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -10, 10)
	
    -- Class Label
    local classLabel = mainPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	classLabel:SetFont("Fonts\\FRIZQT__.TTF", 11) 
    classLabel:SetPoint("TOPLEFT", mainPanel, "TOPLEFT", -2, 40)
    classLabel:SetText("Class")

    -- Class Dropdown
    local classDrop = CreateFrame("Frame", "LFGBuddy_ClassDropDown", mainPanel, "UIDropDownMenuTemplate")
    classDrop:SetPoint("TOPLEFT", classLabel, "TOPLEFT", -17, -13)
    UIDropDownMenu_SetWidth(classDrop, 80)

	-- Ensure lastClass is valid
	if not LFGBuddyOptions.lastClass and LFGBuddyOptions.classes and #LFGBuddyOptions.classes > 0 then
		LFGBuddyOptions.lastClass = LFGBuddyOptions.classes[1]
	end

	-- Initialize the dropdown buttons
	UIDropDownMenu_Initialize(classDrop, function(self, level, menuList)
		local info = UIDropDownMenu_CreateInfo()

		if LFGBuddyOptions.classes then
			for _, v in ipairs(LFGBUDDY_DEFAULT_CLASSES) do -- Using default classes here ensures consistency if a custom one is added and then removed
				info.text, info.value = v, v
				info.func = function(self)
					UIDropDownMenu_SetSelectedValue(classDrop, self.value)
					UIDropDownMenu_SetText(classDrop, self.value)
					LFGBuddyOptions.lastClass = self.value
				end
				info.checked = (v == LFGBuddyOptions.lastClass)
				UIDropDownMenu_AddButton(info)
			end
			-- Re-add any custom classes that might not be in the default list but are in the options
			for _, v in ipairs(LFGBuddyOptions.classes) do
				local isDefault = false
				for _, def in ipairs(LFGBUDDY_DEFAULT_CLASSES) do
					if v == def then isDefault = true; break end
				end
				if not isDefault then
					info.text, info.value = v, v
					info.func = function(self)
						UIDropDownMenu_SetSelectedValue(classDrop, self.value)
						UIDropDownMenu_SetText(classDrop, self.value)
						LFGBuddyOptions.lastClass = self.value
					end
					info.checked = (v == LFGBuddyOptions.lastClass)
					UIDropDownMenu_AddButton(info)
				end
			end
		end
	end)

	-- Set the selected value and visible text immediately
	UIDropDownMenu_SetSelectedValue(classDrop, LFGBuddyOptions.lastClass)
	UIDropDownMenu_SetText(classDrop, LFGBuddyOptions.lastClass)

	-- Refresh dropdown when clicked
	classDrop:HookScript("OnShow", function()
		UIDropDownMenu_Initialize(classDrop, nil)
	end)
	
	function LFGBuddy.CreateLevelDropdown(name, initialValue, optionKey, parent, anchorTo, xOff, yOff)
		local drop = CreateFrame("Frame", name, parent, "UIDropDownMenuTemplate")
		drop:SetPoint("LEFT", anchorTo, "RIGHT", xOff or 0, yOff or 0)
		UIDropDownMenu_SetWidth(drop, 40)

		UIDropDownMenu_Initialize(drop, function()
			local info = UIDropDownMenu_CreateInfo()
			local playerLevel = UnitLevel("player")
			local minLevel = math.max(1, playerLevel - 8)
			local maxLevel = math.min(60, playerLevel + 8)

			for lvl = minLevel, maxLevel do
				info.text, info.value = tostring(lvl), lvl
				info.func = function(self)
					UIDropDownMenu_SetSelectedValue(drop, self.value)
					LFGBuddyOptions[optionKey] = self.value
				end
				info.checked = (lvl == LFGBuddyOptions[optionKey])
				UIDropDownMenu_AddButton(info)
			end
		end)

		-- Update initial value based on current option
		UIDropDownMenu_SetSelectedValue(drop, LFGBuddyOptions[optionKey] or initialValue)

		return drop
	end

	-- Min Level Dropdown + Label
	local minDrop = LFGBuddy.CreateLevelDropdown("LFGBuddy_MinDrop",
		LFGBuddyOptions.minLevel, "minLevel",
		mainPanel, classDrop, -27, 0)
	local minLabel = mainPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	minLabel:SetPoint("TOPLEFT", minDrop, "TOPLEFT", 17, 13)
	minLabel:SetFont("Fonts\\FRIZQT__.TTF", 11) 
	minLabel:SetText("Min Level")

	-- Max Level Dropdown + Label
	local maxDrop = LFGBuddy.CreateLevelDropdown("LFGBuddy_MaxDrop",
		LFGBuddyOptions.maxLevel, "maxLevel",
		mainPanel, minDrop, -27, 0)
	local maxLabel = mainPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	maxLabel:SetPoint("TOPLEFT", maxDrop, "TOPLEFT", 17, 13)
	maxLabel:SetFont("Fonts\\FRIZQT__.TTF", 11) 
	maxLabel:SetText("Max Level")
	
	-- Message Label
	local msgLabel = mainPanel:CreateFontString(nil,"OVERLAY","GameFontNormal")
	msgLabel:SetPoint("TOPLEFT", classLabel, "BOTTOMLEFT", 0, -30)
	msgLabel:SetFont("Fonts\\FRIZQT__.TTF", 11) 
	msgLabel:SetText("Message")

	-- Message Edit Box
	local messageEdit = CreateFrame("EditBox", "LFGBuddy_MessageEditBox", mainPanel, "InputBoxTemplate")
	messageEdit:SetSize(320, 20)
	messageEdit:SetPoint("TOPLEFT", msgLabel, "BOTTOMLEFT", 6, -2)
	messageEdit:SetAutoFocus(false)
	messageEdit:SetText(LFGBuddyOptions.recentSentMessages[1] or "")
	LFGBuddy.messageEdit = messageEdit

	-- Recent Messages Dropdown
	local messageDrop = CreateFrame("Frame", "LFGBuddy_MessageDropdown", mainPanel, "UIDropDownMenuTemplate")
	messageDrop:SetPoint("LEFT", messageEdit, "RIGHT", -18, -3)
	UIDropDownMenu_SetWidth(messageDrop, 10)
	LFGBuddy.messageDrop = messageDrop

	-- Function to refresh dropdown menu
	function LFGBuddy.RefreshMessageDropdown()
		UIDropDownMenu_Initialize(messageDrop, function(self, level)
			local info = UIDropDownMenu_CreateInfo()
			for _, msg in ipairs(LFGBuddyOptions.recentSentMessages or {}) do
				info.text = msg
				info.func = function()
					messageEdit:SetText(msg)
					LFGBuddyOptions.message = msg
				end
				UIDropDownMenu_AddButton(info, level)
			end
		end)
	end
	LFGBuddy.RefreshMessageDropdown()
	
	-- Base vertical offset relative to classLabel
	local buttonYOffset = -65
	local buttonSpacing = 5
	local buttonWidth, buttonHeight = 60, 22
	local largeButtonWidth = 95

	-- Refresh /who button
	local refreshBtn = CreateFrame("Button", "LFGBuddy_RefreshButton", mainPanel, "UIPanelButtonTemplate")
	refreshBtn:SetSize(buttonWidth, buttonHeight)
	refreshBtn:SetPoint("TOPLEFT", classLabel, "BOTTOMLEFT", -1, buttonYOffset)
	refreshBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	refreshBtn:SetText("Refresh")
	refreshBtn:SetScript("OnClick", function()
		LFGBuddy.ClearMessageFocus()

		local classStr = string.lower(LFGBuddyOptions.lastClass or UIDropDownMenu_GetSelectedValue(classDrop) or "")
		if classStr == "" then
			LFGBuddy.Print("No class selected for /who query.")
			return
		end

		local min = UIDropDownMenu_GetSelectedValue(minDrop) or LFGBuddyOptions.minLevel or 1
		local max = UIDropDownMenu_GetSelectedValue(maxDrop) or LFGBuddyOptions.maxLevel or 60

		local whoQuery = "c-" .. classStr .. " " .. min .. "-" .. max

		if LFGBuddyOptions.queueCitiesOnly then
			for _, city in ipairs(LFGBuddyOptions.cities or {}) do
				whoQuery = whoQuery .. ' z-"' .. city .. '"'
			end
		end

		LFGBuddy.Print("Sending /who query: " .. whoQuery)

		SendWho(whoQuery)
		LFGBuddy.UpdateButtonStates()
	end)
	
	-- Show Queue button
	local showQueueBtn = CreateFrame("Button", "LFGBuddy_ShowQueueButton", mainPanel, "UIPanelButtonTemplate")
	showQueueBtn:SetSize(largeButtonWidth, buttonHeight)
	showQueueBtn:SetPoint("LEFT", refreshBtn, "RIGHT", buttonSpacing, 0)
	showQueueBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	showQueueBtn:SetText("Whisper who?")
	
	showQueueBtn:SetScript("OnClick", function()
		LFGBuddy.ClearMessageFocus()
		LFGBuddy.ShowWhisperQueue()
		LFGBuddy.UpdateButtonStates()
	end)
		
	-- Start/Pause toggle button
	local startBtn = CreateFrame("Button", "LFGBuddy_StartPauseButton", mainPanel, "UIPanelButtonTemplate")
	startBtn:SetSize(buttonWidth, buttonHeight)
	startBtn:SetPoint("LEFT", showQueueBtn, "RIGHT", 40, 0)
	startBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	startBtn:SetText("Send")
	
	startBtn:SetScript("OnClick", function()
		LFGBuddy.ClearMessageFocus()

		-- Pause logic
		if LFGBuddy.sending then
			LFGBuddy.sending = false
			startBtn:SetText("Send") -- Change to Start/Send
			LFGBuddy.Print("Whispers paused.",false,true)
			return
		end

		-- Start logic
		local msg = messageEdit:GetText() or ""
		local minChars = 10
		if #msg < minChars then
			LFGBuddy.Print("Message is too short to send, 10 characters is required.",false,true)
			return
		end
		
		-- Ensure queue exists
		if not LFGBuddy.whisperQueue or #LFGBuddy.whisperQueue == 0 then
			LFGBuddy.Print("Whisperqueue is empty. Refresh first.",false,true)
			return
		end

		-- Update recentSentMessages
		LFGBuddyOptions.recentSentMessages = LFGBuddyOptions.recentSentMessages or {}
		for i = #LFGBuddyOptions.recentSentMessages, 1, -1 do
			if LFGBuddyOptions.recentSentMessages[i] == msg then
				table.remove(LFGBuddyOptions.recentSentMessages, i)
			end
		end
		table.insert(LFGBuddyOptions.recentSentMessages, 1, msg)
		while #LFGBuddyOptions.recentSentMessages > 10 do
			table.remove(LFGBuddyOptions.recentSentMessages)
		end
		LFGBuddyOptions.message = msg
		LFGBuddy.RefreshMessageDropdown()

		-- Pre-filter queue: remove anyone in lockout (this is redundant to UpdateWhisperQueue but good for safety if settings change)
		local now = time()
		local filteredQueue = {}
		local lockoutSecs = (LFGBuddyOptions.spamLockoutMins or 30) * 60
		for _, entry in ipairs(LFGBuddy.whisperQueue) do
			local last = LFGBuddyOptions.recentMessageRecipients[entry.name]
			if not last or (now - last) > lockoutSecs or LFGBuddyOptions.ignoreRecipientLockout then
				table.insert(filteredQueue, entry)
			else
				LFGBuddy.Print("Skipped " .. entry.name .. " (lockout active)")
			end
		end

		if #filteredQueue == 0 then
			LFGBuddy.Print("No players in whisperqueue. Sending cancelled.")
			return
		end

		LFGBuddy.whisperQueue = filteredQueue
		LFGBuddy.sending = true
		LFGBuddy.sendTimer = 0
		LFGBuddy.whispersSentSinceStart = 0 -- Reset auto-pause counter
		
		LFGBuddy.UpdateButtonStates()

		startBtn:SetText("Pause") -- Switch button label
		LFGBuddy.Print("Sending whispers started.",false,true)
	end)


	-- Reset button
	local resetBtn = CreateFrame("Button", "LFGBuddy_ResetButton", mainPanel, "UIPanelButtonTemplate")
	resetBtn:SetSize(buttonWidth, buttonHeight)
	resetBtn:SetPoint("LEFT", startBtn, "RIGHT", buttonSpacing, 0)
	resetBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	resetBtn:SetText("Reset")
	resetBtn:SetScript("OnClick", function()
		LFGBuddy.ClearMessageFocus()
		LFGBuddy.sending = false
		LFGBuddy.whisperQueue = {}
		LFGBuddy.excludedPlayers = {}
		LFGBuddy.whispersSentSinceStart = 0 -- Reset auto-pause counter
		if LFGBuddy_StartPauseButton then
			LFGBuddy_StartPauseButton:SetText("Send")
		end
		LFGBuddy.UpdateButtonStates()
		LFGBuddy.Print("Whisperqueue reset.")
	end)
	
	-- Cities Only Checkbox (bare)
	local citiesCheckbox = CreateFrame("CheckButton", "LFGBuddy_CitiesCheckbox", mainPanel, "UICheckButtonTemplate")
	citiesCheckbox:SetPoint("LEFT", classLabel, "RIGHT", 200, -22)
	citiesCheckbox:SetSize(20, 20)
	citiesCheckbox:SetChecked(LFGBuddyOptions.queueCitiesOnly or false)

	-- Label next to checkbox
	local citiesLabel = mainPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	citiesLabel:SetPoint("LEFT", citiesCheckbox, "RIGHT", 4, 0)
	citiesLabel:SetText("Players in cities only")
	citiesLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	-- OnClick handler for checkbox
	citiesCheckbox:SetScript("OnClick", function(self)
		LFGBuddy.ClearMessageFocus()
		LFGBuddy.ToggleQueueCitiesOnly(self:GetChecked())
	end)

    f:Hide()
    LFGBuddy.frame = f
	LFGBuddy.UpdateButtonStates() -- Ensure buttons are in the correct initial state
end

-- =========================
-- Utility for Options Frame
-- =========================
function LFGBuddy.PrintLockouts()
    local lockouts = LFGBuddyOptions.recentMessageRecipients or {}
    local lockoutMins = LFGBuddyOptions.spamLockoutMins or 30
    local lockoutSeconds = lockoutMins * 60
    local now = time()
    local count = 0

    LFGBuddy.Print(string.format("--- Spam lockouts (%d min max) ---", lockoutMins), false, true)

    for name, lastSent in pairs(lockouts) do
        local elapsed = now - lastSent
        if elapsed < lockoutSeconds then
            count = count + 1
            local remainingSeconds = math.ceil(lockoutSeconds - elapsed)
            
            -- Convert remaining seconds to MM:SS format
            local minutes = math.floor(remainingSeconds / 60)
            local seconds = remainingSeconds % 60
            local timeRemaining = string.format("%02d:%02d", minutes, seconds)
            
            LFGBuddy.Print(string.format("  %s - Remaining: %s", name, timeRemaining), true, true)
        end
    end

    if count == 0 then
        LFGBuddy.Print("No spam lockouts.", false, true)
    else
        LFGBuddy.Print(string.format("%d player(s) currently under lockout.", count), false, true)
    end
end


-- =========================
-- GUI (Options Frame - NEW DEDICATED WINDOW)
-- =========================
-- =========================
-- GUI (Options Frame - NEW DEDICATED WINDOW)
-- =========================
-- =========================
-- GUI (Options Frame - NEW DEDICATED WINDOW)
-- =========================
function LFGBuddyOptionsUI()
	if LFGBuddyOptionsFrame then return end
	
    local f = CreateFrame("Frame", "LFGBuddyOptionsFrame", UIParent)
    f:SetSize(337, 330) -- Increased size to accommodate the new vertical stack
    f:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        edgeSize = 10
    })
    f:ClearAllPoints()
	f:SetPoint("CENTER")
	f:SetScript("OnDragStart", f.StartMoving) 
	f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetBackdropColor(0,0,0,0.8)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")

	-- Title
    local title = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    title:SetPoint("TOPLEFT", 6, -6)
    title:SetFont("Fonts\\FRIZQT__.TTF", 13) 
    title:SetText("LFG Buddy Options")

    -- Close button
    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", f, "TOPRIGHT", 4, 3)
    close:SetScript("OnClick", function()
        f:Hide()
		if LFGBuddyOptionsFrame_OptionsButton then
			LFGBuddyOptionsFrame_OptionsButton:UnlockHighlight()
			LFGBuddyOptionsFrame_OptionsButton.fontString:SetTextColor(1, 1, 1)
		end
    end)
	
	-- Separator
    local sep = f:CreateTexture(nil, "BACKGROUND")
    sep:SetColorTexture(0.5, 0.5, 0.5, 0.8)
	sep:SetAlpha(0.8)
    sep:SetHeight(1)
    sep:SetPoint("TOPLEFT", 5, -24)
    sep:SetPoint("TOPRIGHT", -5, -24)
	sep:SetDrawLayer("BACKGROUND", 1)
	
	local contentFrame = CreateFrame("Frame", nil, f)
	contentFrame:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -35)
	contentFrame:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -10, 10)

	-- === Layout Constants ===
	local col1_x = 5
	local col1_y = 8
	local row_spacing = -10
    local button_width = 100
    local buttonSpacing = 5 
    local slider_width = 150
    
    -- Tracks the last placed element for vertical anchoring
    local current_anchor = contentFrame

	-- 1. "Disable Notifications" Checkbox (Stays at the very top)
	local disableNotificationsCheckbox = CreateFrame("CheckButton", "LFGBuddy_DisableNotificationsCheckbox", contentFrame, "UICheckButtonTemplate")
	disableNotificationsCheckbox:SetPoint("TOPLEFT", current_anchor, "TOPLEFT", col1_x, col1_y)
	disableNotificationsCheckbox:SetSize(20, 20)
	disableNotificationsCheckbox:SetChecked(LFGBuddyOptions.disableaddonnotifications or false)

	local disableNotificationsLabel = contentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	disableNotificationsLabel:SetPoint("LEFT", disableNotificationsCheckbox, "RIGHT", 4, 0)
	disableNotificationsLabel:SetText("Disable addon chat notifications")
	disableNotificationsLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	disableNotificationsCheckbox:SetScript("OnClick", function(self)
		LFGBuddyOptions.disableaddonnotifications = self:GetChecked()
		LFGBuddy.Print("Addon chat notifications " .. (self:GetChecked() and "disabled." or "enabled."),false,true)
	end)
    
    current_anchor = disableNotificationsCheckbox
    
    -- 2. Toggle PvP Zones Checkbox
	local togglePvPCheckbox = CreateFrame("CheckButton", "LFGBuddy_TogglePvPCheckbox", contentFrame, "UICheckButtonTemplate")
	togglePvPCheckbox:SetPoint("TOPLEFT", current_anchor, "BOTTOMLEFT", 0, row_spacing)
	togglePvPCheckbox:SetSize(20, 20)
	togglePvPCheckbox:SetChecked(LFGBuddyOptions.togglepvpzones or false)

	local togglePvPLabel = contentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	togglePvPLabel:SetPoint("LEFT", togglePvPCheckbox, "RIGHT", 4, 0)
	togglePvPLabel:SetText("Exclude players in PvP zones from whisperqueue")
	togglePvPLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	togglePvPCheckbox:SetScript("OnClick", function(self)
		LFGBuddyOptions.togglepvpzones = self:GetChecked()
		LFGBuddy.Print("PvP zone filtering " .. (self:GetChecked() and "enabled." or "disabled."), false, true)
	end)
    
    current_anchor = togglePvPCheckbox

	-- 3. Ignore Recipient Lockout Checkbox
	local ignoreLockoutCheckbox = CreateFrame("CheckButton", "LFGBuddy_IgnoreLockoutCheckbox", contentFrame, "UICheckButtonTemplate")
	ignoreLockoutCheckbox:SetPoint("TOPLEFT", current_anchor, "BOTTOMLEFT", 0, row_spacing)
	ignoreLockoutCheckbox:SetSize(20, 20)
	ignoreLockoutCheckbox:SetChecked(LFGBuddyOptions.ignoreRecipientLockout or false)

	local ignoreLockoutLabel = contentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	ignoreLockoutLabel:SetPoint("LEFT", ignoreLockoutCheckbox, "RIGHT", 4, 0)
	ignoreLockoutLabel:SetText("Ignore spam lockouts")
	ignoreLockoutLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	ignoreLockoutCheckbox:SetScript("OnClick", function(self)
		LFGBuddyOptions.ignoreRecipientLockout = self:GetChecked()
		LFGBuddy.Print("Spam lockouts are now " .. (self:GetChecked() and "ignored." or "respected."), false, true)
	end)
    
    current_anchor = ignoreLockoutCheckbox

	-- 4. Spam Lockout Minutes Slider
	local spamSlider = CreateFrame("Slider", "LFGBuddy_SpamLockoutSlider", contentFrame, "OptionsSliderTemplate")
	spamSlider:SetMinMaxValues(5, 60)
	spamSlider:SetValueStep(1)
	spamSlider:SetWidth(slider_width)
	spamSlider:SetValue(LFGBuddyOptions.spamLockoutMins or 30)
	spamSlider:ClearAllPoints()
	-- Anchor below checkbox, move left slightly and adjust for slider height
	spamSlider:SetPoint("TOPLEFT", current_anchor, "BOTTOMLEFT", 2, row_spacing-15)

	-- Hide Low/High Text
	if spamSlider.Low then spamSlider.Low:SetText("") end
	if spamSlider.High then spamSlider.High:SetText("") end

	-- Slider label
	local spamLabel = contentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	spamLabel:SetPoint("TOPLEFT", spamSlider, "TOPLEFT", 0, 10)
	spamLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	local spamScript = function(self, value)
		value = math.floor(value + 0.5)
		LFGBuddyOptions.spamLockoutMins = value
		spamLabel:SetText("Lockout whispers to the same player for " .. value .. " minutes")
	end
    spamSlider:SetScript("OnValueChanged", spamScript)
    spamScript(spamSlider, LFGBuddyOptions.spamLockoutMins or 30) -- Initial label text

    current_anchor = spamSlider

    -- 5. Show Lockouts Button
	local showLockoutsBtn = CreateFrame("Button", "LFGBuddy_ShowLockoutsButton", contentFrame, "UIPanelButtonTemplate")
	showLockoutsBtn:SetSize(button_width, 22)
	-- Anchor below slider, adjust Y to sit after slider body/handle
	showLockoutsBtn:SetPoint("TOPLEFT", current_anchor, "BOTTOMLEFT", -2, row_spacing - 10) 
	showLockoutsBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	showLockoutsBtn:SetText("Show Lockouts")
	showLockoutsBtn:SetScript("OnClick", function()
		LFGBuddy.PrintLockouts()
	end)
    
    -- 6. Reset lockouts button (Horizontal anchor to Show Lockouts)
	local resetRecipientsBtn = CreateFrame("Button", "LFGBuddy_ResetRecipientsButton", contentFrame, "UIPanelButtonTemplate")
	resetRecipientsBtn:SetSize(button_width, 22)
	resetRecipientsBtn:SetPoint("LEFT", showLockoutsBtn, "RIGHT", buttonSpacing, 0)
	resetRecipientsBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	resetRecipientsBtn:SetText("Reset lockouts")
	resetRecipientsBtn:SetScript("OnClick", function()
		LFGBuddyOptions.recentMessageRecipients = {}
		LFGBuddy.Print("Spam lockouts cleared.", false, true)
	end)

    current_anchor = showLockoutsBtn

	-- 7. Auto-Pause Count Slider
	local autoPauseSlider = CreateFrame("Slider", "LFGBuddy_AutoPauseSlider", contentFrame, "OptionsSliderTemplate")
	autoPauseSlider:SetMinMaxValues(1, 50) -- Adjusted max value for more flexibility
	autoPauseSlider:SetValueStep(1)
	autoPauseSlider:SetWidth(slider_width)
	autoPauseSlider:ClearAllPoints()
	-- Anchor below Show Lockouts button
	autoPauseSlider:SetPoint("TOPLEFT", current_anchor, "BOTTOMLEFT", 0, row_spacing-15)
	
    local initialAutoPauseValue = LFGBuddyOptions.autoPauseCount or 50
	autoPauseSlider:SetValue(initialAutoPauseValue)
	
	if autoPauseSlider.Value then autoPauseSlider.Value:Hide() end
    
	-- Slider label
	local autoPauseLabel = contentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	autoPauseLabel:SetPoint("TOPLEFT", autoPauseSlider, "TOPLEFT", 0, 10)
	autoPauseLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	local autoPauseScript = function(self, value)
		value = math.floor(value + 0.5)
		LFGBuddyOptions.autoPauseCount = value
		autoPauseLabel:SetText("Auto-pause whispers when " .. value .. " has been sent")
	end
	
	autoPauseSlider:SetScript("OnValueChanged", autoPauseScript)
    autoPauseScript(autoPauseSlider, initialAutoPauseValue)

    current_anchor = autoPauseSlider

    -- 8. Show Ignore Zones Button (Starting point for the first horizontal row of action buttons)
	local showIgnoreZonesBtn = CreateFrame("Button", "LFGBuddy_ShowIgnoreZonesButton", contentFrame, "UIPanelButtonTemplate")
	showIgnoreZonesBtn:SetSize(button_width, 22)
	-- Anchor below Auto-Pause Slider
	showIgnoreZonesBtn:SetPoint("TOPLEFT", current_anchor, "BOTTOMLEFT", -2, row_spacing - 10)
	showIgnoreZonesBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	showIgnoreZonesBtn:SetText("Ignore zones?")
	showIgnoreZonesBtn:SetScript("OnClick", function()
		LFGBuddy.PrintIgnoreZones()
	end)
    
    local horizontal_anchor = showIgnoreZonesBtn 

	-- 9. Show PvP Zones Button (Horizontal anchor to Show Ignore Zones)
	local showPvPZonesBtn = CreateFrame("Button", "LFGBuddy_ShowPvPZonesButton", contentFrame, "UIPanelButtonTemplate")
	showPvPZonesBtn:SetSize(button_width, 22)
	showPvPZonesBtn:SetPoint("LEFT", horizontal_anchor, "RIGHT", buttonSpacing, 0)
	showPvPZonesBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	showPvPZonesBtn:SetText("PvP zones?")
	showPvPZonesBtn:SetScript("OnClick", function()
		LFGBuddy.PrintPvPZones()
	end)
    
    horizontal_anchor = showPvPZonesBtn

    -- 10. Toggle Faction Button (Horizontal anchor to Show PvP Zones)
	local isHorde = false
    for _, city in ipairs(LFGBuddyOptions.cities) do
        if city == "Orgrimmar" then
            isHorde = true
            break
        end
    end
	local toggleFactionBtn = CreateFrame("Button", "LFGBuddy_ToggleFactionButton", contentFrame, "UIPanelButtonTemplate")
	toggleFactionBtn:SetSize(button_width, 22)
	toggleFactionBtn:SetPoint("LEFT", horizontal_anchor, "RIGHT", buttonSpacing, 0)
	toggleFactionBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	toggleFactionBtn:GetFontString():SetText("Switch faction")
	toggleFactionBtn:SetScript("OnClick", function()
		LFGBuddy.ToggleCities()
	end)

	-- 11. Reset Defaults Button (Vertical anchor to Show Ignore Zones, with extra spacing)
    local extra_spacing = row_spacing - 10 -- Creates the 10-pixel gap below the first button row
	local resetDefaultsBtn = CreateFrame("Button", "LFGBuddy_ResetDefaultsButton", contentFrame, "UIPanelButtonTemplate")
	resetDefaultsBtn:SetSize(button_width, 22)
	resetDefaultsBtn:SetPoint("TOPLEFT", showIgnoreZonesBtn, "BOTTOMLEFT", 0, extra_spacing)
	resetDefaultsBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	resetDefaultsBtn:SetText("Reset addon")
	resetDefaultsBtn:SetScript("OnClick", function()
		LFGBuddy.ResetDefaults()
	end)
    
    f:Hide()
    LFGBuddyOptionsFrame = f
end

function LFGBuddy.UpdateButtonStates()
    local queueEmpty = not LFGBuddy.whisperQueue or #LFGBuddy.whisperQueue == 0

    -- Start/Pause button: enabled if whisperQueue is NOT empty
    if LFGBuddy_StartPauseButton then
        if not queueEmpty then
            LFGBuddy_StartPauseButton:Enable()
        else
            LFGBuddy_StartPauseButton:Disable()
			LFGBuddy_StartPauseButton:SetText("Send") -- Ensure it resets to Send if queue is emptied
			LFGBuddy.sending = false -- Ensure runtime state matches
        end
    end

    -- Reset button: enabled if whisperQueue is NOT empty
    if LFGBuddy_ResetButton then
        if not queueEmpty then
            LFGBuddy_ResetButton:Enable()
        else
            LFGBuddy_ResetButton:Disable()
        end
    end
	
	-- Show Queue button: always enabled as Refresh is the only thing that needs to work before it
	if LFGBuddy_ShowQueueButton then
		LFGBuddy_ShowQueueButton:Enable()
	end
end

-- =========================
-- Show Current Settings
-- =========================
function LFGBuddy.ShowSettings()
    LFGBuddy.Print("Settings:",false,true)
    LFGBuddy.Print("  ignorezones = " .. (#LFGBuddyOptions.ignoreZones > 0 and table.concat(LFGBuddyOptions.ignoreZones, ", ") or "None"),false,true)
    LFGBuddy.Print("  cities = " .. (#LFGBuddyOptions.cities > 0 and table.concat(LFGBuddyOptions.cities, ", ") or "None"),false,true)
    LFGBuddy.Print("Commands:",false,true)
    LFGBuddy.Print("  /lb show - Show GUI, advising to open Who tab",false,true)
    LFGBuddy.Print("  /lb reset - Addon reset to defaults",false,true)
    LFGBuddy.Print("  /lb switchfaction - Switches cities to filter",false,true)
    LFGBuddy.Print("  /lb addclass <Class Name> - Add a class",false,true)
    LFGBuddy.Print("  /lb removeclass <Class Name> - Remove a class",false,true)
    LFGBuddy.Print("  /lb ignorezones - Print zones that are excluded from queue",false,true)
    LFGBuddy.Print("  /lb addzone <Zone Name> - Add a zone to ignorelist",false,true)
    LFGBuddy.Print("  /lb removezone <Zone Name> - Remove a zone from ignorelist",false,true)
end

-- =========================
-- Slash Commands
-- =========================
SLASH_LFGBUDDY1 = "/lb"
SlashCmdList["LFGBUDDY"] = function(msg)
    msg = msg or ""
    local command, arg = msg:match("^(%S*)%s*(.-)$")
    command = command:lower()
    arg = arg:lower()

    if command == "show" then
		LFGBuddyUI()
		LFGBuddy.frame:Show()
		LFGBuddy.Print("Open the Who tab (press O -> Who) to snap the addon into position.")
    elseif command == "reset" then
        LFGBuddy.ResetDefaults()
	elseif command == "switchfaction" then
    	LFGBuddy.ToggleCities()
	elseif command == "addclass" and arg ~= "" then
		local success, msg = LFGBuddy.AddClass(arg)
		LFGBuddy.Print(msg)
	elseif command == "removeclass" and arg ~= "" then
		local success, msg = LFGBuddy.RemoveClass(arg)
		LFGBuddy.Print(msg)
	elseif command == "ignorezones" then
		LFGBuddy.PrintIgnoreZones()
	elseif command == "addzone" and arg ~= "" then
		LFGBuddy.AddIgnoreZone(arg)
	elseif command == "removezone" and arg ~= "" then
		LFGBuddy.RemoveIgnoreZone(arg)
    -- Removed showonwho, locktowho commands
	elseif command == "whisperqueue" then
		LFGBuddy.ShowWhisperQueue()
	elseif command == "whisperqueuecitiesonly" then
    if arg == "on" then
        LFGBuddy.ToggleQueueCitiesOnly(true)
    elseif arg == "off" then
        LFGBuddy.ToggleQueueCitiesOnly(false)
    else
        LFGBuddy.Print("Queue only in cities is " .. (LFGBuddyOptions.queueCitiesOnly and "ENABLED" or "DISABLED"),false,true)
    end
    else
        LFGBuddy.ShowSettings()
    end
end

-- =========================
-- Event Handling
-- =========================
local addonFrame = CreateFrame("Frame")
addonFrame:RegisterEvent("ADDON_LOADED")
addonFrame:SetScript("OnEvent", function(self, event, addonName)
    if event == "ADDON_LOADED" and addonName == ADDON_NAME then
        LFGBuddy.OnFirstLoad()
    end
end)

-- Who updates
local whoEventFrame = CreateFrame("Frame")
whoEventFrame:RegisterEvent("WHO_LIST_UPDATE")
whoEventFrame:SetScript("OnEvent", function(_, event)
    if event == "WHO_LIST_UPDATE" then
        if LFGBuddy.frame and LFGBuddy.frame:IsShown() then
            LFGBuddy.UpdateWhisperQueue()
        end
    end
end)

local saveFramePos = CreateFrame("Frame")
saveFramePos:RegisterEvent("PLAYER_LOGOUT")
saveFramePos:SetScript("OnEvent", function()
	if LFGBuddy.frame then
		-- Get current position in relation to UIParent
		local x, y = LFGBuddy.frame:GetCenter()
		if x and y then
			LFGBuddyOptions.framePoint = "CENTER"
			LFGBuddyOptions.frameRelativePoint = "CENTER"
			LFGBuddyOptions.frameX = x - (UIParent:GetWidth() / 2)
			LFGBuddyOptions.frameY = y - (UIParent:GetHeight() / 2)
		end
	end
end)