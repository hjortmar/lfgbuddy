-- Main.lua
local ADDON_NAME, LFGBuddy = ...

local LFGBUDDY_DEFAULT_IGNORE_ZONES = {
    "Baradin Hold","Ragefire Chasm","Wailing Caverns","The Deadmines","Shadowfang Keep",
    "Blackfathom Deeps","Stormwind Stockade","The Stockades","Gnomeregan","Razorfen Kraul",
    "Scarlet Monastery","Razorfen Downs","Uldaman","Zul'Farrak","Maraudon","Glittermurk Mines",
    "Sunken Temple","Temple of Atal-Hakkar","The Temple of Atal-Hakkar","Blackrock Depths","Blackrock Spire",
    "Tol Barad","Lower Blackrock Spire","Upper Blackrock Spire","Scholomance","Stratholme","Blackrock Mountain",
}

-- PvP Zones excluded when the option is toggled
local LFGBUDDY_DEFAULT_PVP_ZONES = {"Warsong Gulch","Arathi Basin","Alterac Valley"}

local DEFAULT_HORDE_CITIES = {"Orgrimmar", "Undercity", "Thunder Bluff","Silvermoon"}

local DEFAULT_ALLIANCE_CITIES = {"Stormwind", "Ironforge", "Darnassus", "Exodar"}

local LFGBUDDY_DEFAULT_CLASSES = {"Any", "Shaman","Paladin","Druid","Warrior","Warlock","Priest","Rogue","Mage","Hunter","Tank", "Healer", "DPS"}

local LFGBUDDY_DEFAULT_CLASSES_TANKS = {"Paladin","Druid","Warrior"}
local LFGBUDDY_DEFAULT_CLASSES_DPS = {"Shaman","Paladin","Druid","Warrior","Warlock","Priest","Rogue","Mage","Hunter"}
local LFGBUDDY_DEFAULT_CLASSES_HEALERS = {"Shaman","Paladin","Druid","Priest"}

local LFGBUDDY_CLASS_COLORS = {
    ["WARRIOR"] = "C79C6E",
    ["PALADIN"] = "F58CBA",
    ["HUNTER"] = "ABD473",
    ["ROGUE"] = "FFF569",
    ["PRIEST"] = "FFFFFF",
    ["SHAMAN"] = "0070DE",
    ["MAGE"] = "69CCF0",
    ["WARLOCK"] = "9482C9",
    ["DRUID"] = "FF7D0A",
}

-- Options stored in WTF
LFGBuddyOptions = LFGBuddyOptions or {}

-- Initialization
function LFGBuddy.OnFirstLoad()
    if not LFGBuddyOptions.initialized then
        -- ignore zones
        LFGBuddyOptions.ignoreZones = {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_IGNORE_ZONES) do
            table.insert(LFGBuddyOptions.ignoreZones, name)
        end
		
        -- ignore zones: Uses the local variable to populate the OPTIONS table
        LFGBuddyOptions.ignorePvPZones = {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_PVP_ZONES) do
            table.insert(LFGBuddyOptions.ignorePvPZones, name)
        end

		local playerFaction = UnitFactionGroup("player")
		LFGBuddyOptions.cities = (playerFaction == "Horde") and DEFAULT_HORDE_CITIES or DEFAULT_ALLIANCE_CITIES

        -- classes
        LFGBuddyOptions.classes = {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_CLASSES) do
            table.insert(LFGBuddyOptions.classes, name)
        end
		
		if #LFGBuddyOptions.classes > 0 then LFGBuddyOptions.lastClass = LFGBuddyOptions.classes[1] end
		
        -- Tank classes
        LFGBuddyOptions.classesTanks = LFGBuddyOptions.classesTanks or {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_CLASSES_TANKS) do
            table.insert(LFGBuddyOptions.classesTanks, name)
        end

        -- DPS classes
        LFGBuddyOptions.classesDPS = LFGBuddyOptions.classesDPS or {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_CLASSES_DPS) do
            table.insert(LFGBuddyOptions.classesDPS, name)
        end

        -- Healer classes
        LFGBuddyOptions.classesHealers = LFGBuddyOptions.classesHealers or {}
        for _, name in ipairs(LFGBUDDY_DEFAULT_CLASSES_HEALERS) do
            table.insert(LFGBuddyOptions.classesHealers, name)
        end

        -- flags
		LFGBuddyOptions.SelectedRoles = LFGBuddyOptions.SelectedRoles or {}
        LFGBuddyOptions.queueCitiesOnly = false
        LFGBuddyOptions.queueCurrentZoneOnly = false -- NEW OPTION
		LFGBuddyOptions.recentSentMessages = {}
		LFGBuddyOptions.recentMessageRecipients = {}
		LFGBuddyOptions.ignoreRecipientLockout = false
		LFGBuddyOptions.spamInterval = 1.2
		LFGBuddyOptions.spamLockoutMins = 30
		LFGBuddyOptions.togglepvpzones = true
		LFGBuddyOptions.disableaddonnotifications = false
		LFGBuddyOptions.autoPauseCount = 50 
        LFGBuddyOptions.ToggleInactiveMode = false -- NEW OPTION
        LFGBuddyOptions.initialized = true

        print("|cff33ff99LFGBuddy:|r Initialized with default ignorezones, cities, and classes.")
    end
	
    -- Runtime state (reset every reload/UI load)
    LFGBuddy.UpdateLevelRangeOptions()
    LFGBuddy.whisperQueue = {}
	LFGBuddy.excludedPlayers = {} 
    LFGBuddy.sendTimer = 0
    LFGBuddy.sending = false
	LFGBuddy.whispersSentSinceStart = 0 
    
end

-- Reset everything to defaults
function LFGBuddy.ResetDefaults()
    LFGBuddyOptions = {}
	LFGBuddyOptions.initialized = false
    LFGBuddy.OnFirstLoad()
	LFGBuddy.UpdateButtonStates()
    print("|cff33ff99LFGBuddy:|r Defaults restored.")
end

function LFGBuddy.Print(msg, raw, force)
    -- If notifications are disabled and force is not set, stop
    if LFGBuddyOptions.disableaddonnotifications and not force then
        return
    end

    local text = tostring(msg or "")

    if not raw then
        text = "|cff33ff99LFGBuddy:|r " .. text
    end

    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage(text)
    else
        print(text)  -- fallback
    end
end

-- Level Range Updates
function LFGBuddy.UpdateLevelRangeOptions()
    local lvl = UnitLevel("player")
    local MIN_LEVEL_CAP = 1
    local MAX_LEVEL_CAP = 60

    LFGBuddyOptions.minLevel = math.max(MIN_LEVEL_CAP, lvl - 8)
    LFGBuddyOptions.maxLevel = math.min(MAX_LEVEL_CAP, lvl + 8)
	
	LFGBuddyOptions.minLevel = lvl
    
    if LFGBuddy.UpdateLevelDropdowns then
        LFGBuddy.UpdateLevelDropdowns()
    end
end

-- Utility to get the class name with color tags
function LFGBuddy.GetColoredClassName(className)
    if not className or className == "" then return "" end
    
    local upperClass = className:upper()
    local color = LFGBUDDY_CLASS_COLORS[upperClass]
    
    if color then
        -- Returns the formatted string: |cffRRGGBBClassname|r
        return "|cff" .. color .. className .. "|r"
    else
        -- Return unformatted name if color is not found
        return className
    end
end

-- Utility to get the initial state of a role-class checkbox from saved variables.
function LFGBuddy.GetRoleClassState(role, className)
    LFGBuddyOptions.SelectedRoles = LFGBuddyOptions.SelectedRoles or {}
    local key = role .. "_" .. className
    -- Default state is checked (true). If the key is nil (not saved) 
    -- it means the user hasn't explicitly unchecked it.
    local state = LFGBuddyOptions.SelectedRoles[key]
    return state ~= false
end

-- Utility to save the state of a role-class checkbox to saved variables.
function LFGBuddy.SetRoleClassState(role, className, isChecked)
    LFGBuddyOptions.SelectedRoles = LFGBuddyOptions.SelectedRoles or {}
    local key = role .. "_" .. className
    
    if isChecked then
        -- Default state is checked (true). Set to nil to save space in the saved variable file.
        LFGBuddyOptions.SelectedRoles[key] = nil 
    else
        -- Only save 'false' when the checkbox is explicitly unchecked/excluded.
        LFGBuddyOptions.SelectedRoles[key] = false
    end
end

-- =========================================================================
-- NEW: Tooltip Utility
-- =========================================================================

-- Formats the current whisper queue content into a multi-line string for a tooltip.
function LFGBuddy.GetWhisperQueueTooltipText()
    local queue = LFGBuddy.whisperQueue or {}
    local count = #queue
    
    if count == 0 then
        return "|r\n|cffff7755Queue Empty|r\n\nClick \"Find players\" or use /who to populate the whisper queue."
    end

    local output = "|r\n|cffff7755Whisper Queue (" .. count .. " total):|r\n\n"
    local maxDisplay = 5 -- Limit the number of names shown to prevent an excessively large tooltip

    for i, entry in ipairs(queue) do
        local name = entry.name or "Unknown Player" 
        local class = entry.class -- Get the class string
        
        local classColorPrefix = ""
        -- 1. Get the color string using the custom function
        local coloredClassText = LFGBuddy.GetColoredClassName(class)
        
        -- 2. Extract the color prefix, if present (e.g., "|cffRRGGBB")
        -- We assume GetColoredClassName returns "|cffRRGGBBClassname|r" or just "Classname"
        -- We only want the color prefix to apply to the name.
        if coloredClassText:find("|cff", 1, true) then
            classColorPrefix = coloredClassText:match("(|cff[0-9a-fA-F]+)") or ""
        end
        
        -- Apply the color prefix to the player name
        local coloredName = classColorPrefix .. name .. "|r"
        
        if i <= maxDisplay then
            output = output .. coloredName .. "\n"
        elseif i == maxDisplay + 1 then
            output = output .. "|r\n.. and " .. (count - maxDisplay) .. " more.|r\n\nClick \"Whisper who?\" for a full list.|r\n"
            break
        end
    end

    return output
end
-- =========================================================================

-- Classes
-- Adds a class to the list
function LFGBuddy.AddClass(className)
    if not className or className == "" then
        return false, "Invalid class name."
    end

    LFGBuddyOptions.classes = LFGBuddyOptions.classes or {}

    for _, existing in ipairs(LFGBuddyOptions.classes) do
        if existing:lower() == className:lower() then
            return false, "Class '" .. className .. "' already exists."
        end
    end

    table.insert(LFGBuddyOptions.classes, className)
    return true, "Class '" .. className .. "' added."
end

-- Removes a class from the list
function LFGBuddy.RemoveClass(className)
    if not className or className == "" then
        return false, "Invalid class name."
    end

    if not LFGBuddyOptions.classes or #LFGBuddyOptions.classes == 0 then
        return false, "No classes defined."
    end

    for i, existing in ipairs(LFGBuddyOptions.classes) do
        if existing:lower() == className:lower() then
            table.remove(LFGBuddyOptions.classes, i)
            return true, "Class '" .. className .. "' removed."
        end
    end

    return false, "Class '" .. className .. "' not found."
end

-- Switch between faction capitals.
function LFGBuddy.ToggleCities()
    local isHorde = false
    for _, city in ipairs(LFGBuddyOptions.cities) do
        if city == "Orgrimmar" then
            isHorde = true
            break
        end
    end

    if isHorde then
        LFGBuddyOptions.cities = DEFAULT_ALLIANCE_CITIES
		LFGBuddy.Print("Switched to Alliance cities, if active, only players in these cities will be included in the whisper queue.")
    else
        LFGBuddyOptions.cities = DEFAULT_HORDE_CITIES
        LFGBuddy.Print("Switched to Horde cities, if active, only players in these cities will be included in the whisper queue.")
    end
	
	LFGBuddy.PrintCities()
	
end

-- Add and remove ignorezones.
function LFGBuddy.PrintIgnoreZones()
    if not LFGBuddyOptions.ignoreZones or #LFGBuddyOptions.ignoreZones == 0 then
        LFGBuddy.Print("No ignore zones have been set.", false, true)
        return
    end

    LFGBuddy.Print("Ignore zones:", false, true)
    for i, zone in ipairs(LFGBuddyOptions.ignoreZones) do
        LFGBuddy.Print("  " .. zone, true, true)
    end
	LFGBuddy.Print("If players are in any of the zones above, they will not be included in the whisper queue.", false, true)
end

function LFGBuddy.PrintCities()
    if not LFGBuddyOptions.cities or #LFGBuddyOptions.cities == 0 then
        LFGBuddy.Print("No cities have been set.", false, true)
        return
    end

    for i, city in ipairs(LFGBuddyOptions.cities) do
        LFGBuddy.Print("  " .. city, true, true)
    end
end

function LFGBuddy.PrintPvPZones()
    -- Check and print LFGBuddyOptions.ignorePvPZones
    if not LFGBuddyOptions.ignorePvPZones or #LFGBuddyOptions.ignorePvPZones == 0 then
        LFGBuddy.Print("No PvP zones have been set.", false, true)
        return
    end

    LFGBuddy.Print("PvP zones (excluded option is enabled):", false, true)
    for i, zone in ipairs(LFGBuddyOptions.ignorePvPZones) do
        LFGBuddy.Print("  " .. zone, true, true)
    end
end

function LFGBuddy.AddIgnoreZone(zoneName)
    if not zoneName or zoneName == "" then return end
    LFGBuddyOptions.ignoreZones = LFGBuddyOptions.ignoreZones or {}

    local lowerZone = zoneName:lower()
    for _, existing in ipairs(LFGBuddyOptions.ignoreZones) do
        if existing:lower() == lowerZone then
            LFGBuddy.Print("Zone '" .. zoneName .. "' is already in ignore list.")
            return
        end
    end

    table.insert(LFGBuddyOptions.ignoreZones, zoneName)
    LFGBuddy.Print("Zone '" .. zoneName .. "' added to ignore list.")
end

-- Remove a zone from ignoreZones
function LFGBuddy.RemoveIgnoreZone(zoneName)
    if not zoneName or zoneName == "" then return end
    if not LFGBuddyOptions.ignoreZones then return end

    local lowerZone = zoneName:lower()
    for i, existing in ipairs(LFGBuddyOptions.ignoreZones) do
        if existing:lower() == lowerZone then
            table.remove(LFGBuddyOptions.ignoreZones, i)
            LFGBuddy.Print("Zone '" .. existing .. "' removed from ignore list.")
            return
        end
    end

    LFGBuddy.Print("Zone '" .. zoneName .. "' not found in ignore list.")
end

-- =========================================================================
-- NEW FUNCTION: Get filtered class list based on selected role and Roles UI checkboxes
-- =========================================================================
-- Utility function to get the list of selected classes for a role from the Roles UI
function LFGBuddy.GetRoleClassesQuery(role)
    local classes = {}
    local classList
    local checkboxPrefix
    local upperRole = role:upper()
    
    -- Map selected role to list of classes and UI element prefix
    if upperRole == "TANK" then
        classList = LFGBUDDY_DEFAULT_CLASSES_TANKS
        checkboxPrefix = "LFGBuddyRolesUI_Tank_"
    elseif upperRole == "HEALER" then
        classList = LFGBUDDY_DEFAULT_CLASSES_HEALERS
        checkboxPrefix = "LFGBuddyRolesUI_Healer_"
    elseif upperRole == "DPS" then
        classList = LFGBUDDY_DEFAULT_CLASSES_DPS
        checkboxPrefix = "LFGBuddyRolesUI_DPS_"
    else
        -- Not a role (e.g., "Warrior", "Any"), return the original value
        return role
    end

    -- If the Roles UI hasn't been created yet, return the original role name
    if not LFGBuddyRolesUI then
        return role
    end

    for _, class in ipairs(classList) do
        -- Checkbox name example: LFGBuddyRolesUI_Tank_WarriorCheckbox
        local checkboxName = checkboxPrefix .. class .. "Checkbox"
        local checkbox = _G[checkboxName] -- Get the global reference to the frame/checkbox

        if checkbox and checkbox:GetChecked() then
            table.insert(classes, class)
        end
    end

    -- If specific classes are checked, return a string of 'c-"Class"' terms.
    if #classes > 0 then
        local queryParts = {}
        for _, class in ipairs(classes) do
            -- Create the format: c-"Paladin"
            table.insert(queryParts, 'c-"' .. class .. '"')
        end
        -- Return a space-separated string: 'c-"Paladin" c-"Warrior" ...'
        return table.concat(queryParts, " ")
    end
    
    -- If the user selected a role but unchecked all classes, return the original role string.
    -- This results in c-tank, c-healer, or c-dps in the query, maintaining the original logic 
    -- if no class-filtering is enabled for that role.
    return role
end
-- =========================================================================


-- Who Frame Interaction
-- Helper: snap LFGBuddy to WhoFrame
-- Who Frame Interaction
-- Helper: snap LFGBuddy to WhoFrame (Main Frame)
local function SnapToWhoFrame()
    if LFGBuddy.frame and WhoFrame then
        LFGBuddy.frame:StopMovingOrSizing()
        LFGBuddy.frame:ClearAllPoints()
        LFGBuddy.frame:SetPoint("TOPLEFT", WhoFrame, "TOPRIGHT", -35, -13)
        LFGBuddy.frame:SetMovable(false)
        LFGBuddy.frame:EnableMouse(false)
    end
end

-- NEW Helper: snap LFGBuddyPassiveFrame to WhoFrame
local function SnapPassiveToWhoFrame()
    if LFGBuddyPassiveFrame and WhoFrame then
        LFGBuddyPassiveFrame:StopMovingOrSizing()
        LFGBuddyPassiveFrame:ClearAllPoints()
        -- Snaps the small frame to the top right of the WhoFrame, just outside of it
        LFGBuddyPassiveFrame:SetPoint("TOPLEFT", WhoFrame, "TOPRIGHT", -35, -13)
        LFGBuddyPassiveFrame:SetMovable(false)
        LFGBuddyPassiveFrame:EnableMouse(false)
    end
end

-- Show/hide frame when Who tab opens/closes (UPDATED LOGIC)
local function WhoFrame_OnShowHook()
    LFGBuddyUI()
    LFGBuddyPassiveUI() -- Ensure both frames exist
    LFGBuddyOptionsUI() -- Ensure options frame exists to manage button state
    LFGBuddyRolesUI() -- Ensure roles frame exists

    if LFGBuddyOptions.ToggleInactiveMode then
        -- If minimized (passive mode), show the passive frame and snap it
        LFGBuddy.frame:Hide()
        LFGBuddyOptionsFrame:Hide()
        LFGBuddyRolesFrame:Hide() -- Hide Roles frame
        LFGBuddyPassiveFrame:Show()
        SnapPassiveToWhoFrame()
    else
        -- If active (main mode), show the main frame and snap it
        LFGBuddyPassiveFrame:Hide()
        LFGBuddy.frame:Show()
        SnapToWhoFrame()
    end
	
        -- *** NEW LOGIC TO RESTORE ROLES FRAME STATE ***
        if LFGBuddyOptions and LFGBuddyOptions.isRolesOpen then
            local f = LFGBuddy.frame -- Reference to the main frame
            local rolesFrame = LFGBuddyRolesFrame
            local rolesBtn = LFGBuddyRolesFrame_RolesButton
            
            if f and rolesFrame and rolesBtn then
                f:SetHeight(217) -- Expanded size (217 from your code)
                rolesFrame:Show()
                
                -- Restore the custom snap point used in your OnClick handler
                rolesFrame:ClearAllPoints()
                rolesFrame:SetPoint("TOPLEFT", f, "BOTTOMLEFT", 0, 114)
                
                -- Update button state
                rolesBtn:LockHighlight()
                rolesBtn.fontString:SetTextColor(1.0, 0.82, 0.0) -- Blizzard Gold
                
                -- Ensure the Options frame is hidden (as it conflicts)
                LFGBuddyOptionsFrame:Hide()
            end
        else
            -- Ensure default state if the main frame is opened/restored
            LFGBuddy.frame:SetHeight(110)
            LFGBuddyRolesFrame:Hide()
        end
        -- *** END NEW LOGIC ***
	
end

local function WhoFrame_OnHideHook()
    -- Hide options frame and reset button highlight state regardless of active mode
    if LFGBuddyOptionsFrame then
        LFGBuddyOptionsFrame:Hide()
        if LFGBuddyOptionsFrame_OptionsButton then
            LFGBuddyOptionsFrame_OptionsButton:UnlockHighlight()
            LFGBuddyOptionsFrame_OptionsButton.fontString:SetTextColor(1, 1, 1) -- White
        end
    end
    
    -- Hide roles frame and reset button highlight state
    if LFGBuddyRolesFrame then
        LFGBuddyRolesFrame:Hide()
        if LFGBuddyRolesFrame_RolesButton then
            LFGBuddyRolesFrame_RolesButton:UnlockHighlight()
            LFGBuddyRolesFrame_RolesButton.fontString:SetTextColor(1, 1, 1) -- White
        end
    end

    -- Explicitly hide both the main frame and the passive frame when WhoFrame closes
    if LFGBuddyPassiveFrame then
        LFGBuddyPassiveFrame:Hide()
    end
    if LFGBuddy.frame then
        LFGBuddy.frame:Hide()
    end
    
    LFGBuddy.sending = false
    LFGBuddy.whisperQueue = {}
    LFGBuddy.excludedPlayers = {}
    LFGBuddy.whispersSentSinceStart = 0
    if LFGBuddy_StartPauseButton then
        LFGBuddy_StartPauseButton:SetText("Send")
    end
    LFGBuddy.UpdateButtonStates()
    -- ======================================================
end

-- Hook safely
if WhoFrame then
    WhoFrame:HookScript("OnShow", WhoFrame_OnShowHook)
    WhoFrame:HookScript("OnHide", WhoFrame_OnHideHook)
end

-- Check if a zone is one of the default cities
local function isZoneInDefaultCities(zone)
    for _, city in ipairs(LFGBuddyOptions.cities) do
        if city == zone then return true end
    end
    return false
end

-- Check if a zone is ignored
local function isZoneIgnored(zone)
    for _, ignored in ipairs(LFGBuddyOptions.ignoreZones) do
        if ignored == zone then return true end
    end
    return false
end

-- Check if a zone is ignored
local function isPvPZoneIgnored(zone)
    -- Use LFGBuddyOptions.ignorePvPZones for filtering
    for _, ignored in ipairs(LFGBuddyOptions.ignorePvPZones or {}) do 
        if ignored == zone then return true end
    end
    return false
end

-- Toggles the "Idling in town" city filtering
function LFGBuddy.ToggleQueueCitiesOnly(enable)
    LFGBuddyOptions.queueCitiesOnly = enable
    if enable then
        -- Mutually exclusive with new option
        LFGBuddyOptions.queueCurrentZoneOnly = false
        if LFGBuddy_CurrentZoneCheckbox then
            LFGBuddy_CurrentZoneCheckbox:SetChecked(false)
        end
    end
    LFGBuddy.Print("Restricted to players in cities: " .. (enable and "ENABLED." or "DISABLED."))
end

-- NEW: Toggles the "In my zone" filtering
function LFGBuddy.ToggleQueueCurrentZoneOnly(enable)
    LFGBuddyOptions.queueCurrentZoneOnly = enable
    if enable then
        -- Mutually exclusive with old option
        LFGBuddyOptions.queueCitiesOnly = false
        if LFGBuddy_CitiesCheckbox then
            LFGBuddy_CitiesCheckbox:SetChecked(false)
        end
    end
    local zone = GetRealZoneText() or "Unknown Zone"
    LFGBuddy.Print("Restricted to players in current zone: " .. (enable and "ENABLED." or "DISABLED."))
end

function LFGBuddy.PrintLockouts()
    local lockouts = LFGBuddyOptions.recentMessageRecipients or {}
    local lockoutMins = LFGBuddyOptions.spamLockoutMins or 30
    local lockoutSeconds = lockoutMins * 60
    local now = time()
    local count = 0

    LFGBuddy.Print(string.format("--- Spam lockouts (Currently set to %d minutes) ---", lockoutMins), false, true)

    for name, lastSent in pairs(lockouts) do
        local elapsed = now - lastSent
        if elapsed < lockoutSeconds then
            count = count + 1
            local remainingSeconds = math.ceil(lockoutSeconds - elapsed)
            
            -- Convert remaining seconds to MM:SS format
            local minutes = math.floor(remainingSeconds / 60)
            local seconds = remainingSeconds % 60
            local timeRemaining = string.format("%02d:%02d", minutes, seconds)
            
            LFGBuddy.Print(string.format("  %s - Remaining: %s", name, timeRemaining), true, true)
        end
    end

    if count == 0 then
        LFGBuddy.Print("No spam lockouts.", false, true)
    else
        LFGBuddy.Print(string.format("%d player(s) currently under lockout.", count), false, true)
    end
end

function LFGBuddy.UpdateWhisperQueue()
    -- Do not update the queue if inactive mode is toggled
    if LFGBuddyOptions.ToggleInactiveMode then
        return
    end

    LFGBuddy.whisperQueue = {}
	LFGBuddy.excludedPlayers = {} -- Reset excluded list
    local now = time()
    local lockoutSeconds = (LFGBuddyOptions.spamLockoutMins or 30) * 60  -- convert minutes to seconds
    local n = GetNumWhoResults()

    for i = 1, n do
        local name, guild, level, race, class, zone = GetWhoInfo(i)
        if name and name ~= UnitName("player") then
            local include = true
			local excludeReason = nil

			if LFGBuddyOptions.queueCitiesOnly then
				-- Only keep players in default cities
				if not isZoneInDefaultCities(zone) then
					include = false
					excludeReason = "not in a city"
				end
			-- NEW LOGIC: Check for current zone filtering
			elseif LFGBuddyOptions.queueCurrentZoneOnly then
                local currentZone = GetRealZoneText()
                if not currentZone or zone ~= currentZone then
                    include = false
                    excludeReason = "not in your current zone (" .. (currentZone or "Unknown") .. ")"
                end
			-- END NEW LOGIC
			else
				-- Exclude players in ignored zones
				if isZoneIgnored(zone) then
					include = false
					excludeReason = "Ignored zone: " .. zone
				end

				-- Exclude players in PvP zones if toggle is active
				if include and LFGBuddyOptions.togglepvpzones and isPvPZoneIgnored(zone) then
					include = false
					excludeReason = "PvP zone: " .. zone
				end
			end

            -- Skip players who are on the Blizzard ignore list
            if include and IsIgnored(name) then
                include = false
                excludeReason = "player ignored"
            end

            -- Skip players who are recent recipients (lockout)
            local lastSent = LFGBuddyOptions.recentMessageRecipients[name]
            if include and lastSent and not LFGBuddyOptions.ignoreRecipientLockout then
                if now - lastSent <= lockoutSeconds then
                    include = false
                    excludeReason = "Spam lockout active"
                end
            end

            if include then
                table.insert(LFGBuddy.whisperQueue, {name=name, level=level, class=class, zone=zone})
            else
				table.insert(LFGBuddy.excludedPlayers, {name=name, reason=excludeReason or "Unknown Reason"})
            end
        end
    end

    if #LFGBuddy.whisperQueue == 0 then
        --LFGBuddy.Print("No players to whisper after filtering.")
    else
        LFGBuddy.Print("Queued " .. #LFGBuddy.whisperQueue .. " whispers.")
    end

    LFGBuddy.UpdateButtonStates()
end

function LFGBuddy.ShowWhisperQueue()
    -- Only print to chat if notifications are enabled OR if this is a force print via slash command
    local isChatNotifEnabled = true 
    
    if #LFGBuddy.excludedPlayers > 0 then
        LFGBuddy.Print("--- Excluded Players (" .. #LFGBuddy.excludedPlayers .. ") ---", false, isChatNotifEnabled)
        for _, entry in ipairs(LFGBuddy.excludedPlayers) do
        
            -- NEW FORMATTING LOGIC: Reformat the reason based on the content
            local reasonText = entry.reason or "Unknown Reason"
            
            -- Check for the specific "Ignored Zone" format
            local zoneName = reasonText:match("Ignored Zone: (.+)")
            if zoneName then
                -- Change "Ignored Zone: Baradin Hold" to "Baradin Hold (ignored zone)"
                reasonText = string.format("%s (ignored zone)", zoneName)
            else
                -- Check for the specific "PvP Zone" format
                local pvpZoneName = reasonText:match("PvP Zone: (.+)")
                if pvpZoneName then
                    -- Change "PvP Zone: Warsong Gulch" to "Warsong Gulch (PvP zone)"
                    reasonText = string.format("%s (PvP zone)", pvpZoneName)
                end
                -- Other reasons like "Not in a designated city" or "Blizzard Ignore List" remain as is.
            end

            LFGBuddy.Print(string.format("  %s - Reason: %s", entry.name, reasonText), true, isChatNotifEnabled)
        end
    end

    if not LFGBuddy.whisperQueue or #LFGBuddy.whisperQueue == 0 then
        LFGBuddy.Print("Whisper queue is empty.", false, isChatNotifEnabled)
        return
    end

    LFGBuddy.Print("--- Whisper queue (" .. #LFGBuddy.whisperQueue .. ") ---", false, isChatNotifEnabled)
    for i, entry in ipairs(LFGBuddy.whisperQueue) do
        -- MODIFIED LINE: Use the helper function to color the class name before printing
        local coloredClass = LFGBuddy.GetColoredClassName(entry.class)
		LFGBuddy.Print(string.format("  %s %s %s (%s)", 
            entry.level,
            coloredClass,
			entry.name,  
            entry.zone
        ),true, isChatNotifEnabled)
        --LFGBuddy.Print(string.format("  %s - %s %s %s", entry.name, entry.level, coloredClass, entry.zone),true, isChatNotifEnabled)
    end
    
    LFGBuddy.Print("Queued " .. #LFGBuddy.whisperQueue .. " whispers.", false, isChatNotifEnabled)
end

-- Whisper pacing
local eventFrame = CreateFrame("Frame")
eventFrame:SetScript("OnUpdate", function(self, elapsed)
    if LFGBuddy.sending then
        LFGBuddy.sendTimer = (LFGBuddy.sendTimer or 0) + elapsed
        if LFGBuddy.sendTimer >= (LFGBuddyOptions.spamInterval or 1.0) then
            LFGBuddy.sendTimer = 0
            local entry = tremove(LFGBuddy.whisperQueue, 1)
            if entry then
                local now = time()
                local last = LFGBuddyOptions.recentMessageRecipients[entry.name]
                -- Re-check lockout just in case (e.g. settings changed while sending)
                local lockoutSecs = (LFGBuddyOptions.spamLockoutMins or 30) * 60
                if not last or (now - last) > lockoutSecs or LFGBuddyOptions.ignoreRecipientLockout then
                    local msg = LFGBuddy.messageEdit:GetText() or ""
                    SendChatMessage(msg, "WHISPER", nil, entry.name)
                    LFGBuddyOptions.recentMessageRecipients[entry.name] = now
					LFGBuddy.whispersSentSinceStart = LFGBuddy.whispersSentSinceStart + 1 -- Increment counter

					-- Check for auto-pause
					if LFGBuddy.whispersSentSinceStart >= (LFGBuddyOptions.autoPauseCount or 50) then
						LFGBuddy.sending = false
						if LFGBuddy_StartPauseButton then
							LFGBuddy_StartPauseButton:SetText("Send")
						end
						LFGBuddy.Print("|cffFF0000Auto-paused:|r Reached " .. (LFGBuddyOptions.autoPauseCount or 50) .. " whispers.",false,true)
						LFGBuddy.UpdateButtonStates()
						return -- Stop sending immediately
					end

                else
                    LFGBuddy.Print("Skipped " .. entry.name .. " (lockout active)")
                end
            else
                LFGBuddy.sending = false
                if LFGBuddy_StartPauseButton then
                    LFGBuddy_StartPauseButton:SetText("Send") -- reset the button
                end
                LFGBuddy.Print("Whispers sent to all in queue.",false,true)
				LFGBuddy.UpdateButtonStates()
            end
        end
    end
end)

function LFGBuddy.ClearMessageFocus()
    if LFGBuddy.messageEdit and LFGBuddy.messageEdit:HasFocus() then
        LFGBuddy.messageEdit:ClearFocus()
    end
end

-- Main Frame
function LFGBuddyUI()
    if LFGBuddy.frame then return end
	
    local f = CreateFrame("Frame", "LFGBuddyFrame", UIParent)
    f:SetSize(345, 110)
    f:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        edgeSize = 10
    })
    f:ClearAllPoints()
	if LFGBuddyOptions.framePoint then
		f:SetPoint(
			LFGBuddyOptions.framePoint,
			UIParent,
			LFGBuddyOptions.frameRelativePoint,
			LFGBuddyOptions.frameX,
			LFGBuddyOptions.frameY
		)
	else
		f:SetPoint("CENTER")
	end
	f:SetScript("OnDragStart", f.StartMoving) 
	f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetBackdropColor(0,0,0,0.8)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")

    -- Options "Label" Button
    local optionsBtn = CreateFrame("Button", "LFGBuddyOptionsFrame_OptionsButton", f)
	optionsBtn:SetSize(45, 16)
	optionsBtn:SetPoint("TOPRIGHT", f, "TOPRIGHT", -37, 15)
	
	-- Create a font string for the button
	local fontString = optionsBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	fontString:SetText("Options")
	fontString:SetAllPoints(optionsBtn)
	fontString:SetFont("Fonts\\FRIZQT__.TTF", 10)
	fontString:SetTextColor(1, 1, 1) -- Default white color
	optionsBtn.fontString = fontString

	optionsBtn:SetScript("OnClick", function()
		LFGBuddyOptionsUI()
		if LFGBuddyOptionsFrame:IsShown() then
			LFGBuddyOptionsFrame:Hide()
			optionsBtn:UnlockHighlight()
			fontString:SetTextColor(1, 1, 1) -- White
			
		else
			LFGBuddyOptionsFrame:Show()
			LFGBuddyOptionsFrame:SetPoint("TOPLEFT", f, "TOPRIGHT", -1, 0) 
			optionsBtn:LockHighlight()
			fontString:SetTextColor(1.0, 0.82, 0.0) -- Blizzard Gold
            
            -- Ensure Roles frame is hidden and its button is reset
            --if LFGBuddyRolesFrame and LFGBuddyRolesFrame:IsShown() then
            --    LFGBuddyRolesFrame:Hide()
            --    if LFGBuddyRolesFrame_RolesButton then
            --        LFGBuddyRolesFrame_RolesButton:UnlockHighlight()
            --        LFGBuddyRolesFrame_RolesButton.fontString:SetTextColor(1, 1, 1)
            --    end
            --end
		end
	end)
    
    -- NEW: Roles "Label" Button (Left of Options)
    local rolesBtn = CreateFrame("Button", "LFGBuddyRolesFrame_RolesButton", f)
	rolesBtn:SetSize(45, 16)
	-- Anchor to the left of the Options button
	rolesBtn:SetPoint("RIGHT", optionsBtn, "LEFT", 5, 0)
	
	-- Create a font string for the button
	local rolesFontString = rolesBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	rolesFontString:SetText("Roles")
	rolesFontString:SetAllPoints(rolesBtn)
	rolesFontString:SetFont("Fonts\\FRIZQT__.TTF", 10)
	rolesFontString:SetTextColor(1, 1, 1) -- Default white color
	rolesBtn.fontString = rolesFontString

	rolesBtn:SetScript("OnClick", function()
		LFGBuddyRolesUI() -- Ensure the frame exists/is created
		if LFGBuddyRolesFrame:IsShown() then
			f:SetHeight(110)
			LFGBuddyRolesFrame:Hide()
			rolesBtn:UnlockHighlight()
			rolesFontString:SetTextColor(1, 1, 1) -- White
			LFGBuddyOptions.isRolesOpen = false 
		else
			f:SetHeight(217)
			-- Show and snap the new Roles frame
			LFGBuddyRolesFrame:Show()
			LFGBuddyRolesFrame:ClearAllPoints()
			-- Snap to the BOTTOM of the main LFGBuddy frame, and move 5 pixels UP
			LFGBuddyRolesFrame:SetPoint("TOPLEFT", f, "BOTTOMLEFT", 0, 114) 
            
			LFGBuddyOptions.isRolesOpen = true
			rolesBtn:LockHighlight()
			rolesFontString:SetTextColor(1.0, 0.82, 0.0) -- Blizzard Gold
            
            -- Ensure Options frame is hidden and its button is reset
            --if LFGBuddyOptionsFrame and LFGBuddyOptionsFrame:IsShown() then
            --    LFGBuddyOptionsFrame:Hide()
            --    if LFGBuddyOptionsFrame_OptionsButton then
            --        LFGBuddyOptionsFrame_OptionsButton:UnlockHighlight()
            --        LFGBuddyOptionsFrame_OptionsButton.fontString:SetTextColor(1, 1, 1)
            --    end
            --end
		end
	end)
    
    -- NEW: Minimize Button (left of Roles button)
    local minimizeBtn = CreateFrame("Button", "LFGBuddy_MinimizeButton", f)
	minimizeBtn:SetSize(45, 16)
	minimizeBtn:SetPoint("LEFT", optionsBtn, "RIGHT", -5, 0)
	
	-- Create a font string for the button
	local minFontString = minimizeBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	minFontString:SetText("Hide")
	minFontString:SetAllPoints(minimizeBtn)
	minFontString:SetFont("Fonts\\FRIZQT__.TTF", 10)
	minFontString:SetTextColor(1, 1, 1)
	minimizeBtn.fontString = minFontString

	minimizeBtn:SetScript("OnClick", function()
        -- Save the current position before hiding
        local x, y = f:GetCenter()
        if x and y then
            LFGBuddyOptions.framePoint = "CENTER"
            LFGBuddyOptions.frameRelativePoint = "CENTER"
            LFGBuddyOptions.frameX = x - (UIParent:GetWidth() / 2)
            LFGBuddyOptions.frameY = y - (UIParent:GetHeight() / 2)
        end
		
		LFGBuddy.sending = false
		LFGBuddy.whisperQueue = {}
		LFGBuddy.excludedPlayers = {}
		LFGBuddy.whispersSentSinceStart = 0
		if LFGBuddy_StartPauseButton then
			LFGBuddy_StartPauseButton:SetText("Send")
		end
		LFGBuddy.UpdateButtonStates()
        
        LFGBuddyOptions.ToggleInactiveMode = true
        f:Hide()
        LFGBuddyOptionsFrame:Hide() -- Also hide options frame
        
        -- HIDE ROLES FRAME and reset its button
        if LFGBuddyRolesFrame then
            LFGBuddyRolesFrame:Hide()
            if LFGBuddyRolesFrame_RolesButton then
                LFGBuddyRolesFrame_RolesButton:UnlockHighlight()
                LFGBuddyRolesFrame_RolesButton.fontString:SetTextColor(1, 1, 1)
            end
        end
        
        LFGBuddyPassiveUI() -- Ensure passive frame exists
        LFGBuddyPassiveFrame:Show()
		
        if WhoFrame and WhoFrame:IsShown() then
            LFGBuddyPassiveFrame:Show()
            SnapPassiveToWhoFrame() -- Call the function to snap the passive frame
        end
		
        LFGBuddy.Print("Set to passive mode.", false, true)
	end)

	-- Main Content Panel
	local mainPanel = CreateFrame("Frame", nil, f)
	mainPanel:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -45)
	mainPanel:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -10, 10)
	
    -- Class Label
    local classLabel = mainPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	classLabel:SetFont("Fonts\\FRIZQT__.TTF", 10) 
    classLabel:SetPoint("TOPLEFT", mainPanel, "TOPLEFT", -2, 40)
    classLabel:SetText("Class")

    -- Class Dropdown
    local classDrop = CreateFrame("Frame", "LFGBuddy_ClassDropDown", mainPanel, "UIDropDownMenuTemplate")
    classDrop:SetPoint("TOPLEFT", classLabel, "TOPLEFT", -17, -11)
    UIDropDownMenu_SetWidth(classDrop, 80)

	-- Ensure lastClass is valid
	if not LFGBuddyOptions.lastClass and LFGBuddyOptions.classes and #LFGBuddyOptions.classes > 0 then
		LFGBuddyOptions.lastClass = LFGBuddyOptions.classes[1]
	end

	-- Initialize the dropdown buttons
	UIDropDownMenu_Initialize(classDrop, function(self, level, menuList)
        local info = UIDropDownMenu_CreateInfo()

        if LFGBuddyOptions.classes then
            -- Your existing logic to populate allClasses
            local allClasses = {}
            for _, v in ipairs(LFGBUDDY_DEFAULT_CLASSES) do table.insert(allClasses, v) end
            
            -- Add custom classes not in the default list
            for _, v in ipairs(LFGBUDDY_DEFAULT_CLASSES) do
                local isDefault = false
                for _, def in ipairs(LFGBUDDY_DEFAULT_CLASSES) do
                    if v == def then isDefault = true; break end
                end
                if not isDefault then
                    table.insert(allClasses, v)
                end
            end
            
            local totalItems = #allClasses
            -- Set the trigger index to place the separator before the last 3 items
            local separatorTriggerIndex = totalItems - 2 
            
            for i, v in ipairs(allClasses) do
                
                -- 1. Insert the separator
                if i == separatorTriggerIndex then
                    local separatorInfo = UIDropDownMenu_CreateInfo()
                    separatorInfo.text = " "
                    separatorInfo.isTitle = true
                    UIDropDownMenu_AddButton(separatorInfo)
                end
                
                -- 2. Add the regular button. Reset all flags first.
				local coloredText = LFGBuddy.GetColoredClassName(v)
                info.text, info.value = coloredText, v
                info.func = function(self)
                    UIDropDownMenu_SetSelectedValue(classDrop, self.value)
                    UIDropDownMenu_SetText(classDrop, LFGBuddy.GetColoredClassName(self.value))
                    LFGBuddyOptions.lastClass = self.value
                end
                info.checked = (v == LFGBuddyOptions.lastClass)
                
                -- 🔥 FIX: Explicitly clear all conflicting flags and ensure it's enabled.
                info.isTitle = nil 
                info.notCheckable = nil
                info.disabled = false -- Ensures the item is clickable and not grayed out
                
                UIDropDownMenu_AddButton(info)
            end
        end
    end)

	-- Set the selected value and visible text immediately
	UIDropDownMenu_SetSelectedValue(classDrop, LFGBuddyOptions.lastClass)
	UIDropDownMenu_SetText(classDrop, LFGBuddy.GetColoredClassName(LFGBuddyOptions.lastClass))

	-- Refresh dropdown when clicked
	classDrop:HookScript("OnShow", function()
		UIDropDownMenu_Initialize(classDrop, nil)
	end)
	
-- Main.lua - The updated LFGBuddy.CreateLevelDropdown function
	
	function LFGBuddy.CreateLevelDropdown(name, initialValue, optionKey, parent, anchorTo, xOff, yOff)
		local drop = CreateFrame("Frame", name, parent, "UIDropDownMenuTemplate")
		drop:SetPoint("LEFT", anchorTo, "RIGHT", xOff or 0, yOff or 0)
		UIDropDownMenu_SetWidth(drop, 40)

		UIDropDownMenu_Initialize(drop, function()
			local info = UIDropDownMenu_CreateInfo()
			local playerLevel = UnitLevel("player")
			local minLevel = math.max(1, playerLevel - 8)
			local maxLevel = math.min(60, playerLevel + 8)
            
            -- Determine the end of the iteration range
            local iterationEnd = maxLevel
            -- NEW ADDITION: If the max level is 60, stop the main loop at 59 
            -- to allow 60 to be added manually as the last item.
            if maxLevel == 60 then
                iterationEnd = 59
            end

            -- Loop through the standard range (e.g., 13-29, or 52-59)
			for lvl = minLevel, iterationEnd do
				info.text, info.value = tostring(lvl), lvl
				info.func = function(self)
					UIDropDownMenu_SetSelectedValue(drop, self.value)
					LFGBuddyOptions[optionKey] = self.value
				end
				info.checked = (lvl == LFGBuddyOptions[optionKey])
				UIDropDownMenu_AddButton(info)
			end
            
            -- NEW ADDITION: Add 60 explicitly as the final option
            if maxLevel <= 60 then
                info.text, info.value = "60", 60
                info.func = function(self)
                    UIDropDownMenu_SetSelectedValue(drop, self.value)
                    LFGBuddyOptions[optionKey] = self.value
                end
                info.checked = (60 == LFGBuddyOptions[optionKey])
                UIDropDownMenu_AddButton(info)
            end
            
		end)

		-- Update initial value based on current option
		UIDropDownMenu_SetSelectedValue(drop, LFGBuddyOptions[optionKey] or initialValue)

		return drop
	end

	-- Min Level Dropdown + Label
	local minDrop = LFGBuddy.CreateLevelDropdown("LFGBuddy_MinDrop",
		LFGBuddyOptions.minLevel, "minLevel",
		mainPanel, classDrop, -27, 0)
	local minLabel = mainPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	minLabel:SetPoint("TOPLEFT", minDrop, "TOPLEFT", 17, 11)
	minLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)
	minLabel:SetText("Min Level")

	-- Max Level Dropdown + Label
	local maxDrop = LFGBuddy.CreateLevelDropdown("LFGBuddy_MaxDrop",
		LFGBuddyOptions.maxLevel, "maxLevel",
		mainPanel, minDrop, -27, 0)
	local maxLabel = mainPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	maxLabel:SetPoint("TOPLEFT", maxDrop, "TOPLEFT", 17, 11)
	maxLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)
	maxLabel:SetText("Max Level")

	-- Message Label
	local msgLabel = mainPanel:CreateFontString(nil,"OVERLAY","GameFontNormal")
	msgLabel:SetPoint("TOPLEFT", classLabel, "BOTTOMLEFT", 0, -33)
	msgLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)
	msgLabel:SetText("Message")

	-- Message Edit Box
	local messageEdit = CreateFrame("EditBox", "LFGBuddy_MessageEditBox", mainPanel, "InputBoxTemplate")
	messageEdit:SetSize(300, 20)
	messageEdit:SetPoint("TOPLEFT", msgLabel, "BOTTOMLEFT", 6, -2)
	messageEdit:SetAutoFocus(false)
	messageEdit:SetText(LFGBuddyOptions.recentSentMessages[1] or "")
	LFGBuddy.messageEdit = messageEdit

	-- Recent Messages Dropdown
	local messageDrop = CreateFrame("Frame", "LFGBuddy_MessageDropdown", mainPanel, "UIDropDownMenuTemplate")
	messageDrop:SetPoint("LEFT", messageEdit, "RIGHT", -18, -3)
	UIDropDownMenu_SetWidth(messageDrop, 10)
	LFGBuddy.messageDrop = messageDrop

	-- Function to refresh dropdown menu
	function LFGBuddy.RefreshMessageDropdown()
		UIDropDownMenu_Initialize(messageDrop, function(self, level)
			local info = UIDropDownMenu_CreateInfo()
			for _, msg in ipairs(LFGBuddyOptions.recentSentMessages or {}) do
				info.text = msg
				info.func = function()
					messageEdit:SetText(msg)
					LFGBuddyOptions.message = msg
				end
				UIDropDownMenu_AddButton(info, level)
			end
		end)
	end
	LFGBuddy.RefreshMessageDropdown()

	-- Base vertical offset relative to classLabel
	local buttonYOffset = -67
	local buttonSpacing = 5
	local buttonWidth, buttonHeight = 60, 22
	local largeButtonWidth = 95

    -- Refresh /who button
    local refreshBtn = CreateFrame("Button", "LFGBuddy_RefreshButton", mainPanel, "UIPanelButtonTemplate")
    refreshBtn:SetSize(largeButtonWidth, buttonHeight)
    refreshBtn:SetPoint("TOPLEFT", classLabel, "BOTTOMLEFT", -1, buttonYOffset)
    refreshBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
    refreshBtn:SetText("Find players")
    refreshBtn:SetScript("OnClick", function()
        LFGBuddy.ClearMessageFocus()
        local selectedClassOrRole = LFGBuddyOptions.lastClass or UIDropDownMenu_GetSelectedValue(classDrop) or ""
        
        -- Use the helper function to get the final class query part.
        -- It returns a formatted query like 'c-"Class1" c-"Class2"', 
        -- or the original role/class string like 'Tank', 'Warrior', or 'Any'.
        local classQueryPart = LFGBuddy.GetRoleClassesQuery(selectedClassOrRole)

        local min = UIDropDownMenu_GetSelectedValue(minDrop) or LFGBuddyOptions.minLevel or 1
        local max = UIDropDownMenu_GetSelectedValue(maxDrop) or LFGBuddyOptions.maxLevel or 60
        
        local whoQuery = ""
        
        -- 1. Check for the custom multi-class format (e.g., 'c-"Paladin" c-"Warrior"')
        if classQueryPart:find('c-"') then
            whoQuery = classQueryPart .. " "
        -- 2. Check for "Any" or empty
        elseif classQueryPart == "Any" or classQueryPart == "" then
            -- whoQuery remains "" (no class filter)
        -- 3. Handle single class or simple role (e.g., 'Warrior', 'Tank', 'Healer')
        else
            -- Format single class/simple role: c-warrior or c-tank
            -- WoW /who is case-insensitive for classes/roles, but we lowercase it for standard query format.
            whoQuery = "c-" .. string.lower(classQueryPart) .. " "
        end
        
        whoQuery = whoQuery .. min .. "-" .. max
        
        if LFGBuddyOptions.queueCitiesOnly then
            for _, city in ipairs(LFGBuddyOptions.cities or {}) do
                whoQuery = whoQuery .. ' z-"' .. city .. '"'
            end
        -- NEW LOGIC: Add current zone to query
        elseif LFGBuddyOptions.queueCurrentZoneOnly then
            local currentZone = GetRealZoneText()
            if currentZone then
                whoQuery = whoQuery .. ' z-"' .. currentZone .. '"'
            else
                LFGBuddy.Print("Error: Could not determine current zone for /who query.")
                return
            end
        -- END NEW LOGIC
        end
        LFGBuddy.Print("Sending /who query: " .. whoQuery)
        SendWho(whoQuery)
        LFGBuddy.UpdateButtonStates()
    end)

	-- Show Queue button
	local showQueueBtn = CreateFrame("Button", "LFGBuddy_ShowQueueButton", mainPanel, "UIPanelButtonTemplate")
	showQueueBtn:SetSize(largeButtonWidth, buttonHeight)
	showQueueBtn:SetPoint("LEFT", refreshBtn, "RIGHT", buttonSpacing, 0)
	showQueueBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	showQueueBtn:SetText("Whisper who?")
	showQueueBtn:SetScript("OnClick", function()
		LFGBuddy.ClearMessageFocus()
		LFGBuddy.ShowWhisperQueue()
		LFGBuddy.UpdateButtonStates()
	end)

	-- Start/Pause toggle button
	local startBtn = CreateFrame("Button", "LFGBuddy_StartPauseButton", mainPanel, "UIPanelButtonTemplate")
	startBtn:SetSize(buttonWidth, buttonHeight)
	startBtn:SetPoint("LEFT", showQueueBtn, "RIGHT", 53, 0)
	startBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	startBtn:SetText("Send")
    startBtn:SetScript("OnEnter", function(self)
        -- Use the built-in GameTooltip frame
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        
        -- Set the title and main text using the new utility function
        GameTooltip:SetText("|cffffff00Click to Whisper|r", 1.0, 1.0, 0.0)
        -- LFGBuddy.GetWhisperQueueTooltipText() must be defined elsewhere in Main.lua
        GameTooltip:AddLine(LFGBuddy.GetWhisperQueueTooltipText(), 1.0, 1.0, 1.0, true)
        
        GameTooltip:Show()
    end)

    startBtn:SetScript("OnLeave", function(self)
        -- Hide the tooltip when the mouse leaves the button
        GameTooltip:Hide()
    end)
	
	startBtn:SetScript("OnClick", function()
		LFGBuddy.ClearMessageFocus()
		-- Pause logic
		if LFGBuddy.sending then
			LFGBuddy.sending = false
			startBtn:SetText("Send") -- Change to Start/Send
			LFGBuddy.Print("Whispers paused.",false,true)
			return
		end
		-- Start logic
		local msg = messageEdit:GetText() or ""
		local minChars = 10
		if #msg < minChars then
			LFGBuddy.Print("Message is too short to send, 10 characters is required.",false,true)
			return
		end

		-- Ensure queue exists
		if not LFGBuddy.whisperQueue or #LFGBuddy.whisperQueue == 0 then
			LFGBuddy.Print("Whisper queue is empty. Refresh first.",false,true)
			return
		end

		-- Update recentSentMessages
		LFGBuddyOptions.recentSentMessages = LFGBuddyOptions.recentSentMessages or {}
		for i = #LFGBuddyOptions.recentSentMessages, 1, -1 do
			if LFGBuddyOptions.recentSentMessages[i] == msg then
				table.remove(LFGBuddyOptions.recentSentMessages, i)
			end
		end
		table.insert(LFGBuddyOptions.recentSentMessages, 1, msg)
		while #LFGBuddyOptions.recentSentMessages > 10 do
			table.remove(LFGBuddyOptions.recentSentMessages)
		end
		LFGBuddyOptions.message = msg
		LFGBuddy.RefreshMessageDropdown()

		-- Pre-filter queue: remove anyone in lockout (this is redundant to UpdateWhisperQueue but good for safety if settings change)
		local now = time()
		local filteredQueue = {}
		local lockoutSecs = (LFGBuddyOptions.spamLockoutMins or 30) * 60
		for _, entry in ipairs(LFGBuddy.whisperQueue) do
			local last = LFGBuddyOptions.recentMessageRecipients[entry.name]
			if not last or (now - last) > lockoutSecs or LFGBuddyOptions.ignoreRecipientLockout then
				table.insert(filteredQueue, entry)
			else
				LFGBuddy.Print("Skipped " .. entry.name .. " (lockout active)")
			end
		end
		if #filteredQueue == 0 then
			LFGBuddy.Print("No players in whisper queue. Sending cancelled.")
			return
		end
		LFGBuddy.whisperQueue = filteredQueue

		LFGBuddy.sending = true
		LFGBuddy.sendTimer = 0
		LFGBuddy.whispersSentSinceStart = 0 -- Reset auto-pause counter
		LFGBuddy.UpdateButtonStates()
		startBtn:SetText("Pause") -- Switch button label
		LFGBuddy.Print("Sending whispers started.",false,true)
	end)

	-- Cities Only Checkbox (bare)
	local citiesCheckbox = CreateFrame("CheckButton", "LFGBuddy_CitiesCheckbox", mainPanel, "UICheckButtonTemplate")
	citiesCheckbox:SetPoint("LEFT", classLabel, "RIGHT", 200, -15)
	citiesCheckbox:SetSize(20, 20)
	citiesCheckbox:SetChecked(LFGBuddyOptions.queueCitiesOnly or false)
	-- Label next to checkbox
	local citiesLabel = mainPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	citiesLabel:SetPoint("LEFT", citiesCheckbox, "RIGHT", 4, 0)
	citiesLabel:SetText("Idling in town")
	citiesLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)
	-- OnClick handler for checkbox
	citiesCheckbox:SetScript("OnClick", function(self)
		LFGBuddy.ClearMessageFocus()
		LFGBuddy.ToggleQueueCitiesOnly(self:GetChecked())
		-- Update the 'In my zone' checkbox to reflect mutual exclusivity
		if self:GetChecked() then
			if LFGBuddy_CurrentZoneCheckbox then
				LFGBuddy_CurrentZoneCheckbox:SetChecked(false)
			end
		end
	end)

	-- NEW: Current Zone Checkbox (bare)
	local currentZoneCheckbox = CreateFrame("CheckButton", "LFGBuddy_CurrentZoneCheckbox", mainPanel, "UICheckButtonTemplate")
	currentZoneCheckbox:SetPoint("TOPLEFT", citiesCheckbox, "BOTTOMLEFT", 0, 0) -- Placed below Cities Only
	currentZoneCheckbox:SetSize(20, 20)
	currentZoneCheckbox:SetChecked(LFGBuddyOptions.queueCurrentZoneOnly or false)

	-- NEW: Label next to checkbox
	local currentZoneLabel = mainPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	currentZoneLabel:SetPoint("LEFT", currentZoneCheckbox, "RIGHT", 4, 0)
	currentZoneLabel:SetText("In my zone")
	currentZoneLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	-- NEW: OnClick handler for checkbox
	currentZoneCheckbox:SetScript("OnClick", function(self)
		LFGBuddy.ClearMessageFocus()
		LFGBuddy.ToggleQueueCurrentZoneOnly(self:GetChecked())
		-- Update the 'Idling in town' checkbox to reflect mutual exclusivity
		if self:GetChecked() then
			if LFGBuddy_CitiesCheckbox then
				LFGBuddy_CitiesCheckbox:SetChecked(false)
			end
		end
	end)

	LFGBuddy.frame = f
    f:Hide() -- Start hidden, show on WhoFrame_OnShow
end

-- Passive Frame
function LFGBuddyPassiveUI()
    if LFGBuddyPassiveFrame then return end
    
    local f = CreateFrame("Frame", "LFGBuddyPassiveFrame", UIParent)
    f:SetSize(110, 16)
    f:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        edgeSize = 10
    })
    f:ClearAllPoints()
    f:SetBackdropColor(0,0,0,0.8)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")

    -- Clickable Label
    local labelBtn = CreateFrame("Button", nil, f)
	labelBtn:SetAllPoints(f)
	
	local fontString = labelBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	fontString:SetText("|cff33ff99LFGBuddy|r: Passive")
	fontString:SetAllPoints(labelBtn)
	fontString:SetFont("Fonts\\FRIZQT__.TTF", 10)
	fontString:SetJustifyH("CENTER")
	fontString:SetJustifyV("MIDDLE")
	labelBtn.fontString = fontString

	labelBtn:SetScript("OnClick", function()
        LFGBuddyOptions.ToggleInactiveMode = false
        LFGBuddyPassiveFrame:Hide()
        LFGBuddyUI() -- Ensure main frame exists
        LFGBuddyOptionsUI() -- Ensure options frame exists
        LFGBuddyRolesUI() -- Ensure roles frame exists
        LFGBuddy.frame:Show()
        LFGBuddy.Print("Switched to active mode.", false, true)

        if WhoFrame and WhoFrame:IsShown() then
            SnapToWhoFrame() -- Snap the main frame
        end
		
		
		-- *** NEW LOGIC TO RESTORE ROLES FRAME STATE ***
		if LFGBuddyOptions and LFGBuddyOptions.isRolesOpen then
			local rolesFrame = LFGBuddyRolesFrame
			local rolesBtn = LFGBuddyRolesFrame_RolesButton
			
			if f and rolesFrame and rolesBtn then
				f:SetHeight(217) -- Expanded size (using your size)
				rolesFrame:Show()
				
				-- Restore the custom snap point
				rolesFrame:ClearAllPoints()
				rolesFrame:SetPoint("TOPLEFT", f, "BOTTOMLEFT", 0, 114)
				
				-- Update button state
				rolesBtn:LockHighlight()
				rolesBtn.fontString:SetTextColor(1.0, 0.82, 0.0)
				
				-- Ensure Options is hidden
				if LFGBuddyOptionsFrame then
					LFGBuddyOptionsFrame:Hide()
				end
			end
		else
			-- Ensure default state (shrunk) if Roles was not open
			f:SetHeight(110)
		end
		-- *** END NEW LOGIC ***
	end)
    
    f:Hide() -- Start hidden, show on WhoFrame_OnShow
end

-- Options Frame
function LFGBuddyOptionsUI()
	if LFGBuddyOptionsFrame then return end
	
    local f = CreateFrame("Frame", "LFGBuddyOptionsFrame", UIParent)
    f:SetSize(337, 330) -- Increased size to accommodate the new vertical stack
    f:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        edgeSize = 10
    })
    f:ClearAllPoints()
	f:SetPoint("CENTER")
	--f:SetScript("OnDragStart", f.StartMoving) 
	--f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetBackdropColor(0,0,0,0.8)
    --f:SetMovable(true)
    --f:EnableMouse(true)
    --f:RegisterForDrag("LeftButton")

	-- Title
    local title = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    title:SetPoint("TOPLEFT", 6, -6)
    title:SetFont("Fonts\\FRIZQT__.TTF", 13) 
    title:SetText("LFG Buddy Options")

    -- Close button
    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", f, "TOPRIGHT", 4, 3)
    close:SetScript("OnClick", function()
        f:Hide()
		if LFGBuddyOptionsFrame_OptionsButton then
			LFGBuddyOptionsFrame_OptionsButton:UnlockHighlight()
			LFGBuddyOptionsFrame_OptionsButton.fontString:SetTextColor(1, 1, 1)
		end
    end)
	
	-- Separator
    local sep = f:CreateTexture(nil, "BACKGROUND")
    sep:SetColorTexture(0.5, 0.5, 0.5, 0.8)
	sep:SetAlpha(0.8)
    sep:SetHeight(1)
    sep:SetPoint("TOPLEFT", 5, -24)
    sep:SetPoint("TOPRIGHT", -5, -24)
	sep:SetDrawLayer("BACKGROUND", 1)
	
	local contentFrame = CreateFrame("Frame", nil, f)
	contentFrame:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -35)
	contentFrame:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -10, 10)

	-- Layout Constants
	local col1_x = 5
	local col1_y = 8
	local row_spacing = -10
    local button_width = 100
    local buttonSpacing = 5 
    local slider_width = 150
    
    -- Tracks the last placed element for vertical anchoring
    local current_anchor = contentFrame

	-- 1. "Disable Notifications" Checkbox (Stays at the very top)
	local disableNotificationsCheckbox = CreateFrame("CheckButton", "LFGBuddy_DisableNotificationsCheckbox", contentFrame, "UICheckButtonTemplate")
	disableNotificationsCheckbox:SetPoint("TOPLEFT", current_anchor, "TOPLEFT", col1_x, col1_y)
	disableNotificationsCheckbox:SetSize(20, 20)
	disableNotificationsCheckbox:SetChecked(LFGBuddyOptions.disableaddonnotifications or false)

	local disableNotificationsLabel = contentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	disableNotificationsLabel:SetPoint("LEFT", disableNotificationsCheckbox, "RIGHT", 4, 0)
	disableNotificationsLabel:SetText("Disable addon chat notifications")
	disableNotificationsLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	disableNotificationsCheckbox:SetScript("OnClick", function(self)
		LFGBuddyOptions.disableaddonnotifications = self:GetChecked()
		LFGBuddy.Print("Addon chat notifications " .. (self:GetChecked() and "disabled." or "enabled."),false,true)
	end)
    
    current_anchor = disableNotificationsCheckbox
    
    -- 2. Toggle PvP Zones Checkbox
	local togglePvPCheckbox = CreateFrame("CheckButton", "LFGBuddy_TogglePvPCheckbox", contentFrame, "UICheckButtonTemplate")
	togglePvPCheckbox:SetPoint("TOPLEFT", current_anchor, "BOTTOMLEFT", 0, row_spacing)
	togglePvPCheckbox:SetSize(20, 20)
	togglePvPCheckbox:SetChecked(LFGBuddyOptions.togglepvpzones or false)

	local togglePvPLabel = contentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	togglePvPLabel:SetPoint("LEFT", togglePvPCheckbox, "RIGHT", 4, 0)
	togglePvPLabel:SetText("Exclude players in PvP zones from whisper queue")
	togglePvPLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	togglePvPCheckbox:SetScript("OnClick", function(self)
		LFGBuddyOptions.togglepvpzones = self:GetChecked()
		LFGBuddy.Print("PvP zone filtering " .. (self:GetChecked() and "enabled." or "disabled."), false, true)
	end)
    
    current_anchor = togglePvPCheckbox

	-- 3. Ignore Recipient Lockout Checkbox
	local ignoreLockoutCheckbox = CreateFrame("CheckButton", "LFGBuddy_IgnoreLockoutCheckbox", contentFrame, "UICheckButtonTemplate")
	ignoreLockoutCheckbox:SetPoint("TOPLEFT", current_anchor, "BOTTOMLEFT", 0, row_spacing)
	ignoreLockoutCheckbox:SetSize(20, 20)
	ignoreLockoutCheckbox:SetChecked(LFGBuddyOptions.ignoreRecipientLockout or false)

	local ignoreLockoutLabel = contentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	ignoreLockoutLabel:SetPoint("LEFT", ignoreLockoutCheckbox, "RIGHT", 4, 0)
	ignoreLockoutLabel:SetText("Ignore spam lockouts")
	ignoreLockoutLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	ignoreLockoutCheckbox:SetScript("OnClick", function(self)
		LFGBuddyOptions.ignoreRecipientLockout = self:GetChecked()
		LFGBuddy.Print("Spam lockouts are now " .. (self:GetChecked() and "ignored." or "respected."), false, true)
	end)
    
    current_anchor = ignoreLockoutCheckbox

	-- 4. Spam Lockout Minutes Slider
	local spamSlider = CreateFrame("Slider", "LFGBuddy_SpamLockoutSlider", contentFrame, "OptionsSliderTemplate")
	spamSlider:SetMinMaxValues(5, 60)
	spamSlider:SetValueStep(1)
	spamSlider:SetWidth(slider_width)
	spamSlider:SetValue(LFGBuddyOptions.spamLockoutMins or 30)
	spamSlider:ClearAllPoints()
	-- Anchor below checkbox, move left slightly and adjust for slider height
	spamSlider:SetPoint("TOPLEFT", current_anchor, "BOTTOMLEFT", 2, row_spacing-15)

	-- Hide Low/High Text
	if spamSlider.Low then spamSlider.Low:SetText("") end
	if spamSlider.High then spamSlider.High:SetText("") end

	-- Slider label
	local spamLabel = contentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	spamLabel:SetPoint("TOPLEFT", spamSlider, "TOPLEFT", 0, 10)
	spamLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	local spamScript = function(self, value)
		value = math.floor(value + 0.5)
		LFGBuddyOptions.spamLockoutMins = value
		spamLabel:SetText("Lockout whispers to the same player for " .. value .. " minutes")
	end
    spamSlider:SetScript("OnValueChanged", spamScript)
    spamScript(spamSlider, LFGBuddyOptions.spamLockoutMins or 30) -- Initial label text

    current_anchor = spamSlider

    -- 5. Show Lockouts Button
	local showLockoutsBtn = CreateFrame("Button", "LFGBuddy_ShowLockoutsButton", contentFrame, "UIPanelButtonTemplate")
	showLockoutsBtn:SetSize(button_width, 22)
	-- Anchor below slider
	showLockoutsBtn:SetPoint("TOPLEFT", current_anchor, "BOTTOMLEFT", -2, row_spacing - 10) 
	showLockoutsBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	showLockoutsBtn:SetText("Show Lockouts")
	showLockoutsBtn:SetScript("OnClick", function()
		LFGBuddy.PrintLockouts()
	end)
    
    -- 6. Reset lockouts button (Horizontal anchor to Show Lockouts)
	local resetRecipientsBtn = CreateFrame("Button", "LFGBuddy_ResetRecipientsButton", contentFrame, "UIPanelButtonTemplate")
	resetRecipientsBtn:SetSize(button_width, 22)
	resetRecipientsBtn:SetPoint("LEFT", showLockoutsBtn, "RIGHT", buttonSpacing, 0)
	resetRecipientsBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	resetRecipientsBtn:SetText("Reset lockouts")
	resetRecipientsBtn:SetScript("OnClick", function()
		LFGBuddyOptions.recentMessageRecipients = {}
		LFGBuddy.Print("Spam lockouts cleared.", false, true)
	end)

    current_anchor = showLockoutsBtn

	-- 7. Auto-Pause Count Slider
	local autoPauseSlider = CreateFrame("Slider", "LFGBuddy_AutoPauseSlider", contentFrame, "OptionsSliderTemplate")
	autoPauseSlider:SetMinMaxValues(1, 50)
	autoPauseSlider:SetValueStep(1)
	autoPauseSlider:SetWidth(slider_width)
	autoPauseSlider:ClearAllPoints()
	-- Anchor below Show Lockouts button
	autoPauseSlider:SetPoint("TOPLEFT", current_anchor, "BOTTOMLEFT", 0, row_spacing-15)
	
    local initialAutoPauseValue = LFGBuddyOptions.autoPauseCount or 50
	autoPauseSlider:SetValue(initialAutoPauseValue)
	
	if autoPauseSlider.Value then autoPauseSlider.Value:Hide() end
    
	-- Slider label
	local autoPauseLabel = contentFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	autoPauseLabel:SetPoint("TOPLEFT", autoPauseSlider, "TOPLEFT", 0, 10)
	autoPauseLabel:SetFont("Fonts\\FRIZQT__.TTF", 10)

	local autoPauseScript = function(self, value)
		value = math.floor(value + 0.5)
		LFGBuddyOptions.autoPauseCount = value
		autoPauseLabel:SetText("Auto-pause whispers when " .. value .. " has been sent")
	end
	
	autoPauseSlider:SetScript("OnValueChanged", autoPauseScript)
    autoPauseScript(autoPauseSlider, initialAutoPauseValue)

    current_anchor = autoPauseSlider

    -- 8. Show Ignore Zones Button (Starting point for the first horizontal row of action buttons)
	local showIgnoreZonesBtn = CreateFrame("Button", "LFGBuddy_ShowIgnoreZonesButton", contentFrame, "UIPanelButtonTemplate")
	showIgnoreZonesBtn:SetSize(button_width, 22)
	-- Anchor below Auto-Pause Slider
	showIgnoreZonesBtn:SetPoint("TOPLEFT", current_anchor, "BOTTOMLEFT", -2, row_spacing - 10)
	showIgnoreZonesBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	showIgnoreZonesBtn:SetText("Ignore zones?")
	showIgnoreZonesBtn:SetScript("OnClick", function()
		LFGBuddy.PrintIgnoreZones()
	end)
    
    local horizontal_anchor = showIgnoreZonesBtn 

	-- 9. Show PvP Zones Button (Horizontal anchor to Show Ignore Zones)
	local showPvPZonesBtn = CreateFrame("Button", "LFGBuddy_ShowPvPZonesButton", contentFrame, "UIPanelButtonTemplate")
	showPvPZonesBtn:SetSize(button_width, 22)
	showPvPZonesBtn:SetPoint("LEFT", horizontal_anchor, "RIGHT", buttonSpacing, 0)
	showPvPZonesBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	showPvPZonesBtn:SetText("PvP zones?")
	showPvPZonesBtn:SetScript("OnClick", function()
		LFGBuddy.PrintPvPZones()
	end)
    
    horizontal_anchor = showPvPZonesBtn

    -- 10. Toggle Faction Button (Horizontal anchor to Show PvP Zones)
	local isHorde = false
    for _, city in ipairs(LFGBuddyOptions.cities) do
        if city == "Orgrimmar" then
            isHorde = true
            break
        end
    end
	local toggleFactionBtn = CreateFrame("Button", "LFGBuddy_ToggleFactionButton", contentFrame, "UIPanelButtonTemplate")
	toggleFactionBtn:SetSize(button_width, 22)
	toggleFactionBtn:SetPoint("LEFT", horizontal_anchor, "RIGHT", buttonSpacing, 0)
	toggleFactionBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	toggleFactionBtn:GetFontString():SetText("Switch faction")
	toggleFactionBtn:SetScript("OnClick", function()
		LFGBuddy.ToggleCities()
	end)

	-- 11. Reset Defaults Button (Vertical anchor to Show Ignore Zones, with extra spacing)
    local extra_spacing = row_spacing - 10
	local resetDefaultsBtn = CreateFrame("Button", "LFGBuddy_ResetDefaultsButton", contentFrame, "UIPanelButtonTemplate")
	resetDefaultsBtn:SetSize(button_width, 22)
	resetDefaultsBtn:SetPoint("TOPLEFT", showIgnoreZonesBtn, "BOTTOMLEFT", 0, extra_spacing)
	resetDefaultsBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11)
	resetDefaultsBtn:SetText("Reset addon")
	resetDefaultsBtn:SetScript("OnClick", function()
		LFGBuddy.ResetDefaults()
	end)
    
    f:Hide()
    LFGBuddyOptionsFrame = f
end

-- Roles UI Frame
function LFGBuddyRolesUI()
    if LFGBuddyRolesFrame then return end
    
    local f = CreateFrame("Frame", "LFGBuddyRolesFrame", UIParent)
    f:SetSize(300, 115)
    f:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
       -- edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
       -- edgeSize = 10
		edgeFile = nil, 
        edgeSize = 0,
        insets = {left = 0, right = 0, top = 0, bottom = 0}
    })
    f:ClearAllPoints()
    -- It will be positioned by the LFGBuddyRolesFrame_RolesButton OnClick handler
    f:SetBackdropColor(0,0,0,0)
    f:SetMovable(false)
    f:EnableMouse(true)
    
    -- Assuming these are defined globally in your Main.lua
    local classes = {
        Tank = LFGBUDDY_DEFAULT_CLASSES_TANKS,
        Healer = LFGBUDDY_DEFAULT_CLASSES_HEALERS,
        DPS = LFGBUDDY_DEFAULT_CLASSES_DPS
    }
    
    local columnNames = {"Tank", "Healer", "DPS"}
    local columnCount = #columnNames
    local columnWidth = 290 / columnCount
    local checkboxWidth = 20
    local rowHeight = 18
    local labelFont = "Fonts\\FRIZQT__.TTF"

    -- Positioning Constants
    local HORIZONTAL_START_OFFSET = 9 -- 5px margin from left edge
    local VERTICAL_HEADER_OFFSET = -5 -- Positioning the header 5px from the top edge
    local PADDING_AFTER_HEADER = 5
    local MAX_ROWS_PER_COLUMN = 5
    
    -- New Spacing Constants for spillover columns
    local INNER_COLUMN_WIDTH = 60 -- Estimated width for Checkbox + Label text + small internal padding
    local INNER_COLUMN_GAP = 7   -- User-requested gap between inner columns (e.g., Tank-1 and Tank-2)
    local INNER_COLUMN_TOTAL_SPACING = INNER_COLUMN_WIDTH + INNER_COLUMN_GAP
    
    -- Calculate the vertical starting point for the first checkbox row.
    local START_Y_OFFSET = VERTICAL_HEADER_OFFSET - PADDING_AFTER_HEADER - 8 

    -- Role column headers
    for i, role in ipairs(columnNames) do
        local header = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        header:SetFont(labelFont, 10)
		header:SetTextColor(1, 1, 1)
        header:SetText(role)
        
        local xOffset = (i - 1) * columnWidth + HORIZONTAL_START_OFFSET
        
        header:SetPoint("TOPLEFT", f, "TOPLEFT", xOffset, VERTICAL_HEADER_OFFSET)
    end
    
    -- Function to create and position a checkbox with a label (unchanged)
    local function CreateClassCheckbox(parent, role, class, xOffset, yOffset)
        -- Create the checkbox
        local cbName = "LFGBuddyRolesUI_" .. role .. "_" .. class .. "Checkbox"
        local checkbox = CreateFrame("CheckButton", cbName, parent, "UICheckButtonTemplate")
        checkbox:SetSize(checkboxWidth, checkboxWidth)
        checkbox:SetPoint("TOPLEFT", parent, "TOPLEFT", xOffset, yOffset)

        -- Create the label
        local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        label:SetFont(labelFont, 9)
        label:SetText(LFGBuddy.GetColoredClassName(class))
        label:SetPoint("LEFT", checkbox, "RIGHT", 2, 0)
        
        -- Store in options if it doesn't exist (default to true/checked)
        LFGBuddyOptions.roleClassChecks = LFGBuddyOptions.roleClassChecks or {}
        local key = role .. "_" .. class
        if LFGBuddyOptions.roleClassChecks[key] == nil then
            LFGBuddyOptions.roleClassChecks[key] = true -- Default to checked
        end
        
        -- Set initial state
        checkbox:SetChecked(LFGBuddyOptions.roleClassChecks[key] ~= false)

		-- OnClick handler to save state
		checkbox:SetScript("OnClick", function(self)
        local isChecked = self:GetChecked()
        
        -- Save the state to the persistent LFGBuddyOptions table
        if isChecked then
            -- Set to nil for the default (checked) state to save space
            LFGBuddyOptions.roleClassChecks[key] = nil 
        else
            -- Only save 'false' when the checkbox is explicitly unchecked/excluded.
            LFGBuddyOptions.roleClassChecks[key] = false
        end
        
        -- Optional: If you want to update the /who list immediately:
        -- LFGBuddy.UpdateWhisperQueue() 
    end)
        
        return checkbox
    end
    
    -- Iterate through classes for each role column
    for i, role in ipairs(columnNames) do
        local classList = classes[role]
        
        -- Base X position for the role's first column
        local baseXOffset = (i - 1) * columnWidth + HORIZONTAL_START_OFFSET
        
        for j, class in ipairs(classList) do
            -- Calculate column/row index for the multi-column layout
            local currentColumn = math.floor((j - 1) / MAX_ROWS_PER_COLUMN)
            local rowIndex = (j - 1) % MAX_ROWS_PER_COLUMN
            
            -- Calculate X offset: Base X + (internal column index * total spacing: width + gap)
            local xOffset = baseXOffset + (currentColumn * INNER_COLUMN_TOTAL_SPACING)

            -- Calculate Y offset: START_Y_OFFSET - (row index * row height)
            local yOffset = START_Y_OFFSET - rowIndex * rowHeight 
            
            CreateClassCheckbox(f, role, class, xOffset, yOffset)
        end
    end

    LFGBuddyRolesFrame = f
    f:Hide()
end

function LFGBuddy.UpdateButtonStates()
    local queueEmpty = not LFGBuddy.whisperQueue or #LFGBuddy.whisperQueue == 0

    -- Start/Pause button: enabled if whisperQueue is NOT empty
    if LFGBuddy_StartPauseButton then
        if not queueEmpty then
            LFGBuddy_StartPauseButton:Enable()
        else
            LFGBuddy_StartPauseButton:Disable()
			LFGBuddy_StartPauseButton:SetText("Send") -- Ensure it resets to Send if queue is emptied
			LFGBuddy.sending = false -- Ensure runtime state matches
        end
    end
	
	-- Show Queue button: always enabled as Refresh is the only thing that needs to work before it
	if LFGBuddy_ShowQueueButton then
		LFGBuddy_ShowQueueButton:Enable()
	end
end


-- ======================================================
-- Event Frame and Initialization Hooks
-- ======================================================

-- Call OnFirstLoad upon LOGIN
local loadFrame = CreateFrame("Frame")
loadFrame:RegisterEvent("ADDON_LOADED")
loadFrame:SetScript("OnEvent", function(_, event, addonName)
    if addonName == ADDON_NAME then
        LFGBuddy.OnFirstLoad()
    end
end)

-- Who updates
local whoEventFrame = CreateFrame("Frame")
whoEventFrame:RegisterEvent("WHO_LIST_UPDATE")
whoEventFrame:SetScript("OnEvent", function(_, event)
    if event == "WHO_LIST_UPDATE" then
        -- Only update queue if not in inactive mode
        if not LFGBuddyOptions.ToggleInactiveMode and LFGBuddy.frame and LFGBuddy.frame:IsShown() then
            LFGBuddy.UpdateWhisperQueue()
        end
    end
end)

local saveFramePos = CreateFrame("Frame")
saveFramePos:RegisterEvent("PLAYER_LOGOUT")
saveFramePos:SetScript("OnEvent", function()
    -- Save position of the active frame if not in inactive mode
	if LFGBuddy.frame and not LFGBuddyOptions.ToggleInactiveMode then
		-- Get current position in relation to UIParent
		local x, y = LFGBuddy.frame:GetCenter()
		if x and y then
			LFGBuddyOptions.framePoint = "CENTER"
			LFGBuddyOptions.frameRelativePoint = "CENTER"
			LFGBuddyOptions.frameX = x - (UIParent:GetWidth() / 2)
			LFGBuddyOptions.frameY = y - (UIParent:GetHeight() / 2)
		end
    -- Save position of the passive frame if in inactive mode
	elseif LFGBuddyPassiveFrame and LFGBuddyOptions.ToggleInactiveMode then
		-- Get current position in relation to UIParent
		local x, y = LFGBuddyPassiveFrame:GetCenter()
		if x and y then
			LFGBuddyOptions.framePoint = "CENTER"
			LFGBuddyOptions.frameRelativePoint = "CENTER"
			LFGBuddyOptions.frameX = x - (UIParent:GetWidth() / 2)
			LFGBuddyOptions.frameY = y - (UIParent:GetHeight() / 2)
		end
	end
end)