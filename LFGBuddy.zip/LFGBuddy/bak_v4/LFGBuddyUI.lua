-- LFGBuddy UI for WoW 3.3.5
-- Requires LFGBuddy.lua to be loaded first

local function CreateUI()
    -- Only create UI once
    if LFGBuddy.frame then return end
    if not LFGBuddyOptions then return end
    local allClasses = ALL_CLASSES or {"Shaman","Paladin","Druid","Warrior","Warlock","Priest","Rogue","Mage","Hunter"}

    -- Main Frame
    local f = CreateFrame("Frame", "LFGBuddyFrame", UIParent)
    f:SetSize(600, 300)
    f:SetPoint("CENTER")
    f:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        edgeSize = 12
    })
    f:SetBackdropColor(0,0,0,0.8)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) self:StartMoving() end)
    f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)

    -- Header
    local header = CreateFrame("Frame", nil, f)
    header:SetPoint("BOTTOMLEFT", f, "TOPLEFT")
    header:SetSize(f:GetWidth(), 26)
    header:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        edgeSize = 12
    })
    header:SetBackdropColor(0,0,0,0.9)
    header:EnableMouse(true)

    -- Header title
    local title = header:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    title:SetPoint("LEFT", 10, 0)
    title:SetText("LFG Buddy")

    -- Close button
    local close = CreateFrame("Button", nil, header, "UIPanelCloseButton")
    close:SetPoint("RIGHT", -4, 0)
    close:SetScript("OnClick", function() f:Hide() end)

    -- Tabs
    local tabNames = {"LFM","Blacklist","Blacklist2"}
    local tabButtons, tabFrames = {}, {}

    for i, name in ipairs(tabNames) do
        -- Button
        local btn = CreateFrame("Button", nil, header, "UIPanelButtonTemplate")
        btn:SetSize(80,22)
        btn:SetPoint("LEFT", header, "LEFT", 50 + (i-1)*90, 0)
        btn:SetText(name)

        -- Frame
        local frame = CreateFrame("Frame", nil, f)
        frame:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -70)
        frame:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -10, 10)
        frame:Hide()

        -- Click logic
        btn:SetScript("OnClick", function()
            for j, other in ipairs(tabFrames) do
                other:SetShown(frame == other)
                tabButtons[j]:UnlockHighlight()
            end
            btn:LockHighlight()
        end)

        table.insert(tabButtons, btn)
        table.insert(tabFrames, frame)
    end
    tabButtons[1]:Click() -- Show first tab

    local lfmPanel = tabFrames[1]
    local blacklistPanel = tabFrames[2]
    local blacklist2Panel = tabFrames[3]

    -- === LFM Panel ===



    local classDrop = CreateFrame("Frame", "LFGBuddy_ClassDropDown", lfmPanel, "UIDropDownMenuTemplate")
    classDrop:SetPoint("TOPLEFT", -10, 45)
    UIDropDownMenu_SetWidth(classDrop, 80)

    UIDropDownMenu_Initialize(classDrop, function()
        local info = UIDropDownMenu_CreateInfo()
        for _, v in ipairs(allClasses) do
            info.text, info.value = v, v
            info.func = function(self)
                UIDropDownMenu_SetSelectedValue(classDrop, self.value)
                LFGBuddyOptions.lastClass = self.value
            end
            info.checked = (v == LFGBuddyOptions.lastClass)
            UIDropDownMenu_AddButton(info)
        end
    end)
    UIDropDownMenu_SetSelectedValue(classDrop, LFGBuddyOptions.lastClass)

-- Class Label
    local classLabel = lfmPanel:CreateFontString(nil,"OVERLAY","GameFontNormal")
    classLabel:SetPoint("TOPLEFT", classDrop, "TOPLEFT", 17, 13)
    classLabel:SetText("Class")

-- Min Level Dropdown
local minDrop = LFGBuddy.CreateLevelDropdown("LFGBuddy_MinDrop", LFGBuddyOptions.lastX, "lastX")
minDrop:SetPoint("LEFT", classDrop, "RIGHT", -20, 0)
minDrop:SetParent(lfmPanel)
minDrop:SetFrameLevel(classDrop:GetFrameLevel() + 2)

-- Min Level Label
local minLabel = lfmPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
minLabel:SetPoint("TOPLEFT", minDrop, "TOPLEFT", 17, 13)
minLabel:SetText("Min Level")

-- Max Level Dropdown
local maxDrop = LFGBuddy.CreateLevelDropdown("LFGBuddy_MaxDrop", LFGBuddyOptions.lastY, "lastY")
maxDrop:SetPoint("LEFT", minDrop, "RIGHT", -20, 0)
maxDrop:SetParent(lfmPanel)
maxDrop:SetFrameLevel(classDrop:GetFrameLevel() + 2)

-- Max Level Label
local maxLabel = lfmPanel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
maxLabel:SetPoint("TOPLEFT", maxDrop, "TOPLEFT", 17, 13)
maxLabel:SetText("Max Level")





    -- Cities checkbox
citiesCheckbox = CreateFrame("CheckButton", nil, lfmPanel, "UICheckButtonTemplate")
citiesCheckbox:SetPoint("LEFT", maxDrop, "RIGHT", 0, 1)
citiesCheckbox:SetSize(18, 18)
citiesCheckbox:SetChecked(LFGBuddyOptions.filterCities)

citiesCheckbox.label = citiesCheckbox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
citiesCheckbox.label:SetFont("Fonts\\FRIZQT__.TTF", 9) 
citiesCheckbox.label:SetPoint("LEFT", citiesCheckbox, "RIGHT", 2, 0)
citiesCheckbox.label:SetText("Cities only")

citiesCheckbox:SetScript("OnClick", function(self)
    LFGBuddyOptions.filterCities = self:GetChecked()
end)



    local edit = CreateFrame("EditBox", "LFGBuddy_MessageEdit", lfmPanel, "InputBoxTemplate")
    edit:SetPoint("TOPLEFT", classLabel, "BOTTOMLEFT", 6, -55)
    edit:SetSize(400,26)
    edit:SetAutoFocus(false)
    edit:SetText(LFGBuddyOptions.message or "")
    edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    edit:SetScript("OnEnterPressed", function(self)
        LFGBuddyOptions.message = self:GetText()
        self:ClearFocus()
    end)
    edit:SetScript("OnTextChanged", function(self)
        LFGBuddyOptions.message = self:GetText()
    end)

    -- Message box
    local msgLabel = lfmPanel:CreateFontString(nil,"OVERLAY","GameFontNormal")
    msgLabel:SetPoint("TOPLEFT", edit, "TOPLEFT", -6, 11)
    msgLabel:SetText("Message")

    -- Buttons
    local refreshBtn = CreateFrame("Button", "LFGBuddy_RefreshButton", lfmPanel, "UIPanelButtonTemplate")
    refreshBtn:SetPoint("BOTTOMLEFT", lfmPanel, "BOTTOMLEFT", 5, 3)
    refreshBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11) 
    refreshBtn:SetSize(96,24)
    refreshBtn:SetText("Refresh /who")
    refreshBtn:SetScript("OnClick", function()
        local classStr = string.lower(LFGBuddyOptions.lastClass)
        local min = UIDropDownMenu_GetSelectedValue(minDrop)
        local max = UIDropDownMenu_GetSelectedValue(maxDrop)
        local whoQuery = "c-"..classStr.." "..min.."-"..max
    -- Check if the citiesCheckbox is checked and append city filters ADD IGNOREZONES WHOQUERY
if citiesCheckbox:GetChecked() then
    for _, city in ipairs(LFGBuddyOptions.defaultCities) do
        whoQuery = whoQuery .. ' z-"' .. city .. '"'
    end
end
        LFGBuddy.Notify("/who "..whoQuery)
        SendWho(whoQuery)
    end)

-- Declare all button variables first
local sendBtn, pauseBtn, resetBtn

-- Send button
sendBtn = CreateFrame("Button", "LFGBuddy_SendButton", lfmPanel, "UIPanelButtonTemplate")
sendBtn:SetPoint("BOTTOMRIGHT", lfmPanel, "BOTTOMRIGHT", -5, 3)
sendBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11) 
sendBtn:SetSize(96, 24)
sendBtn:SetText("Send Whispers")
sendBtn:SetScript("OnClick", function()
    if #LFGBuddy.whisperQueue == 0 then
        LFGBuddy.Notify("No queued whispers. Run /who first.")
        return
    end
    LFGBuddy.sending = true
    LFGBuddy.sendTimer = LFGBuddyOptions.spamInterval or 1.0
    LFGBuddy.Notify("Started sending whispers.")
    pauseBtn:SetText("Pause")
end)

-- Pause button
pauseBtn = CreateFrame("Button", "LFGBuddy_PauseButton", lfmPanel, "UIPanelButtonTemplate")
pauseBtn:SetPoint("RIGHT", sendBtn, "LEFT", -5, 0)
pauseBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11) 
pauseBtn:SetSize(96, 24)
pauseBtn:SetText("Pause")
pauseBtn:SetScript("OnClick", function(self)
    if LFGBuddy.sending then
        LFGBuddy.sending = false
        LFGBuddy.Notify("Whisper sending paused.")
        self:SetText("Resume")
    else
        if #LFGBuddy.whisperQueue > 0 then
            LFGBuddy.sending = true
            LFGBuddy.sendTimer = LFGBuddyOptions.spamInterval or 1.0
            LFGBuddy.Notify("Whisper sending resumed.")
            self:SetText("Pause")
        else
            LFGBuddy.Notify("No queued whispers to resume.")
        end
    end
end)

-- Reset button
resetBtn = CreateFrame("Button", "LFGBuddy_ResetButton", lfmPanel, "UIPanelButtonTemplate")
resetBtn:SetPoint("RIGHT", pauseBtn, "LEFT", -5, 0)
resetBtn:GetFontString():SetFont("Fonts\\FRIZQT__.TTF", 11) 
resetBtn:SetSize(96, 24)
resetBtn:SetText("Reset")
resetBtn:SetScript("OnClick", function()
    LFGBuddy.sending = false
    LFGBuddy.whisperQueue = {}
    LFGBuddy.sendTimer = 0
    LFGBuddy.Notify("Whisper queue reset.")
end)

    LFGBuddy.frame = f
end

-- Expose to global for slash command
_G["CreateLFGBuddyUI"] = CreateUI
