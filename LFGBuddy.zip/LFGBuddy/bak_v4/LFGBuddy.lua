-- LFGBuddy Functionality -----------------------------------------------------------------

-- Global table WoW will save
LFGBUDDY_SAVEDVARNAME = "LFGBuddyDB"

-- Config / defaults
local DEFAULT_IGNORE_ZONES = {
    "Baradin Hold","Ragefire Chasm","Wailing Caverns","The Deadmines","Shadowfang Keep",
    "Blackfathom Deeps","Stormwind Stockade","The Stockades","Gnomeregan","Razorfen Kraul",
    "Scarlet Monastery","Razorfen Downs","Uldaman","Zul'Farrak","Maraudon",
    "Sunken Temple","Temple of Atal'Hakkar","Blackrock Depths","Blackrock Spire",
    "Tol Barad","Lower Blackrock Spire","Upper Blackrock Spire","Scholomance","Stratholme",
}

local playerFaction = UnitFactionGroup("player")
local DEFAULT_CITIES_ONLY = playerFaction == "Horde" and {"Orgrimmar","Undercity","Thunder Bluff"}
                         or playerFaction == "Alliance" and {"Stormwind","Ironforge","Darnassus","Exodar"}
                         or {}

local ALL_CLASSES = {"Shaman","Paladin","Druid","Warrior","Warlock","Priest","Rogue","Mage","Hunter"}
--local SEND_INTERVAL = 1.0 -- seconds between whispers

-- Internal state
local LFGBuddy = {}
LFGBuddy.whisperQueue = {}
LFGBuddy.sending = false
LFGBuddy.sendTimer = 0

-- SavedVars
local playerLevel = UnitLevel("player") or 60

LFGBuddyOptions = {
    lastClass = "Shaman",
    lastX = playerLevel,
    lastY = playerLevel,
    message = "Hey buddy, wanna come tank Maraudon?",
    ignoreZones = DEFAULT_IGNORE_ZONES,
    recentMessages = {},
    filterCities = false,
    defaultCities = DEFAULT_CITIES_ONLY,
    allClasses = ALL_CLASSES,
    spamInterval = 1.0,
}


-- Initialize SavedVariables
LFGBuddyOptions = _G[LFGBUDDY_SAVEDVARNAME] or LFGBuddyOptions
_G[LFGBUDDY_SAVEDVARNAME] = LFGBuddyOptions

-- Helpers
function LFGBuddy.Notify(msg)
    if LFGBuddy.frame and LFGBuddy.frame:IsShown() then
        DEFAULT_CHAT_FRAME:AddMessage(msg)
    end
end

local function isZoneIgnored(zone)
    if not zone or zone == "" then return false end
    for _, z in ipairs(LFGBuddyOptions.ignoreZones) do
        if z == zone then return true end
    end
    return false
end

local function isZoneInDefaultCities(zone)
    if not zone or zone == "" then return false end
    for _, city in ipairs(DEFAULT_CITIES_ONLY) do
        if city == zone then return true end
    end
    return false
end

-- WHO list handling
function LFGBuddy.OnWhoListUpdate(onlyCities)
    LFGBuddy.whisperQueue = {}
    local n = GetNumWhoResults()

    for i = 1, n do
        local name, guild, level, race, class, zone = GetWhoInfo(i)
        if name and name ~= UnitName("player") then
            if onlyCities then
                if isZoneInDefaultCities(zone) then
                    tinsert(LFGBuddy.whisperQueue, {name=name, level=level, class=class, zone=zone})
                end
            else
                if not isZoneIgnored(zone) then
                    tinsert(LFGBuddy.whisperQueue, {name=name, level=level, class=class, zone=zone})
                end
            end
        end
    end

    if #LFGBuddy.whisperQueue == 0 then
        LFGBuddy.Notify("No players to whisper after filtering ignore zones.")
    else
        LFGBuddy.Notify("Queued " .. #LFGBuddy.whisperQueue .. " whispers.")
    end
end

-- Whisper pacing
local eventFrame = CreateFrame("Frame")
eventFrame:SetScript("OnUpdate", function(self, elapsed)
    if LFGBuddy.sending then
        -- Ensure sendTimer is initialized
        LFGBuddy.sendTimer = (LFGBuddy.sendTimer or 0) + elapsed

        if LFGBuddy.sendTimer >= (LFGBuddyOptions.spamInterval or 1.0) then
            LFGBuddy.sendTimer = 1.0

            local entry = tremove(LFGBuddy.whisperQueue, 1)
            if entry then
                local msg = LFGBuddyOptions.message or ""
                SendChatMessage(msg, "WHISPER", nil, entry.name)
                --LFGBuddy.Notify("Whispered " .. entry.name)

                -- Save message history
                if msg ~= "" then
                    for i = #LFGBuddyOptions.recentMessages, 1, -1 do
                        if LFGBuddyOptions.recentMessages[i] == msg then
                            table.remove(LFGBuddyOptions.recentMessages, i)
                        end
                    end
                    table.insert(LFGBuddyOptions.recentMessages, 1, msg)
                    while #LFGBuddyOptions.recentMessages > 10 do
                        table.remove(LFGBuddyOptions.recentMessages)
                    end
                end
            else
                LFGBuddy.sending = false
                LFGBuddy.Notify("Finished sending whispers.")
            end
        end
    end
end)

-- WHO event
local evt = CreateFrame("Frame")
evt:RegisterEvent("WHO_LIST_UPDATE")
evt:SetScript("OnEvent", function(_, event)
    if event == "WHO_LIST_UPDATE" then
        LFGBuddy.OnWhoListUpdate(LFGBuddyOptions.filterCities)
    end
end)

-- Level dropdown helper
function LFGBuddy.CreateLevelDropdown(name, defaultValue, dbKey)
    local dd = CreateFrame("Frame", name, UIParent, "UIDropDownMenuTemplate")
    UIDropDownMenu_SetWidth(dd, 70)

    local function Init()
        local info = UIDropDownMenu_CreateInfo()
        local min = math.max(1, playerLevel - 8)
        local max = math.min(60, playerLevel + 8)
        for i = min, max do
            info.text = tostring(i)
            info.value = i
            info.func = function(self)
                UIDropDownMenu_SetSelectedValue(dd, self.value)
                if dbKey then LFGBuddyOptions[dbKey] = self.value end
            end
            info.checked = (i == UIDropDownMenu_GetSelectedValue(dd))
            UIDropDownMenu_AddButton(info)
        end
    end

    UIDropDownMenu_Initialize(dd, Init)
    if defaultValue then UIDropDownMenu_SetSelectedValue(dd, defaultValue) end
    return dd
end


-- Slash command to toggle UI
SLASH_LFGBUDDY1 = "/lfgbuddy"
SlashCmdList["LFGBUDDY"] = function()
    if not LFGBuddy.frame then
        CreateLFGBuddyUI()  -- safely create UI if not yet created
    end
    if LFGBuddy.frame:IsShown() then
        LFGBuddy.frame:Hide()
    else
        LFGBuddy.frame:Show()
    end
end

-- Expose LFGBuddy for UI file
_G["LFGBuddy"] = LFGBuddy
