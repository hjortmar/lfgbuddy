-- LFGBuddy Addon for WoW 3.3.5 API 2009 -----------------------------------------------------------------
-- CONFIG / defaults
local DEFAULT_IGNORE_ZONES = {
    "Baradin Hold", "Ragefire Chasm", "Wailing Caverns", "The Deadmines", "Shadowfang Keep",
    "Blackfathom Deeps", "Stormwind Stockade", "The Stockades", "Gnomeregan", "Razorfen Kraul",
    "Scarlet Monastery", "Razorfen Downs", "Uldaman", "Zul'Farrak", "Maraudon",
    "Sunken Temple", "Temple of Atal'Hakkar", "Blackrock Depths", "Blackrock Spire",
    "Tol Barad", "Lower Blackrock Spire", "Upper Blackrock Spire", "Scholomance", "Stratholme",
}

local LFGBUDDY_SAVEDVARNAME = "LFGBuddyDB"
local SEND_INTERVAL = 1.0 -- seconds between whispers to avoid flooding

-- Internal state
local LFGBuddy = {}
LFGBuddy.frame = nil
LFGBuddy.whisperQueue = {}
LFGBuddy.sending = false
LFGBuddy.sendTimer = 0

-- Default savedDB: first load only
local playerLevel = UnitLevel("player") or 60
if not _G[LFGBUDDY_SAVEDVARNAME] then
    _G[LFGBUDDY_SAVEDVARNAME] = {
        lastClass = "Shaman",
        lastX = playerLevel,
        lastY = playerLevel,
        customRange = false,
        message = "Hey buddy, wanna come tank Maraudon?", -- first load default
        ignoreZones = DEFAULT_IGNORE_ZONES,
        recentMessages = {},
    }
end
local DB = _G[LFGBUDDY_SAVEDVARNAME]

-- Ensure message box always has last typed message (only first load uses default)
if DB.message == nil or DB.message == "" then
    DB.message = "Hey buddy, wanna come tank Maraudon?"
end

-- Notify only if GUI is open
local function Notify(msg)
    if LFGBuddy.frame and LFGBuddy.frame:IsShown() then
        DEFAULT_CHAT_FRAME:AddMessage(msg)
    end
end

-- Utility: simple frame
local function CreateSimpleFrame(name, parent, width, height)
    local f = CreateFrame("Frame", name, parent)
    f:SetSize(width, height)
    f:SetFrameStrata("DIALOG")
    f:EnableMouse(true)
    f:SetMovable(true)
    f:SetClampedToScreen(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) self:StartMoving() end)
    f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    return f
end

-- Helper: check ignored zones
local function isZoneIgnored(zone)
    if not zone or zone=="" then return false end
    for _,z in ipairs(DB.ignoreZones) do
        if z==zone then return true end
    end
    return false
end

-- WHO results handler
local function OnWhoListUpdate()
    local n = GetNumWhoResults()
    if n==0 then
        Notify("No who results.")
        return
    end
    LFGBuddy.whisperQueue = {}
    for i=1,n do
        local name, guild, level, race, class, zone, classFileName, realm = GetWhoInfo(i)
        if name and name~=UnitName("player") and not isZoneIgnored(zone) then
            tinsert(LFGBuddy.whisperQueue, {name=name, level=level, class=class, zone=zone})
        end
    end
    if #LFGBuddy.whisperQueue==0 then
        Notify("No players to whisper after filtering ignore zones.")
        return
    end
    Notify("Queued "..tostring(#LFGBuddy.whisperQueue).." whispers. Ready to send.")
end

-- OnUpdate loop to pace whispers
local eventFrame = CreateFrame("Frame")
eventFrame:SetScript("OnUpdate", function(self, elapsed)
    if LFGBuddy.sending then
        LFGBuddy.sendTimer = LFGBuddy.sendTimer + elapsed
        if LFGBuddy.sendTimer >= SEND_INTERVAL then
            LFGBuddy.sendTimer = 0
            local entry = tremove(LFGBuddy.whisperQueue, 1)
            if entry then
                local msg = DB.message or "Hey buddy, wanna join?"
                SendChatMessage(msg, "WHISPER", nil, entry.name)
                Notify("Whispered "..entry.name)
                -- Save recent messages across sessions
                if msg ~= "" then
                    -- remove duplicates
                    for i=#DB.recentMessages,1,-1 do
                        if DB.recentMessages[i]==msg then table.remove(DB.recentMessages,i) end
                    end
                    table.insert(DB.recentMessages,1,msg)
                    while #DB.recentMessages>10 do table.remove(DB.recentMessages) end
                end
                DB.message = msg -- keep last message in saved var
            else
                LFGBuddy.sending = false
                Notify("Finished sending whispers.")
            end
        end
    end
end)

-- WHO event registration
local evt = CreateFrame("Frame")
evt:RegisterEvent("WHO_LIST_UPDATE")
evt:SetScript("OnEvent", function(self, event, ...)
    if event=="WHO_LIST_UPDATE" then
        OnWhoListUpdate()
    end
end)

-- Number dropdown helper (8 below / 8 above current level, clamped 1-60)
local function CreateLevelDropdown(name, anchor, defaultValue)
    local dd = CreateFrame("Frame", name, UIParent, "UIDropDownMenuTemplate")
    dd:SetPoint("LEFT", anchor, "RIGHT", 10, 0)
    UIDropDownMenu_SetWidth(dd, 70)

    local function Init()
        local info = UIDropDownMenu_CreateInfo()
        local min = math.max(1, playerLevel - 8)
        local max = math.min(60, playerLevel + 8)
        for i=min,max do
            info.text = tostring(i)
            info.value = i
            info.func = function(self)
                UIDropDownMenu_SetSelectedValue(dd, self.value)
            end
            info.checked = nil
            UIDropDownMenu_AddButton(info)
        end
    end

    UIDropDownMenu_Initialize(dd, Init)
    UIDropDownMenu_SetSelectedValue(dd, defaultValue)
    return dd
end

-- Main UI
local function CreateUI()
    if LFGBuddy.frame then return end
    local f = CreateSimpleFrame("LFGBuddyFrame", UIParent, 530, 155) -- compacted window
    f:SetPoint("CENTER")
    f:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        edgeSize = 12
    })
    f:SetBackdropColor(0,0,0,0.8)

    -- Header box (draggable)
    local headerHeight = 28
    local header = CreateFrame("Frame", nil, f)
    header:SetPoint("BOTTOMLEFT", f, "TOPLEFT", 0, 0)
    header:SetSize(f:GetWidth(), headerHeight)
    header:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        edgeSize = 12
    })
    header:SetBackdropColor(0,0,0,0.9)
    header:EnableMouse(true)
    header:SetMovable(true)
    header:RegisterForDrag("LeftButton")
    header:SetScript("OnDragStart", function() f:StartMoving() end)
    header:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)

    -- Title inside header (bold style)
    header.title = header:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    header.title:SetPoint("LEFT", 10, 0)
    header.title:SetText("LFG Buddy")

    -- Close button in header
    local close = CreateFrame("Button", nil, header, "UIPanelCloseButton")
    close:SetPoint("RIGHT", -4, 0)
    close:SetScript("OnClick", function() f:Hide() end)

    -- Row spacing (body starts below header)
    local ROW_HEIGHT = 20
    local extraOffset = -15 -- push elements down 15px
    local rowY = extraOffset - 10

    -- Row 2: Class, Min, Max
    f.classLabel = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.classLabel:SetPoint("TOPLEFT", 20, rowY)
    f.classLabel:SetText("Class:")

    local classes = {"Shaman","Paladin","Druid","Warrior","Warlock","Priest","Rogue","Mage","Hunter"}
    local classDrop = CreateFrame("Frame", "LFGBuddy_ClassDropDown", f, "UIDropDownMenuTemplate")
    classDrop:SetPoint("LEFT", f.classLabel, "RIGHT", 10, 0)
    UIDropDownMenu_SetWidth(classDrop, 100)

    local function Class_OnClick(self)
        DB.lastClass = self.value
        UIDropDownMenu_SetSelectedValue(classDrop, self.value)
    end

    local function Class_Initialize()
        local info = UIDropDownMenu_CreateInfo()
        for _,v in ipairs(classes) do
            info.text = v
            info.value = v
            info.func = Class_OnClick
            UIDropDownMenu_AddButton(info)
        end
    end
    UIDropDownMenu_Initialize(classDrop, Class_Initialize)
    UIDropDownMenu_SetSelectedValue(classDrop, DB.lastClass)

    -- Min dropdown
    f.minLabel = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.minLabel:SetPoint("LEFT", classDrop, "RIGHT", 0, 0)
    f.minLabel:SetText("Min:")
    local minDrop = CreateLevelDropdown("LFGBuddy_MinDrop", f.minLabel, DB.lastX)
    minDrop:SetParent(f)

    -- Max dropdown
    f.maxLabel = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.maxLabel:SetPoint("LEFT", minDrop, "RIGHT", 0, 0)
    f.maxLabel:SetText("Max:")
    local maxDrop = CreateLevelDropdown("LFGBuddy_MaxDrop", f.maxLabel, DB.lastY)
    maxDrop:SetParent(f)

    rowY = rowY - ROW_HEIGHT - 10

    -- Row 3: Message
    f.msgLabel = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.msgLabel:SetPoint("TOPLEFT", 20, rowY)
    f.msgLabel:SetText("Message:")

    local edit = CreateFrame("EditBox", "LFGBuddy_MessageEdit", f, "InputBoxTemplate")
    edit:SetPoint("LEFT", f.msgLabel, "RIGHT", 10, 0)
    edit:SetSize(428, 26)
    edit:SetAutoFocus(false)
    edit:SetText(DB.message or "")
    edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    edit:SetScript("OnEnterPressed", function(self)
        DB.message = self:GetText()
        self:ClearFocus()
    end)
    edit:SetScript("OnTextChanged", function(self) DB.message = self:GetText() end)

    rowY = rowY - ROW_HEIGHT - 10

    -- Row 4: Recent messages dropdown (10px left shift)
    local recentDrop = CreateFrame("Frame", "LFGBuddy_RecentDrop", f, "UIDropDownMenuTemplate")
    recentDrop:SetPoint("TOPLEFT", edit, "BOTTOMLEFT", -23, -4)
    UIDropDownMenu_SetWidth(recentDrop, 416)

    local function Recent_OnClick(self)
        DB.message = self.value
        edit:SetText(self.value)
    end

    local function Recent_Initialize()
        local info = UIDropDownMenu_CreateInfo()
        for _,msg in ipairs(DB.recentMessages) do
            info.text = msg
            info.value = msg
            info.func = Recent_OnClick
            info.checked = nil
            UIDropDownMenu_AddButton(info)
        end
    end
    UIDropDownMenu_Initialize(recentDrop, Recent_Initialize)

    rowY = rowY - ROW_HEIGHT - 25 -- vertical spacing


    -- Row 5: Buttons
    local refreshBtn = CreateFrame("Button", "LFGBuddy_RefreshButton", f, "UIPanelButtonTemplate")
    refreshBtn:SetPoint("BOTTOMLEFT", 12, 10)
    refreshBtn:SetSize(120,26)
    refreshBtn:SetText("Refresh /who")
    refreshBtn:SetScript("OnClick", function()
        local classStr = string.lower(DB.lastClass)
        local min = UIDropDownMenu_GetSelectedValue(minDrop)
        local max = UIDropDownMenu_GetSelectedValue(maxDrop)
        local whoQuery = "c-"..classStr.." "..min.."-"..max
        Notify("Sending /who query: "..whoQuery)
        SendWho(whoQuery)
    end)

    -- Reset button
    local resetBtn = CreateFrame("Button", "LFGBuddy_ResetButton", f, "UIPanelButtonTemplate")
    resetBtn:SetPoint("BOTTOMRIGHT", -12, 10) -- anchor same as send, shift left later
    resetBtn:SetSize(80,26)
    resetBtn:SetText("Reset")
    resetBtn:SetScript("OnClick", function()
        LFGBuddy.sending = false
        LFGBuddy.whisperQueue = {}
        LFGBuddy.sendTimer = 0
        Notify("Whisper queue has been reset.")
    end)

    -- Pause button
    local pauseBtn = CreateFrame("Button", "LFGBuddy_PauseButton", f, "UIPanelButtonTemplate")
    pauseBtn:SetPoint("RIGHT", resetBtn, "LEFT", -5, 0)
    pauseBtn:SetSize(80,26)
    pauseBtn:SetText("Pause")
    pauseBtn:SetScript("OnClick", function()
        if LFGBuddy.sending then
            LFGBuddy.sending = false
            Notify("Whisper sending paused.")
            pauseBtn:SetText("Resume")
        else
            if #LFGBuddy.whisperQueue > 0 then
                LFGBuddy.sending = true
                LFGBuddy.sendTimer = SEND_INTERVAL
                Notify("Whisper sending resumed.")
                pauseBtn:SetText("Pause")
            else
                Notify("No queued whispers to resume.")
            end
        end
    end)

    local sendBtn = CreateFrame("Button", "LFGBuddy_SendButton", f, "UIPanelButtonTemplate")
    sendBtn:SetPoint("RIGHT", pauseBtn, "LEFT", -5, 0)
    sendBtn:SetSize(120,26)
    sendBtn:SetText("Send Whispers")
    sendBtn:SetScript("OnClick", function()
        if #LFGBuddy.whisperQueue==0 then
            Notify("No queued whispers. Run /who first.")
            return
        end
        LFGBuddy.sending = true
        LFGBuddy.sendTimer = SEND_INTERVAL
        Notify("Started sending whispers.")
        pauseBtn:SetText("Pause")
    end)

    LFGBuddy.frame = f
end

-- Slash command
SLASH_LFGBUDDY1 = "/lfgbuddy"
SlashCmdList["LFGBUDDY"] = function(msg)
    if not LFGBuddy.frame then CreateUI() end
    if LFGBuddy.frame:IsShown() then LFGBuddy.frame:Hide() else LFGBuddy.frame:Show() end
end

-- Initialize hidden UI
CreateUI()
LFGBuddy.frame:Hide()