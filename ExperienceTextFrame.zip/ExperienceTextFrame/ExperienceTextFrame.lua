-- ExperienceTextFrame.lua
-- Standalone WoW 3.3.5 / WotLK Compatibility Edition
-- Implements: currxp/maxtotalxp (restedxp) format, /etf hide, and Detailed Tooltip (XP/Hour, Activities Remaining, Time to Level, and all XP values/percentages).

-- ====================================================================
-- === SAVED VARIABLES INITIALIZATION =================================
-- ====================================================================
-- This global table is automatically created/loaded by WoW if the
-- addon's .toc file specifies 'ExperienceTextFrameDB' in SavedVariables.
ExperienceTextFrameDB = ExperienceTextFrameDB or {}

local defaults = {
    isLocked = false,
    -- MODIFIED: Added all six possible display modes
    displayMode = "VALUE", -- "VALUE", "PERCENT", "CURR_PERCENT", "CURR_RESTED_PERCENT", "VALUE_ONLY", or "VALUE_RESTED_PERCENT"
    isHidden = false,
    position = {
        point = "CENTER",
        relativeTo = "UIParent",
        relativePoint = "CENTER",
        x = 0,
        y = 0
    }
}

-- Ensure the DB table has the required structure and defaults on first load
local function InitializeDB()
    local db = ExperienceTextFrameDB
    db.isLocked = db.isLocked ~= nil and db.isLocked or defaults.isLocked
    db.displayMode = db.displayMode or defaults.displayMode
    db.isHidden = db.isHidden ~= nil and db.isHidden or defaults.isHidden
    
    db.position = db.position or {}
    db.position.point = db.position.point or defaults.position.point
    db.position.relativeTo = db.position.relativeTo or defaults.position.relativeTo
    db.position.relativePoint = db.position.relativePoint or defaults.position.relativePoint
    db.position.x = db.position.x or defaults.position.x
    db.position.y = db.position.y or defaults.position.y
end

-- ====================================================================
-- === LOCAL VARIABLES (NON-PERSISTENT) ===============================
-- ====================================================================

local ExperienceTextFrame
local xpFullDisplay 
local tooltip = CreateFrame("GameTooltip", "ExperienceTextFrameTooltip", UIParent, "GameTooltipTemplate")

local startTime = 0       
local totalXPGained = 0  
local lastXPGain = 0     
local lastXP = 0         

-- ====================================================================
-- === Utility Functions (Print/Time) =================================
-- ====================================================================

-- Print function to manage chat output with a prefix and notification settings
local function ETFPrint(msg, raw, force)

    local text = tostring(msg or "")
    local ADDON_PREFIX_COLOR = "|cff33ff99ETF: |r" 
    
    if not raw then
        text = ADDON_PREFIX_COLOR .. text
    end

    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage(text)
    else
        print(text)  -- fallback
    end
end

-- Helper function to format seconds into readable time (Xh Ym Zs)
local function FormatTime(seconds)
    if seconds <= 0 or seconds > 1e9 then 
        return "N/A"
    end
    
    local minutes = seconds / 60
    local roundedMinutes = math.ceil(minutes)
    
    return format("%dm", roundedMinutes) -- Returns time in minutes rounded up, e.g., "13m"
end

-- ====================================================================
-- === XP Logic Functions =============================================
-- ====================================================================

local function UpdateXPDisplay()
    local db = ExperienceTextFrameDB

    if UnitLevel("player") == MAX_PLAYER_LEVEL or UnitXPMax("player") == 0 then 
        xpFullDisplay:SetText("|cff00ff00ETF: Max Level Reached|r")
        return
    end

    local currentXP = UnitXP("player") or 0
    local requiredXP = UnitXPMax("player") or 0
    local restedXP = GetXPExhaustion() or 0 

    -- Color Codes: |cffRRGGBB
    local XP_COLOR = "|cffffffff"
    local REST_COLOR = "|cff569cd6" -- Blueish color for the Rested XP value
    local PARENTHESES_COLOR = "|cfffff8a3" -- Gold color for parentheses
    local NORMAL_COLOR = "|cffffffff"
    
    local fullText
    
    -- Conditional string components for rested XP value
    local restedStr = (restedXP > 0 and format(" %s(%s%d%s)|r", 
        PARENTHESES_COLOR, 
        REST_COLOR, restedXP, 
        PARENTHESES_COLOR)) or ""
        
    -- Conditional string components for rested XP percentage
    local restedPercentStr = (restedXP > 0 and format(" %s(%s%.1f%%%s)|r", 
        PARENTHESES_COLOR, 
        REST_COLOR, (restedXP / requiredXP) * 100, 
        PARENTHESES_COLOR)) or ""

    if db.displayMode == "VALUE" then
        -- Format: currxp/maxtotalxp (restedxp)
        fullText = format("%s%d%s / %s%d%s%s", 
            XP_COLOR, currentXP, NORMAL_COLOR, 
            XP_COLOR, requiredXP, NORMAL_COLOR, 
            restedStr) 
    elseif db.displayMode == "PERCENT" then
        local xpPercent = (currentXP / requiredXP) * 100
        
        -- Format: currxppercent / 100.0% (restedxppercent)
        fullText = format("%s%.1f%%%s / %s100.0%%%s%s",
            XP_COLOR, xpPercent, NORMAL_COLOR,
            XP_COLOR, NORMAL_COLOR,
            restedPercentStr) 
    elseif db.displayMode == "CURR_PERCENT" then
        local xpPercent = (currentXP / requiredXP) * 100
        
        -- Format: currxppercent only
        fullText = format("%s%.1f%%%s",
            XP_COLOR, xpPercent, NORMAL_COLOR)
            
    elseif db.displayMode == "CURR_RESTED_PERCENT" then
        local xpPercent = (currentXP / requiredXP) * 100
        
        -- Format: currxppercent (restedxppercent)
        fullText = format("%s%.1f%%%s%s",
            XP_COLOR, xpPercent, NORMAL_COLOR,
            restedPercentStr) 
    elseif db.displayMode == "VALUE_ONLY" then
        -- Format: currxp / maxtotalxp
        fullText = format("%s%d%s / %s%d%s", 
            XP_COLOR, currentXP, NORMAL_COLOR, 
            XP_COLOR, requiredXP, NORMAL_COLOR)
            
    elseif db.displayMode == "VALUE_RESTED_PERCENT" then
        -- Format: currxp / maxtotalxp (restedxppercentage)
        fullText = format("%s%d%s / %s%d%s%s", 
            XP_COLOR, currentXP, NORMAL_COLOR, 
            XP_COLOR, requiredXP, NORMAL_COLOR, 
            restedPercentStr) -- Uses restedPercentStr
    end
    
    xpFullDisplay:SetText(fullText)
end

-- ====================================================================
-- === Tooltip Functions ==============================================
-- ====================================================================

local function UpdateTooltip()
    local db = ExperienceTextFrameDB

    local currentXP = UnitXP("player") or 0
    local requiredXP = UnitXPMax("player") or 0
    local restedXP = GetXPExhaustion() or 0 
    local remainingXP = requiredXP - currentXP

    -- Calculations
    local currentTime = GetTime()
    local elapsedTime = currentTime - startTime
    local xpPerHour = (elapsedTime > 0 and totalXPGained > 0) and math.floor((totalXPGained / elapsedTime) * 3600) or 0
    
    local timeToLevelStr = "N/A"
    if xpPerHour > 0 and remainingXP > 0 then
        local secondsToLevel = (remainingXP / xpPerHour) * 3600
        timeToLevelStr = FormatTime(secondsToLevel)
    end
    
    local activitiesRemainingStr = "N/A"
    local lastXPGainStr = "N/A"

    if lastXPGain > 0 and remainingXP > 0 then
        activitiesRemainingStr = math.ceil(remainingXP / lastXPGain)
    end

    if lastXPGain > 0 then
        lastXPGainStr = lastXPGain
    end
    
    -- Tooltip Display Setup
    tooltip:SetOwner(ExperienceTextFrame, "ANCHOR_CURSOR")
    tooltip:ClearLines()
    tooltip:SetText("|cfffff8a3Experience|r", 1.0, 1.0, 1.0) -- Header (larger font)
	tooltip:AddLine(" ")
    
    if UnitLevel("player") == MAX_PLAYER_LEVEL or UnitXPMax("player") == 0 then
        tooltip:AddLine("|cff00ff00Max Level Reached!|r")
        tooltip:Show()
        return
    end
    
    -- ROW 1: XP Values
    local restedValueStr = (restedXP > 0 and format(" |cfffff8a3(%s%d|cfffff8a3)|r", "|cff569cd6", restedXP)) or ""
    local xpRow1 = format("|cffffffff%d / %d|r%s", 
        currentXP, requiredXP, restedValueStr)
    
    -- Removed AddLine(" ") to immediately follow header with data, ensuring body font size.
    tooltip:AddLine(xpRow1)

    -- ROW 2: Percentage Values
    local xpPercent = (currentXP / requiredXP) * 100
    local restedPercent = (restedXP / requiredXP) * 100
    
    local restedPercentValueStr = (restedPercent > 0 and format(" |cfffff8a3(%s%.1f%%|cfffff8a3)|r", "|cff569cd6", restedPercent)) or ""
    local xpRow2 = format("|cffffffff%.1f%% / 100.0%%|r%s", 
        xpPercent, restedPercentValueStr)
    tooltip:AddLine(xpRow2)
    
    -- ROW 3 & 4: Tracking Stats
    tooltip:AddLine(" ")
    tooltip:AddLine(format("XP per hour: |cffffffff%d|r", xpPerHour))
    tooltip:AddLine(format("Time to level: |cffffffff%s|r", timeToLevelStr))
    
    -- ROW 5 & 6: Activities Remaining
    tooltip:AddLine(" ")
    tooltip:AddLine(format("Recent XP gain: |cffffffff%s|r", lastXPGainStr))
    tooltip:AddLine(format("Repeat to level: |cffffffff%s|r", activitiesRemainingStr))
    
    tooltip:Show()
end

local function HideTooltip()
    tooltip:Hide()
end

-- ====================================================================
-- === Frame Position, Lock, and Visibility Management ================
-- ====================================================================

local function SavePosition()
    local db = ExperienceTextFrameDB
    local point, relativeTo, relativePoint, x, y = ExperienceTextFrame:GetPoint()
    
    db.position.point = point
    db.position.relativeTo = (type(relativeTo) == "table" and relativeTo:GetName()) or "UIParent"
    db.position.relativePoint = relativePoint
    db.position.x = x
    db.position.y = y
end

local function CenterFrame()
    ExperienceTextFrame:ClearAllPoints()
    ExperienceTextFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    ExperienceTextFrame:StopMovingOrSizing()
    SavePosition()
    ETFPrint("Frame moved to center position.|r")
end

local function SetLockState(lockState)
    local db = ExperienceTextFrameDB
    db.isLocked = lockState
    
    if db.isLocked then
        ExperienceTextFrame:SetMovable(false)
        -- Keep mouse enabled so OnEnter/OnLeave (tooltip) events still fire.
        ExperienceTextFrame:EnableMouse(true) 
		ETFPrint("Frame set to LOCKED.")
    else
        ExperienceTextFrame:SetMovable(true)
        ExperienceTextFrame:EnableMouse(true)
        ETFPrint("Frame set to UNLOCKED. Drag to move. Type /etf lock to lock.|r")
    end
end

-- Toggles the frame's visibility
local function SetVisibilityState(hideState)
    local db = ExperienceTextFrameDB
    db.isHidden = hideState
    
    if db.isHidden then
        ExperienceTextFrame:Hide()
        ETFPrint("Frame set to HIDDEN.")
    else
        ExperienceTextFrame:Show()
        UpdateXPDisplay() 
        ETFPrint("Frame set to VISIBLE. Type /etf hide to hide.|r")
    end
end

-- ====================================================================
-- === Frame Creation and Setup =======================================
-- ====================================================================

	local function SetupUI()
		local db = ExperienceTextFrameDB
		local pos = db.position

		ExperienceTextFrame = CreateFrame("Frame", "ExperienceTextFrame", UIParent)
		ExperienceTextFrame:SetSize(400, 16) 
		ExperienceTextFrame:SetFrameStrata("MEDIUM") 
		
		-- Apply Saved Position
		local relativeToFrame = _G[pos.relativeTo] or UIParent
		ExperienceTextFrame:SetPoint(pos.point, relativeToFrame, pos.relativePoint, pos.x, pos.y)

		xpFullDisplay = ExperienceTextFrame:CreateFontString("ExperienceTextFrame_FullDisplay", "OVERLAY", "GameFontHighlightSmall")
		
		-- LEFT ALIGNMENT
		xpFullDisplay:SetPoint("LEFT", ExperienceTextFrame, "LEFT", 0, 0)
		
		xpFullDisplay:SetTextColor(1.0, 1.0, 1.0, 1.0) 
		xpFullDisplay:SetText("XP N/A") 
		
		-- LEFT ALIGNMENT
		xpFullDisplay:SetJustifyH("LEFT") 
		
		if db.isHidden then
			ExperienceTextFrame:Hide()
		else
			ExperienceTextFrame:Show()
		end
		
		-- Setup Frame Movement Handlers
		ExperienceTextFrame:SetScript("OnMouseDown", function(self, button)
			-- *** START NEW XP RESET LOGIC ***
			if button == "LeftButton" or button == "RightButton" or button == "MiddleButton" then
				startTime = GetTime()       -- Reset the timer
				totalXPGained = 0           -- Reset total XP gained for the current session
				lastXPGain = 0              -- Reset the last XP gain value
				ETFPrint("XP/Hour tracking has been |cffffcc00RESET|r.")
			end
			-- *** END NEW XP RESET LOGIC ***

			-- Existing movement logic
			if not db.isLocked and button == "LeftButton" then
				self:StartMoving()
			end
		end)
		ExperienceTextFrame:SetScript("OnMouseUp", function(self, button)
			if not db.isLocked and button == "LeftButton" then
				self:StopMovingOrSizing()
				SavePosition() -- Save position on move end
			end
		end)
		
		-- Tooltip Mouseover Handlers
		ExperienceTextFrame:SetScript("OnEnter", UpdateTooltip)
		ExperienceTextFrame:SetScript("OnLeave", HideTooltip)

		SetLockState(db.isLocked) -- Apply saved lock state
	end

-- ====================================================================
-- === Addon Lifecycle and Events =====================================
-- ====================================================================

local EventFrame = CreateFrame("Frame")

-- Event handler for XP Gained and Time Tracking
EventFrame:SetScript("OnEvent", function(self, event, ...)
    local arg1 = select(1, ...)
    local db = ExperienceTextFrameDB
    
    if event == "ADDON_LOADED" and arg1 == "ExperienceTextFrame" then
        InitializeDB() -- Load defaults if this is the first time
        SetupUI()
        
        self:RegisterEvent("PLAYER_XP_UPDATE")
        self:RegisterEvent("PLAYER_LEVEL_UP")
        self:RegisterEvent("PLAYER_ENTERING_WORLD")
        
    elseif event == "PLAYER_XP_UPDATE" or event == "PLAYER_LEVEL_UP" then
        if not db.isHidden then 
            local currentXP = UnitXP("player") or 0
            
            -- Track total XP and last gain for XP/Hour and Activities Remaining
            if UnitXPMax("player") > 0 and lastXP > 0 and currentXP > lastXP then
                 local gain = currentXP - lastXP
                 totalXPGained = totalXPGained + gain
                 lastXPGain = gain 
            end
            
            lastXP = currentXP
            UpdateXPDisplay()
        end
        
    elseif event == "PLAYER_ENTERING_WORLD" then
        self:UnregisterEvent("PLAYER_ENTERING_WORLD") 
        
        -- Reset non-persistent trackers on login/world entry
        startTime = GetTime()
        totalXPGained = 0
        lastXPGain = 0
        lastXP = UnitXP("player") or 0 
        
        C_Timer.After(5.1, UpdateXPDisplay) 
    end
end)

-- Handle Chat Commands
SLASH_ETF1 = "/etf"
SlashCmdList["ETF"] = function(msg)
    local command = string.lower(msg)
    local db = ExperienceTextFrameDB
    local handled = true -- Assume handled unless the command is unrecognized

    if command == "lock" then
        SetLockState(not db.isLocked)
    elseif command == "center" then
        CenterFrame()
    elseif command == "hide" or command == "show" or command == "toggle" then
        SetVisibilityState(not db.isHidden)
    elseif command == "displaymode" or command == "dm" then
        -- Logic cycles through six modes
        if db.displayMode == "VALUE" then
            db.displayMode = "PERCENT"
            ETFPrint("Display mode set to PERCENT.")
        elseif db.displayMode == "PERCENT" then
            db.displayMode = "CURR_PERCENT"
            ETFPrint("Display mode set to CURRENT XP PERCENT.")
        elseif db.displayMode == "CURR_PERCENT" then
            db.displayMode = "CURR_RESTED_PERCENT" 
            ETFPrint("Display mode set to CURRENT XP PERCENT and RESTED XP PERCENT.")
        elseif db.displayMode == "CURR_RESTED_PERCENT" then
            db.displayMode = "VALUE_ONLY" 
            ETFPrint("Display mode set to CURRENT XP VALUE.")
        elseif db.displayMode == "VALUE_ONLY" then
            db.displayMode = "VALUE_RESTED_PERCENT"
            ETFPrint("Display mode set to CURRENT XP VALUE and RESTED XP PERCENT.")
        else -- Cycles back to VALUE (covers "VALUE_RESTED_PERCENT" case)
            db.displayMode = "VALUE"
            ETFPrint("Display mode set to VALUE.")
        end
        UpdateXPDisplay()
    else
        -- Command not recognized, set handled to false and print usage
        handled = false 
        ETFPrint("|cffccccccUsage: /etf lock | /etf center | /etf hide | /etf displaymode|r", true) 
    end
    
    -- FIX: Returning a non-nil value (like true) tells WoW's chat system the command was handled, 
    -- which closes the input box and prevents the command from being sent as chat.
    if handled then
        return true 
    end
end

-- Register the initial load event
EventFrame:RegisterEvent("ADDON_LOADED")