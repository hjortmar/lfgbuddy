string.gfind = string.gmatch
ITEM_SPELL_CHARGES_P1 = ITEM_SPELL_CHARGES